-- =============================================================================
--  NEXORA data store (SQLite) - runnable twin of schema_oracle.sql.
--  Same tables, same columns, same tracking; only the dialect differs.
--  Backend/db.js applies this file on first start.
-- =============================================================================
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS users (
   user_id            INTEGER PRIMARY KEY AUTOINCREMENT,
   full_name          TEXT NOT NULL,
   email              TEXT NOT NULL UNIQUE,
   password_hash      TEXT NOT NULL,
   role               TEXT NOT NULL DEFAULT 'CUSTOMER' CHECK (role IN ('CUSTOMER','ADMIN')),
   is_active          INTEGER NOT NULL DEFAULT 1 CHECK (is_active IN (0,1)),
   created_at         TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
   last_login_at      TEXT,
   failed_login_count INTEGER NOT NULL DEFAULT 0,
   locked_until       TEXT
);
CREATE TABLE IF NOT EXISTS products (
   product_id   INTEGER PRIMARY KEY AUTOINCREMENT,
   name         TEXT NOT NULL,
   category     TEXT,
   price        REAL NOT NULL CHECK (price >= 0),
   is_available INTEGER NOT NULL DEFAULT 1 CHECK (is_available IN (0,1))
);
CREATE TABLE IF NOT EXISTS inventory (
   product_id        INTEGER PRIMARY KEY REFERENCES products(product_id) ON DELETE CASCADE,
   quantity          INTEGER NOT NULL DEFAULT 0 CHECK (quantity >= 0),
   reserved_quantity INTEGER NOT NULL DEFAULT 0 CHECK (reserved_quantity >= 0),
   reorder_level     INTEGER NOT NULL DEFAULT 5 CHECK (reorder_level >= 0)
);
CREATE TABLE IF NOT EXISTS carts (
   cart_id INTEGER PRIMARY KEY AUTOINCREMENT,
   user_id INTEGER NOT NULL UNIQUE REFERENCES users(user_id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS cart_items (
   cart_id    INTEGER REFERENCES carts(cart_id) ON DELETE CASCADE,
   product_id INTEGER REFERENCES products(product_id) ON DELETE CASCADE,
   quantity   INTEGER NOT NULL CHECK (quantity > 0),
   PRIMARY KEY (cart_id, product_id)
);
CREATE TABLE IF NOT EXISTS orders (
   order_id         INTEGER PRIMARY KEY AUTOINCREMENT,
   user_id          INTEGER NOT NULL REFERENCES users(user_id),
   total_amount     REAL NOT NULL CHECK (total_amount >= 0),
   status           TEXT DEFAULT 'PENDING',
   shipping_address TEXT NOT NULL,
   created_at       TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
   updated_at       TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE TABLE IF NOT EXISTS audit_logs (
   log_id      INTEGER PRIMARY KEY AUTOINCREMENT,
   user_id     INTEGER REFERENCES users(user_id),
   event_type  TEXT NOT NULL,
   details     TEXT,
   created_at  TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
   ip_address  TEXT,
   entity_type TEXT,
   entity_id   INTEGER,
   os_job_id   INTEGER
);
CREATE TABLE IF NOT EXISTS security_events (
   event_id   INTEGER PRIMARY KEY AUTOINCREMENT,
   severity   TEXT CHECK (severity IN ('LOW','MEDIUM','HIGH','CRITICAL')),
   event_type TEXT NOT NULL,
   message    TEXT NOT NULL,
   risk_score REAL CHECK (risk_score BETWEEN 0 AND 100),
   resolved   INTEGER DEFAULT 0 CHECK (resolved IN (0,1)),
   created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);

-- ----------------------------- tracking tables ------------------------------
CREATE TABLE IF NOT EXISTS order_items (
   order_id     INTEGER NOT NULL REFERENCES orders(order_id) ON DELETE CASCADE,
   product_id   INTEGER NOT NULL REFERENCES products(product_id),
   product_name TEXT NOT NULL,
   unit_price   REAL NOT NULL,
   quantity     INTEGER NOT NULL CHECK (quantity > 0),
   PRIMARY KEY (order_id, product_id)
);
CREATE TABLE IF NOT EXISTS order_status_history (
   history_id INTEGER PRIMARY KEY AUTOINCREMENT,
   order_id   INTEGER NOT NULL REFERENCES orders(order_id) ON DELETE CASCADE,
   old_status TEXT,
   new_status TEXT NOT NULL,
   changed_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE TABLE IF NOT EXISTS inventory_movements (
   movement_id    INTEGER PRIMARY KEY AUTOINCREMENT,
   product_id     INTEGER NOT NULL REFERENCES products(product_id) ON DELETE CASCADE,
   delta          INTEGER NOT NULL,
   quantity_after INTEGER NOT NULL,
   reason         TEXT NOT NULL,
   order_id       INTEGER,
   user_id        INTEGER,
   created_at     TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE TABLE IF NOT EXISTS sessions (
   session_id   INTEGER PRIMARY KEY AUTOINCREMENT,
   user_id      INTEGER NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
   role         TEXT NOT NULL,
   token_hash   TEXT NOT NULL UNIQUE,
   ip_address   TEXT,
   user_agent   TEXT,
   created_at   TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
   last_seen_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
   expires_at   TEXT NOT NULL,
   revoked      INTEGER NOT NULL DEFAULT 0 CHECK (revoked IN (0,1))
);
CREATE TABLE IF NOT EXISTS login_history (
   login_id        INTEGER PRIMARY KEY AUTOINCREMENT,
   user_id         INTEGER,
   email_attempted TEXT NOT NULL,
   success         INTEGER NOT NULL CHECK (success IN (0,1)),
   failure_reason  TEXT,
   ip_address      TEXT,
   user_agent      TEXT,
   created_at      TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE TABLE IF NOT EXISTS os_runs (
   run_id           INTEGER PRIMARY KEY AUTOINCREMENT,
   algorithm        TEXT NOT NULL,
   quantum          INTEGER NOT NULL,
   job_count        INTEGER NOT NULL,
   waves            INTEGER NOT NULL,
   avg_wait         REAL,
   avg_turnaround   REAL,
   avg_response     REAL,
   context_switches INTEGER,
   cpu_utilization  REAL,
   disk_fcfs        INTEGER,
   disk_sstf        INTEGER,
   deadlocks        INTEGER DEFAULT 0,
   created_at       TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE TABLE IF NOT EXISTS os_jobs (
   job_id         INTEGER PRIMARY KEY,
   pid            INTEGER,
   job_type       TEXT NOT NULL,
   user_id        INTEGER,
   source         TEXT NOT NULL DEFAULT 'USER',
   http_method    TEXT,
   http_path      TEXT,
   status_code    INTEGER,
   duration_ms    INTEGER,
   queue_level    INTEGER,
   priority       INTEGER,
   arrival_tick   INTEGER,
   start_tick     INTEGER,
   finish_tick    INTEGER,
   burst          INTEGER,
   wait_ticks     INTEGER,
   turnaround     INTEGER,
   response_ticks INTEGER,
   memory_kb      INTEGER,
   page_faults    INTEGER,
   page_hits      INTEGER,
   deadlocked     INTEGER DEFAULT 0,
   retried        INTEGER DEFAULT 0,
   algorithm      TEXT,
   run_id         INTEGER REFERENCES os_runs(run_id),
   created_at     TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE TABLE IF NOT EXISTS os_metrics (
   metric_id       INTEGER PRIMARY KEY AUTOINCREMENT,
   sampled_at      TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
   cpu_utilization REAL,
   memory_used_kb  INTEGER,
   memory_total_kb INTEGER,
   process_count   INTEGER,
   jobs_per_sec    REAL,
   page_faults     INTEGER,
   evictions       INTEGER,
   disk_head       INTEGER,
   disk_sstf_total INTEGER,
   disk_fcfs_total INTEGER,
   deadlocks       INTEGER
);
CREATE TABLE IF NOT EXISTS os_events (
   event_id   INTEGER PRIMARY KEY AUTOINCREMENT,
   kernel_seq INTEGER NOT NULL,
   source     TEXT NOT NULL,
   severity   TEXT NOT NULL,
   message    TEXT NOT NULL,
   tick       INTEGER,
   created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);

-- ------------------------- indexes and triggers -----------------------------
CREATE INDEX IF NOT EXISTS idx_products_category  ON products(category);
CREATE INDEX IF NOT EXISTS idx_orders_user        ON orders(user_id);
CREATE INDEX IF NOT EXISTS idx_audit_created      ON audit_logs(created_at);
CREATE INDEX IF NOT EXISTS idx_audit_user         ON audit_logs(user_id);
CREATE INDEX IF NOT EXISTS idx_security_resolved  ON security_events(resolved, created_at);
CREATE INDEX IF NOT EXISTS idx_sessions_user      ON sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_login_history_created ON login_history(created_at);
CREATE INDEX IF NOT EXISTS idx_status_history_order ON order_status_history(order_id);
CREATE INDEX IF NOT EXISTS idx_inv_mov_product    ON inventory_movements(product_id, created_at);
CREATE INDEX IF NOT EXISTS idx_os_jobs_created    ON os_jobs(created_at);
CREATE INDEX IF NOT EXISTS idx_os_jobs_type       ON os_jobs(job_type);
CREATE INDEX IF NOT EXISTS idx_os_metrics_sampled ON os_metrics(sampled_at);
CREATE UNIQUE INDEX IF NOT EXISTS idx_os_events_seq ON os_events(kernel_seq);

CREATE TRIGGER IF NOT EXISTS trg_orders_status_insert AFTER INSERT ON orders
WHEN NEW.status IS NOT NULL
BEGIN
   INSERT INTO order_status_history(order_id, old_status, new_status) VALUES (NEW.order_id, NULL, NEW.status);
END;

CREATE TRIGGER IF NOT EXISTS trg_orders_status_history AFTER UPDATE OF status ON orders
WHEN NEW.status IS NOT NULL AND (OLD.status IS NULL OR OLD.status <> NEW.status)
BEGIN
   INSERT INTO order_status_history(order_id, old_status, new_status) VALUES (NEW.order_id, OLD.status, NEW.status);
   UPDATE orders SET updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE order_id = NEW.order_id;
END;
