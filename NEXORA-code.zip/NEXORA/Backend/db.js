'use strict';
// SQLite data store. Schema lives in ../DB/schema_sqlite.sql (twin of schema_oracle.sql).
const { DatabaseSync } = require('node:sqlite');
const fs = require('node:fs');
const path = require('node:path');
const { hashPassword } = require('./auth');

const ADMIN_EMAIL = 'admin@nexora.local';
const DEFAULT_ADMIN_PASSWORD = 'NexoraDemo123!';

const STARTER = [
  ['Wireless Headphones', 'Electronics', 49.99, 18], ['Smart Desk Lamp', 'Home', 29.5, 25],
  ['Everyday Backpack', 'Accessories', 39, 12], ['Mechanical Keyboard', 'Electronics', 74.95, 9],
  ['USB-C Hub', 'Electronics', 34.9, 30], ['Ceramic Mug Set', 'Home', 19.99, 40],
  ['Wireless Mouse', 'Electronics', 24.5, 22], ['Notebook Pack', 'Stationery', 12, 60],
];

function open(file) {
  const db = new DatabaseSync(file);
  db.exec('PRAGMA journal_mode = WAL; PRAGMA foreign_keys = ON; PRAGMA busy_timeout = 3000;');
  db.exec(fs.readFileSync(path.join(__dirname, '..', 'DB', 'schema_sqlite.sql'), 'utf8'));
  seed(db);
  return db;
}

function seed(db) {
  const adminPassword = process.env.NEXORA_ADMIN_PASSWORD || DEFAULT_ADMIN_PASSWORD;
  if (!db.prepare(`SELECT 1 FROM users WHERE email = ?`).get(ADMIN_EMAIL)) {
    db.prepare(`INSERT INTO users(full_name, email, password_hash, role) VALUES ('NEXORA Admin', ?, ?, 'ADMIN')`)
      .run(ADMIN_EMAIL, hashPassword(adminPassword));
  }
  if (!db.prepare(`SELECT COUNT(*) n FROM products`).get().n) {
    const addP = db.prepare(`INSERT INTO products(name, category, price) VALUES (?,?,?)`);
    const addI = db.prepare(`INSERT INTO inventory(product_id, quantity) VALUES (?,?)`);
    const addM = db.prepare(`INSERT INTO inventory_movements(product_id, delta, quantity_after, reason) VALUES (?,?,?, 'PRODUCT_CREATED')`);
    for (const [name, cat, price, qty] of STARTER) {
      const id = Number(addP.run(name, cat, price).lastInsertRowid);
      addI.run(id, qty); addM.run(id, qty, qty);
    }
  }
}

function tx(db, fn) {
  db.exec('BEGIN IMMEDIATE');
  try { const r = fn(); db.exec('COMMIT'); return r; }
  catch (e) { try { db.exec('ROLLBACK'); } catch {} throw e; }
}

module.exports = { open, tx, ADMIN_EMAIL, DEFAULT_ADMIN_PASSWORD };
