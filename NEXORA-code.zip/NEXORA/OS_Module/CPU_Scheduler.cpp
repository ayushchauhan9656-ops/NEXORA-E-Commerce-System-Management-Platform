#include "CPU_Scheduler.hpp"
#include <algorithm>
#include <cctype>
#include <deque>
#include <queue>
#include <stdexcept>

using namespace std;

namespace nexora
{
    // First-Come, First-Served Implementation
    vector<int> CPUScheduler::fcfs(vector<Job> jobs)
    {
        stable_sort(jobs.begin(), jobs.end(), [](const Job &a, const Job &b)
                    { return a.arrival < b.arrival; });
        vector<int> order;
        for (const auto &job : jobs)
            if (job.burst > 0)
                order.push_back(job.id);
        return order;
    }

    // Non-preemptive SJF
    vector<int> CPUScheduler::sjf(vector<Job> jobs)
    {
        vector<int> order;
        vector<bool> finished(jobs.size(), false);
        int completed = 0;
        int time = 0;

        for (size_t i = 0; i < jobs.size(); ++i)
        {
            if (jobs[i].burst <= 0)
            {
                finished[i] = true;
                ++completed;
            }
        }

        while (completed < static_cast<int>(jobs.size()))
        {
            int best = -1;
            for (int i = 0; i < static_cast<int>(jobs.size()); ++i)
            {
                if (finished[i] || jobs[i].burst <= 0)
                    continue;
                if (jobs[i].arrival <= time && (best == -1 || jobs[i].burst < jobs[best].burst || (jobs[i].burst == jobs[best].burst && jobs[i].arrival < jobs[best].arrival)))
                    best = i;
            }

            if (best == -1)
            {
                int next = -1;
                for (int i = 0; i < static_cast<int>(jobs.size()); ++i)
                    if (!finished[i] && jobs[i].burst > 0 && (next == -1 || jobs[i].arrival < jobs[next].arrival))
                        next = i;
                if (next == -1)
                    break;
                time = max(time, jobs[next].arrival);
                continue;
            }

            order.push_back(jobs[best].id);
            time += jobs[best].burst;
            finished[best] = true;
            ++completed;
        }
        return order;
    }

    // Preemptive Priority Implementation
    vector<int> CPUScheduler::priority(vector<Job> jobs, int priority)
    {
        if (priority <= 0)
            throw invalid_argument("Priority must be greater than zero.");

        vector<int> order;
        vector<int> remaining_burst;
        for (const auto &j : jobs)
            remaining_burst.push_back(max(0, j.burst));

        int time = 0;
        size_t completed = 0;

        int last_running_idx = -1;
        int current_priority_left = 0;

        while (completed < jobs.size())
        {
            int best_idx = -1;

            for (size_t i = 0; i < jobs.size(); ++i)
            {
                if (jobs[i].arrival <= time && remaining_burst[i] > 0)
                {
                    if (best_idx == -1)
                    {
                        best_idx = static_cast<int>(i);
                    }
                    else if (jobs[i].priority < jobs[best_idx].priority)
                    {
                        best_idx = static_cast<int>(i);
                    }
                    else if (jobs[i].priority == jobs[best_idx].priority)
                    {
                        if (static_cast<int>(i) == last_running_idx && current_priority_left > 0)
                        {
                            best_idx = static_cast<int>(i);
                        }
                        else if (best_idx != last_running_idx && jobs[i].arrival < jobs[best_idx].arrival)
                        {
                            best_idx = static_cast<int>(i);
                        }
                    }
                }
            }

            if (best_idx == -1)
            {
                int next_arrival = -1;
                for (size_t i = 0; i < jobs.size(); ++i)
                {
                    if (remaining_burst[i] > 0 && (next_arrival == -1 || jobs[i].arrival < next_arrival))
                    {
                        next_arrival = jobs[i].arrival;
                    }
                }

                if (next_arrival == -1)
                    break;

                time = max(time, next_arrival);
                last_running_idx = -1;
                current_priority_left = 0;
                continue;
            }

            if (best_idx != last_running_idx)
            {
                last_running_idx = best_idx;
                current_priority_left = priority;
            }

            order.push_back(jobs[best_idx].id);
            time += 1;
            remaining_burst[best_idx] -= 1;
            current_priority_left -= 1;

            if (remaining_burst[best_idx] == 0)
            {
                completed++;
                last_running_idx = -1;
                current_priority_left = 0;
            }
            else if (current_priority_left == 0)
            {
                last_running_idx = -1;
            }
        }

        return order;
    }

    // =========================================================================
    //  Timeline engine shared by every policy that reports slices + statistics.
    // =========================================================================
    namespace
    {
        enum class Mode
        {
            FCFS,
            SJF,
            PRIORITY,
            RR,
            MLQ
        };

        void addSlice(ScheduleResult &r, int jobId, int start, int end, int queue)
        {
            // a job that simply keeps the CPU is one slice, not many
            if (!r.slices.empty() && r.slices.back().jobId == jobId && r.slices.back().end == start)
                r.slices.back().end = end;
            else
                r.slices.push_back({jobId, start, end, queue});
        }

        // Turns completion times into per-job statistics and the summary numbers.
        void finalize(ScheduleResult &r, const vector<Job> &jobs, const vector<int> &firstRun,
                      const vector<int> &completion, const vector<int> &levels, int idle)
        {
            double w = 0, t = 0, rs = 0;
            int count = 0;
            for (size_t i = 0; i < jobs.size(); ++i)
            {
                if (jobs[i].burst <= 0)
                    continue;
                JobStat s{};
                s.id = jobs[i].id;
                s.queue = levels[i];
                s.arrival = jobs[i].arrival;
                s.burst = jobs[i].burst;
                s.firstRun = firstRun[i];
                s.completion = completion[i];
                s.turnaround = s.completion - s.arrival;
                s.waiting = s.turnaround - s.burst;
                s.response = s.firstRun - s.arrival;
                r.stats.push_back(s);
                w += s.waiting;
                t += s.turnaround;
                rs += s.response;
                r.busyTicks += s.burst;
                r.makespan = max(r.makespan, s.completion);
                ++count;
            }
            if (count)
            {
                r.avgWaiting = w / count;
                r.avgTurnaround = t / count;
                r.avgResponse = rs / count;
            }
            r.idleTicks = idle;
            for (size_t i = 1; i < r.slices.size(); ++i)
                if (r.slices[i].jobId != r.slices[i - 1].jobId)
                    ++r.contextSwitches;
        }

        // Jobs with something to run, in (arrival, input order).
        vector<int> arrivalOrder(const vector<Job> &jobs)
        {
            vector<int> order;
            for (size_t i = 0; i < jobs.size(); ++i)
                if (jobs[i].burst > 0)
                    order.push_back(static_cast<int>(i));
            stable_sort(order.begin(), order.end(), [&](int a, int b)
                        { return jobs[a].arrival < jobs[b].arrival; });
            return order;
        }

        // FCFS, SJF (non-preemptive) and Priority (preemptive): pick from the ready set every tick.
        ScheduleResult simulatePicker(const string &name, Mode mode, const vector<Job> &jobs)
        {
            ScheduleResult res;
            res.algorithm = name;
            const size_t n = jobs.size();
            vector<int> rem(n, 0), firstRun(n, -1), completion(n, 0), levels(n, 0);
            for (size_t i = 0; i < n; ++i)
            {
                rem[i] = max(0, jobs[i].burst);
                levels[i] = CPUScheduler::queueLevel(jobs[i]);
            }
            const vector<int> order = arrivalOrder(jobs);
            if (order.empty())
            {
                finalize(res, jobs, firstRun, completion, levels, 0);
                return res;
            }

            vector<int> ready;
            size_t next = 0;
            size_t finished = 0;
            int t = jobs[order[0]].arrival, idle = 0, running = -1;
            auto admit = [&](int upto)
            {
                while (next < order.size() && jobs[order[next]].arrival <= upto)
                    ready.push_back(order[next++]);
            };
            // true when a beats b for the CPU
            auto better = [&](int a, int b)
            {
                switch (mode)
                {
                case Mode::SJF:
                    if (jobs[a].burst != jobs[b].burst)
                        return jobs[a].burst < jobs[b].burst;
                    break;
                case Mode::PRIORITY:
                    if (jobs[a].priority != jobs[b].priority)
                        return jobs[a].priority < jobs[b].priority;
                    if (a == running || b == running) // ties never cause a context switch
                        return a == running;
                    break;
                default:
                    break;
                }
                if (jobs[a].arrival != jobs[b].arrival)
                    return jobs[a].arrival < jobs[b].arrival;
                return a < b;
            };

            admit(t);
            while (finished < order.size())
            {
                if (ready.empty())
                { // CPU idles until the next arrival
                    const int nextArrival = jobs[order[next]].arrival;
                    idle += nextArrival - t;
                    t = nextArrival;
                    running = -1;
                    admit(t);
                    continue;
                }
                if (running == -1 || mode == Mode::PRIORITY)
                {
                    int best = ready.front();
                    for (int cand : ready)
                        if (better(cand, best))
                            best = cand;
                    running = best;
                }
                const int j = running;
                if (firstRun[j] < 0)
                    firstRun[j] = t;
                addSlice(res, jobs[j].id, t, t + 1, levels[j]);
                --rem[j];
                ++t;
                admit(t);
                if (rem[j] == 0)
                {
                    completion[j] = t;
                    ready.erase(find(ready.begin(), ready.end(), j));
                    ++finished;
                    running = -1;
                }
            }
            finalize(res, jobs, firstRun, completion, levels, idle);
            return res;
        }

        // Round Robin (one queue) and Multilevel Queue (three queues).
        ScheduleResult simulateQueues(const string &name, Mode mode, const vector<Job> &jobs, int quantum)
        {
            if (quantum <= 0)
                throw invalid_argument("Quantum must be greater than zero.");
            ScheduleResult res;
            res.algorithm = name;
            const size_t n = jobs.size();
            const int nq = mode == Mode::MLQ ? 3 : 1;
            const int unlimited = 1 << 30;
            // time slice per queue; Q2 of the MLQ is plain FCFS
            const int qt[3] = {quantum, mode == Mode::MLQ ? 2 * quantum : quantum, unlimited};

            vector<int> rem(n, 0), firstRun(n, -1), completion(n, 0), levels(n, 0);
            for (size_t i = 0; i < n; ++i)
            {
                rem[i] = max(0, jobs[i].burst);
                levels[i] = CPUScheduler::queueLevel(jobs[i]);
            }
            auto qidx = [&](int j)
            { return mode == Mode::MLQ ? levels[j] : 0; };

            const vector<int> order = arrivalOrder(jobs);
            if (order.empty())
            {
                finalize(res, jobs, firstRun, completion, levels, 0);
                return res;
            }

            deque<int> queues[3];
            size_t next = 0, finished = 0;
            int t = jobs[order[0]].arrival, idle = 0, running = -1, left = 0;
            auto admit = [&](int upto)
            {
                while (next < order.size() && jobs[order[next]].arrival <= upto)
                {
                    queues[qidx(order[next])].push_back(order[next]);
                    ++next;
                }
            };

            admit(t);
            while (finished < order.size())
            {
                int top = -1;
                for (int k = 0; k < nq; ++k)
                    if (!queues[k].empty())
                    {
                        top = k;
                        break;
                    }
                // a more urgent queue takes the CPU away; the victim keeps its place at the head of its queue
                if (running != -1 && top != -1 && top < qidx(running))
                {
                    queues[qidx(running)].push_front(running);
                    running = -1;
                }
                if (running == -1)
                {
                    if (top == -1)
                    { // nothing ready: idle until the next arrival
                        const int nextArrival = jobs[order[next]].arrival;
                        idle += nextArrival - t;
                        t = nextArrival;
                        admit(t);
                        continue;
                    }
                    running = queues[top].front();
                    queues[top].pop_front();
                    left = qt[top];
                }
                const int j = running, k = qidx(j);
                if (firstRun[j] < 0)
                    firstRun[j] = t;
                addSlice(res, jobs[j].id, t, t + 1, levels[j]);
                --rem[j];
                --left;
                ++t;
                admit(t); // arrivals line up before a job whose quantum just ran out
                if (rem[j] == 0)
                {
                    completion[j] = t;
                    ++finished;
                    running = -1;
                }
                else if (left <= 0)
                {
                    queues[k].push_back(j);
                    running = -1;
                }
            }
            finalize(res, jobs, firstRun, completion, levels, idle);
            return res;
        }

        vector<int> idsOf(const ScheduleResult &r)
        {
            vector<int> ids;
            for (const auto &s : r.slices)
                ids.push_back(s.jobId);
            return ids;
        }

        string upper(string s)
        {
            for (auto &c : s)
                c = static_cast<char>(toupper(static_cast<unsigned char>(c)));
            return s;
        }
    } // namespace

    int CPUScheduler::queueLevel(const Job &job)
    {
        if (job.queue >= 0 && job.queue < 3)
            return job.queue;
        if (job.priority <= 1)
            return 0;
        return job.priority == 2 ? 1 : 2;
    }

    ScheduleResult CPUScheduler::scheduleFCFS(vector<Job> jobs) { return simulatePicker("FCFS", Mode::FCFS, jobs); }
    ScheduleResult CPUScheduler::scheduleSJF(vector<Job> jobs) { return simulatePicker("SJF", Mode::SJF, jobs); }
    ScheduleResult CPUScheduler::schedulePriority(vector<Job> jobs) { return simulatePicker("PRIORITY", Mode::PRIORITY, jobs); }
    ScheduleResult CPUScheduler::scheduleRoundRobin(vector<Job> jobs, int quantum) { return simulateQueues("RR", Mode::RR, jobs, quantum); }
    ScheduleResult CPUScheduler::scheduleMLQ(vector<Job> jobs, int quantum) { return simulateQueues("MLQ", Mode::MLQ, jobs, quantum); }
    vector<int> CPUScheduler::roundRobin(vector<Job> jobs, int quantum) { return idsOf(scheduleRoundRobin(std::move(jobs), quantum)); }
    vector<int> CPUScheduler::multilevelQueue(vector<Job> jobs, int quantum) { return idsOf(scheduleMLQ(std::move(jobs), quantum)); }

    ScheduleResult CPUScheduler::run(const string &algorithm, vector<Job> jobs, int quantum)
    {
        const string a = upper(algorithm);
        if (a == "FCFS")
            return scheduleFCFS(std::move(jobs));
        if (a == "SJF")
            return scheduleSJF(std::move(jobs));
        if (a == "PRIORITY")
            return schedulePriority(std::move(jobs));
        if (a == "RR")
            return scheduleRoundRobin(std::move(jobs), quantum);
        if (a == "MLQ")
            return scheduleMLQ(std::move(jobs), quantum);
        throw invalid_argument("Unknown scheduling algorithm: " + algorithm);
    }
} // namespace nexora
