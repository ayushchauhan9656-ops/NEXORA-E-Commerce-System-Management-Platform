'use strict';
// NEXORA admin console - store management views and database tracking.

// ============================================================ Orders
const ORDER_STATUSES = ['PLACED', 'PROCESSING', 'SHIPPED', 'DELIVERED', 'CANCELLED'];
const orderTone = { PLACED: 'q0', PROCESSING: 'warn', SHIPPED: 'q1', DELIVERED: 'good', CANCELLED: 'bad' };
VIEWS.orders = {
  title: 'Orders', every: 4, rows: [],
  mount(root) {
    root.innerHTML = `<h1>Orders</h1><p class="sub">Change an order's status here and the customer sees it on their orders page. Every change is stored in the order's status history. Cancelling returns the items to stock.</p>
      <div class="bar"><div><label for="or-s">Status</label><select id="or-s"><option value="">All</option>${ORDER_STATUSES.map((s) => `<option>${s}</option>`).join('')}</select></div><span class="msg" id="or-msg" role="status"></span></div><div id="or-tbl"></div>`;
    $('#or-s').addEventListener('change', () => this.load());
    $('#or-tbl').addEventListener('change', async (e) => {
      const sel = e.target.closest('select[data-o]'); if (!sel) return;
      try { await aj('PATCH', '/api/admin/orders/' + sel.dataset.o, { status: sel.value }); say($('#or-msg'), `Order #${sel.dataset.o} is now ${sel.value.toLowerCase()}.`, 'ok'); } catch (err) { say($('#or-msg'), err.message, 'err'); }
      this.load();
    });
  },
  async load() {
    const st = $('#or-s'); if (!st) return;
    this.rows = (await aget('/api/admin/orders' + (st.value ? '?status=' + st.value : ''))).orders; this.tick();
  },
  tick() {
    const host = $('#or-tbl'); if (!host || host.contains(document.activeElement) && document.activeElement.tagName === 'SELECT') return; // don't redraw under an open dropdown
    dataTable(host, [
      { k: 'id', label: 'Order', num: true, f: (o) => '#' + o.id }, { k: 'createdAt', label: 'Placed', f: (o) => dateTime(o.createdAt) },
      { k: 'customer', label: 'Customer', f: (o) => `${esc(o.customer)}<div class="muted">${esc(o.email)}</div>` },
      { k: 'items', label: 'Items', sort: false, cls: 'wrapcell', f: (o) => o.items.map((i) => `${i.qty} × ${esc(i.name)}`).join('<br>') },
      { k: 'total', label: 'Total', num: true, f: (o) => usd(o.total) }, { k: 'address', label: 'Ship to', cls: 'wrapcell' },
      { k: 'status', label: 'Status', f: (o) => `${chip(o.status.toLowerCase(), orderTone[o.status])}<div><select data-o="${o.id}" aria-label="Status of order ${o.id}" ${['CANCELLED', 'DELIVERED'].includes(o.status) ? 'disabled' : ''}>${ORDER_STATUSES.map((s) => `<option ${s === o.status ? 'selected' : ''}>${s}</option>`).join('')}</select></div>` },
      { k: 'history', label: 'History', sort: false, cls: 'wrapcell', f: (o) => o.history.map((h) => `<div class="muted">${esc(h.status.toLowerCase())} · ${clockTime(h.at)}</div>`).join('') },
    ], this.rows, { empty: 'No orders yet. They appear here the moment a customer checks out.', maxHeight: 640 });
  },
};

// ============================================================ Products & stock
VIEWS.products = {
  title: 'Products & stock', every: 5, rows: [], moves: [],
  mount(root) {
    root.innerHTML = `<h1>Products & stock</h1><p class="sub">Edit price and stock inline. Every stock change, from an order, a cancellation or your own adjustment, is recorded in the movement log below.</p>
      <form class="panel bar" id="pd-add" style="align-items:end"><div><label for="pd-n">Name</label><input id="pd-n" required maxlength="170" style="min-width:210px"></div><div><label for="pd-c">Category</label><input id="pd-c" placeholder="Electronics" style="width:140px"></div>
        <div><label for="pd-p">Price ($)</label><input id="pd-p" type="number" min="0" step="0.01" required></div><div><label for="pd-s">Stock</label><input id="pd-s" type="number" min="0" required></div><button class="primary" type="submit">Add product</button><span class="msg" id="pd-msg" role="status"></span></form>
      <div style="margin-top:14px" id="pd-tbl"></div><h2 style="margin-top:20px">Stock movement log</h2><div id="pd-mv"></div>`;
    $('#pd-add').addEventListener('submit', async (e) => {
      e.preventDefault();
      try { await aj('POST', '/api/admin/products', { name: $('#pd-n').value, category: $('#pd-c').value, price: Number($('#pd-p').value), stock: Number($('#pd-s').value) }); e.target.reset(); say($('#pd-msg'), 'Product added.', 'ok'); this.load(); } catch (err) { say($('#pd-msg'), err.message, 'err'); }
    });
    $('#pd-tbl').addEventListener('click', async (e) => {
      const b = e.target.closest('button[data-act]'); if (!b) return;
      const id = b.dataset.id, row = b.closest('tr');
      try {
        if (b.dataset.act === 'save') { await aj('PATCH', '/api/admin/products/' + id, { price: Number(row.querySelector('[data-f=price]').value), stock: Number(row.querySelector('[data-f=stock]').value), available: row.querySelector('[data-f=available]').checked }); say($('#pd-msg'), `Saved product #${id}.`, 'ok'); }
        else if (confirm('Remove this product? Products that have been ordered are hidden instead, so order history stays intact.')) { const r = await aj('DELETE', '/api/admin/products/' + id); say($('#pd-msg'), r.hidden ? `Product #${id} has orders, so it was hidden instead.` : `Deleted product #${id}.`, 'ok'); }
        this.load();
      } catch (err) { say($('#pd-msg'), err.message, 'err'); }
    });
  },
  async load() {
    const [p, m] = await Promise.all([aget('/api/admin/products'), aget('/api/admin/inventory/movements?limit=80')]);
    this.rows = p.products; this.moves = m.movements;
    const host = $('#pd-tbl'); if (!host) return;
    if (host.contains(document.activeElement) && document.activeElement.tagName === 'INPUT') return; // never redraw while typing
    dataTable(host, [
      { k: 'id', label: 'ID', num: true }, { k: 'name', label: 'Product' }, { k: 'category', label: 'Category' },
      { k: 'price', label: 'Price ($)', num: true, f: (p) => `<input data-f="price" type="number" min="0" step="0.01" value="${p.price}" style="width:90px" aria-label="Price of ${esc(p.name)}">` },
      { k: 'quantity', label: 'In stock', num: true, f: (p) => `<input data-f="stock" type="number" min="0" value="${p.quantity}" style="width:80px" aria-label="Stock of ${esc(p.name)}">${p.quantity <= p.reorderLevel ? ' ' + chip('low', 'warn') : ''}` },
      { k: 'available', label: 'On sale', f: (p) => `<input data-f="available" type="checkbox" ${p.available ? 'checked' : ''} aria-label="${esc(p.name)} is on sale">`, v: (p) => p.available },
      { k: 'act', label: '', sort: false, f: (p) => `<button class="small primary" data-act="save" data-id="${p.id}" type="button">Save</button> <button class="small danger" data-act="del" data-id="${p.id}" type="button">Remove</button>` },
    ], this.rows, { maxHeight: 460 });
    dataTable($('#pd-mv'), [
      { k: 'at', label: 'Time', f: (x) => dateTime(x.at) }, { k: 'product', label: 'Product' }, { k: 'delta', label: 'Change', num: true, f: (x) => `<b style="color:${x.delta < 0 ? 'var(--bad)' : 'var(--good)'}">${x.delta > 0 ? '+' : ''}${x.delta}</b>` },
      { k: 'quantityAfter', label: 'Stock after', num: true }, { k: 'reason', label: 'Reason', f: (x) => chip(x.reason.replace(/_/g, ' ').toLowerCase()) }, { k: 'orderId', label: 'Order', num: true, f: (x) => (x.orderId ? '#' + x.orderId : '') }, { k: 'email', label: 'By' },
    ], this.moves, { maxHeight: 340, empty: 'No stock movements yet.' });
  },
  tick() {},
};

// ============================================================ Customers & logins
VIEWS.customers = {
  title: 'Customers & logins', every: 5, users: [], logins: null,
  mount(root) {
    root.innerHTML = `<h1>Customers & logins</h1><p class="sub">Accounts, every sign-in attempt (successful or not) and the sessions open right now. Deactivating a customer signs them out immediately.</p>
      <div class="msg" id="cu-msg" role="status"></div><h2>Customers</h2><div id="cu-users"></div>
      <div class="row cols-2" style="margin-top:18px"><div><h2>Sign-in attempts</h2><div id="cu-logins"></div></div><div><h2>Open sessions</h2><div id="cu-sess"></div></div></div>`;
    $('#cu-users').addEventListener('click', async (e) => {
      const b = e.target.closest('button[data-u]'); if (!b) return;
      try { await aj('PATCH', '/api/admin/users/' + b.dataset.u, { active: b.dataset.on === '1' }); say($('#cu-msg'), 'Account updated.', 'ok'); this.load(); } catch (err) { say($('#cu-msg'), err.message, 'err'); }
    });
  },
  async load() {
    const [u, l] = await Promise.all([aget('/api/admin/users'), aget('/api/admin/logins?limit=80')]);
    if (!$('#cu-users')) return;
    dataTable($('#cu-users'), [
      { k: 'id', label: 'ID', num: true }, { k: 'name', label: 'Name' }, { k: 'email', label: 'Email' }, { k: 'role', label: 'Role', f: (x) => chip(x.role.toLowerCase(), x.role === 'ADMIN' ? 'q0' : '') },
      { k: 'orders', label: 'Orders', num: true }, { k: 'spent', label: 'Spent', num: true, f: (x) => usd(x.spent) }, { k: 'createdAt', label: 'Joined', f: (x) => dateTime(x.createdAt) },
      { k: 'lastLogin', label: 'Last sign-in', f: (x) => (x.lastLogin ? dateTime(x.lastLogin) : 'never') }, { k: 'active', label: 'Status', f: (x) => chip(x.active ? 'active' : 'deactivated', x.active ? 'good' : 'bad') },
      { k: 'act', label: '', sort: false, f: (x) => (x.role === 'ADMIN' ? '' : `<button class="small ${x.active ? 'danger' : ''}" data-u="${x.id}" data-on="${x.active ? 0 : 1}" type="button">${x.active ? 'Deactivate' : 'Reactivate'}</button>`) },
    ], u.users, { maxHeight: 360, empty: 'No customers have registered yet.' });
    dataTable($('#cu-logins'), [
      { k: 'at', label: 'Time', f: (x) => dateTime(x.at) }, { k: 'email', label: 'Email' }, { k: 'success', label: 'Result', f: (x) => (x.success ? chip('success', 'good') : chip((x.reason || 'failed').replace(/_/g, ' ').toLowerCase(), 'bad')) }, { k: 'ip', label: 'IP', cls: 'mono' },
    ], l.logins, { maxHeight: 360, empty: 'No sign-in attempts yet.' });
    dataTable($('#cu-sess'), [
      { k: 'email', label: 'Account' }, { k: 'role', label: 'Role', f: (x) => chip(x.role.toLowerCase(), x.role === 'ADMIN' ? 'q0' : '') }, { k: 'createdAt', label: 'Signed in', f: (x) => dateTime(x.createdAt) }, { k: 'lastSeen', label: 'Last seen', f: (x) => dateTime(x.lastSeen) }, { k: 'ip', label: 'IP', cls: 'mono' },
    ], l.sessions, { maxHeight: 360, empty: 'Nobody is signed in.' });
  },
  tick() {},
};

// ============================================================ Security
VIEWS.security = {
  title: 'Security', every: 4, rows: [], open: true,
  mount(root) {
    root.innerHTML = `<h1>Security</h1><p class="sub">Raised automatically: failed sign-ins, lock-outs, checkout attempts without an account, unauthorised admin calls, low stock and deadlocks. Mark an item resolved once you have dealt with it.</p>
      <div class="bar"><div><label><input type="checkbox" id="se-open" checked> Show unresolved only</label></div><span class="msg" id="se-msg" role="status"></span></div><div id="se-tbl"></div>`;
    $('#se-open').addEventListener('change', (e) => { this.open = e.target.checked; this.tick(); });
    $('#se-tbl').addEventListener('click', async (e) => {
      const b = e.target.closest('button[data-r]'); if (!b) return;
      try { await aj('POST', `/api/admin/security/${b.dataset.r}/resolve`); say($('#se-msg'), 'Marked resolved.', 'ok'); this.load(); } catch (err) { say($('#se-msg'), err.message, 'err'); }
    });
  },
  async load() { this.rows = (await aget('/api/admin/security?limit=300')).events; this.tick(); },
  tick() {
    if (!$('#se-tbl')) return;
    dataTable($('#se-tbl'), [
      { k: 'at', label: 'Time', f: (x) => dateTime(x.at) }, { k: 'severity', label: 'Severity', f: (x) => chip(x.severity.toLowerCase(), sevClass[x.severity]), v: (x) => ['LOW', 'MEDIUM', 'HIGH', 'CRITICAL'].indexOf(x.severity) },
      { k: 'type', label: 'Type', f: (x) => esc(x.type.replace(/_/g, ' ').toLowerCase()) }, { k: 'message', label: 'Details', cls: 'wrapcell' }, { k: 'risk', label: 'Risk', num: true, f: (x) => nf(x.risk) },
      { k: 'resolved', label: '', sort: false, f: (x) => (x.resolved ? chip('resolved', 'good') : `<button class="small" data-r="${x.id}" type="button">Mark resolved</button>`) },
    ], this.rows.filter((x) => !this.open || !x.resolved), { maxHeight: 640, empty: this.open ? 'Nothing needs attention.' : 'No security events yet.' });
  },
};

// ============================================================ Database tracking
const TRACKED = [
  ['auditRows', 'audit_logs', 'who did what, with IP and OS job'], ['loginRows', 'login_history', 'every sign-in attempt'], ['statusChanges', 'order_status_history', 'every order status change'],
  ['movements', 'inventory_movements', 'every stock change and why'], ['trackedJobs', 'os_jobs', 'one row per OS job: queue, wait, faults'], ['trackedRuns', 'os_runs', 'one row per scheduling run'],
  ['metricSamples', 'os_metrics', 'CPU / memory / disk samples (the graphs)'], ['osEvents', 'os_events', 'the OS monitor event log'],
];
VIEWS.tracking = {
  title: 'Database tracking', every: 3, rows: [],
  mount(root) {
    root.innerHTML = `<h1>Database tracking</h1><p class="sub">Nothing here is only on screen. The data store records activity as it happens, and OS-engine results are written to the database a few seconds after each job.</p>
      <div class="row cols-4" id="tk-tiles"></div>
      <div class="panel" style="margin-top:14px"><div class="bar" style="margin:0 0 8px"><div><label for="tk-t">OS jobs of type</label><select id="tk-t"><option value="">All</option>${['BROWSE', 'CART', 'LOGIN', 'REGISTER', 'LOGOUT', 'CHECKOUT', 'STOCK_UPDATE', 'ORDER_UPDATE', 'ADMIN_ACTION', 'REPORT', 'AUDIT_FLUSH'].map((t) => `<option>${t}</option>`).join('')}</select></div><span class="msg" id="tk-pending"></span></div><div id="tk-jobs"></div></div>`;
    $('#tk-t').addEventListener('change', () => this.load());
  },
  async load() {
    const sel = $('#tk-t'); if (!sel) return;
    const r = await aget('/api/admin/jobs?limit=150' + (sel.value ? '&type=' + sel.value : '')); this.rows = r.jobs;
    say($('#tk-pending'), r.pendingWrites ? `${r.pendingWrites} job result${r.pendingWrites === 1 ? '' : 's'} waiting to be written` : 'Up to date');
    this.tick();
  },
  tick() {
    const st = A.stats; if (!st || !$('#tk-tiles')) return;
    $('#tk-tiles').innerHTML = TRACKED.map(([k, t, d]) => tile(t, nf(st[k]), d)).join('');
    dataTable($('#tk-jobs'), [
      { k: 'job_id', label: 'Job', num: true }, { k: 'pid', label: 'PID', num: true }, { k: 'job_type', label: 'Type' }, { k: 'source', label: 'Source', f: (j) => chip(j.source.toLowerCase(), j.source === 'SIMULATION' ? 'warn' : j.source === 'ADMIN' ? 'q0' : j.source === 'SYSTEM' ? '' : 'good') },
      { k: 'email', label: 'User', f: (j) => esc(j.email || (j.user_id ? '#' + j.user_id : '')) }, { k: 'http_path', label: 'Request', cls: 'mono', f: (j) => (j.http_path ? `${esc(j.http_method)} ${esc(j.http_path)}` : '') },
      { k: 'status_code', label: 'HTTP', num: true }, { k: 'queue_level', label: 'Queue', f: (j) => (j.queue_level == null ? '' : qchip(j.queue_level)) },
      { k: 'wait_ticks', label: 'Wait', num: true }, { k: 'turnaround', label: 'Turnaround', num: true }, { k: 'page_faults', label: 'Faults', num: true },
      { k: 'algorithm', label: 'Policy' }, { k: 'run_id', label: 'Run', num: true }, { k: 'created_at', label: 'Saved', f: (j) => clockTime(j.created_at) },
    ], this.rows, { maxHeight: 560, empty: 'No jobs saved yet. Use the store, or run a load test from the CPU scheduler page.' });
  },
};
