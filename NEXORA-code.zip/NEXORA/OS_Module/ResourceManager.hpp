#pragma once
#include <vector>
using namespace std;
namespace nexora
{
    // Deadlock detection on a resource-allocation matrix (one row per process, one column
    // per resource; here: one column per product lock).
    class ResourceManager
    {
    public:
        // Deadlock-state check; true means at least one process cannot finish.
        static bool hasDeadlock(const vector<int> &available,
                                const vector<vector<int>> &allocation,
                                const vector<vector<int>> &request);

        // Indices of the processes that can never finish (empty = no deadlock).
        static vector<int> deadlockedProcesses(const vector<int> &available,
                                               const vector<vector<int>> &allocation,
                                               const vector<vector<int>> &request);
    };
}
