'use strict';
// Customer sign in + account creation. A guest cart is merged into the account cart on success.
const params = new URLSearchParams(location.search);
const next = safeNext(params.get('next'));
const forms = { signin: document.getElementById('signin'), register: document.getElementById('register') };
const tabs = { signin: document.getElementById('tab-signin'), register: document.getElementById('tab-register') };

function show(which) {
  for (const k of Object.keys(forms)) { forms[k].hidden = k !== which; tabs[k].setAttribute('aria-selected', String(k === which)); }
  document.getElementById('heading').textContent = which === 'register' ? 'Create your account' : 'Welcome back';
  document.getElementById('sub').textContent = which === 'register'
    ? 'You need an account to place an order. It takes under a minute.'
    : 'Sign in to check out and track your orders.';
}
tabs.signin.addEventListener('click', () => show('signin'));
tabs.register.addEventListener('click', () => show('register'));

async function finish() {
  const items = guestCart.get();
  if (items.length) {
    try { await API.post('/api/cart/merge', { items }); guestCart.clear(); } catch { /* cart stays in the browser */ }
  }
  location.href = next;
}

async function submit(form, errId, path, body) {
  const err = document.getElementById(errId), btn = form.querySelector('button[type=submit]');
  err.textContent = ''; btn.disabled = true;
  try { await API.post(path, body); await finish(); }
  catch (e) {
    err.textContent = e.message;
    if (e.code === 'EMAIL_TAKEN') show('signin');
    btn.disabled = false;
  }
}
forms.signin.addEventListener('submit', (e) => {
  e.preventDefault();
  submit(forms.signin, 'si-err', '/api/auth/login', { email: document.getElementById('si-email').value, password: document.getElementById('si-pass').value });
});
forms.register.addEventListener('submit', (e) => {
  e.preventDefault();
  submit(forms.register, 'rg-err', '/api/auth/register', {
    name: document.getElementById('rg-name').value, email: document.getElementById('rg-email').value, password: document.getElementById('rg-pass').value });
});
window.pageReady = () => {
  if (session.user) return finish(); // already signed in
  show(params.get('tab') === 'register' ? 'register' : 'signin');
};
