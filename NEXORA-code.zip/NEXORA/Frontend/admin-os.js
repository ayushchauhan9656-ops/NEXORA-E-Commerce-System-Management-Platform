'use strict';
// NEXORA admin console - views that show the OS engine (CPU, memory, disk, locks, IPC).

const snap = () => (A.os && A.os.snapshot) || null;
const offline = '<div class="panel"><div class="empty">The OS engine is offline, so there is nothing live to show. Start the backend with <code>npm start</code> in the Backend folder; it compiles and launches the C++ engine.</div></div>';

// ============================================================ Overview
VIEWS.overview = {
  title: 'Overview', every: 3,
  mount(root) {
    root.innerHTML = `
      <h1>System overview</h1>
      <p class="sub">Every click in the store and every action in this console becomes a job. The OS engine schedules it, gives it memory, locks, and a disk write, and the data store keeps the record.</p>
      <div class="row cols-4" id="ov-kpi"></div>
      <div class="panel arch" style="margin-top:14px">
        <div class="box" style="text-align:center"><h2 style="margin:0">NEXORA Storefront + Admin Panel</h2><div class="muted">Products · Cart · Checkout · Inventory · Order management</div></div>
        <div class="flow">⇅ Every operation becomes a managed workload</div>
        <div class="box engine"><h2>NEXORA OS Engine</h2><div class="row cols-2" id="ov-mods"></div></div>
        <div class="flow">↓</div>
        <div class="box" style="text-align:center"><h2 style="margin:0">NEXORA Data Store</h2><div class="muted" id="ov-store">Orders · Inventory · Users · Sessions · Audit logs · OS tracking</div></div>
      </div>
      <div class="row cols-2" style="margin-top:14px">
        <div class="panel"><h2>CPU utilisation</h2><div id="ov-cpu"></div></div>
        <div class="panel"><h2>Memory in use</h2><div id="ov-mem"></div></div>
      </div>
      <div class="panel" style="margin-top:14px"><h2>Latest activity</h2><div id="ov-feed"></div></div>`;
    this.cpu = new LineChart($('#ov-cpu'), { series: [{ name: 'CPU', key: 'cpu', color: 'var(--s1)' }], yMax: 100, fmt: (v) => nf(v) + '%', height: 170, label: 'CPU utilisation over time' });
    this.mem = new LineChart($('#ov-mem'), { series: [{ name: 'Memory', key: 'mem', color: 'var(--s3)' }], yMax: 100, fmt: (v) => nf(v) + '%', height: 170, label: 'Memory use over time' });
    this.feed = [];
  },
  async load() { try { this.feed = (await aget('/api/admin/activity?limit=8')).events; } catch { /* ignore */ } },
  tick() {
    const st = A.stats, s = snap();
    if (st) {
      $('#ov-kpi').innerHTML = tile('Customers', nf(st.customers), `${nf(st.activeSessions)} signed in now`) + tile('Orders', nf(st.orders), `${nf(st.orders24h)} in the last 24 h`)
        + tile('Revenue', usd(st.revenue), 'cancelled orders excluded') + tile('Needs attention', nf(st.openSecurity + st.lowStock), `${nf(st.openSecurity)} security · ${nf(st.lowStock)} low stock`);
      $('#ov-store').innerHTML = `Orders <b>${nf(st.orders)}</b> · Inventory <b>${nf(st.products)}</b> products · Users <b>${nf(st.customers)}</b> · Audit logs <b>${nf(st.auditRows)}</b> · OS jobs tracked <b>${nf(st.trackedJobs)}</b> · Metric samples <b>${nf(st.metricSamples)}</b>`;
    }
    const mods = s ? [
      ['processes', 'Process Manager', 'Runs order, checkout, inventory and admin jobs.', `<b>${nf(s.processes.length)}</b> live · <b>${nf(s.cpu.completed)}</b> finished`],
      ['scheduler', 'CPU Scheduler', 'Prioritizes urgent checkout and stock-update tasks.', `<b>${s.algorithm}</b>${['RR', 'MLQ'].includes(s.algorithm) ? ' q=' + s.quantum : ''} · Q0/Q1/Q2 done <b>${s.cpu.queues.join(' / ')}</b> · avg wait <b>${nf(s.cpu.avgWait, 1)}</b>`],
      ['memory', 'Memory Manager', 'Manages simulated memory for active carts and jobs.', `<b>${kb(s.memory.used)}</b> of ${kb(s.memory.total)} · LRU evictions <b>${nf(s.memory.evictions)}</b>`],
      ['resources', 'Resource & Deadlock Manager', 'Controls competing stock and checkout operations.', `deadlocks <b>${nf(s.resources.deadlocks)}</b> · rollbacks <b>${nf(s.resources.rollbacks)}</b> · lock waits <b>${nf(s.resources.lockWaits)}</b>`],
      ['disk', 'Disk & Audit Manager', 'Schedules simulated log and data-storage operations.', `SSTF <b>${nf(s.disk.sstfTotal)}</b> vs FCFS <b>${nf(s.disk.fcfsTotal)}</b> cylinders · head at <b>${s.disk.head}</b>`],
      ['ipc', 'IPC & Process Monitor', 'Coordinates jobs and tracks their status and output.', `messages <b>${nf(s.ipc.sent)}</b> sent / <b>${nf(s.ipc.received)}</b> received · <b>${nf(s.monitor.count)}</b> events`],
    ] : [];
    $('#ov-mods').innerHTML = s ? mods.map(([id, name, desc, live]) => `<a class="mod" href="#${id}"><h3>${name}</h3><p>${desc}</p><div class="live">${live}</div></a>`).join('') : offline;
    this.cpu.update(A.pts); this.mem.update(A.pts);
    dataTable($('#ov-feed'), [
      { k: 'at', label: 'Time', f: (e) => clockTime(e.at), sort: false }, { k: 'type', label: 'Event', f: (e) => chip(e.type.replace(/_/g, ' ').toLowerCase()), sort: false },
      { k: 'who', label: 'By', f: (e) => esc(e.name || e.email || 'system'), sort: false }, { k: 'details', label: 'What happened', cls: 'wrapcell', sort: false },
    ], this.feed, { empty: 'No activity yet. Browse the store, sign up or place an order.' });
  },
};

// ============================================================ Performance (Task Manager style)
const PERF = [
  { id: 'cpu', name: 'CPU', key: 'cpu', color: 'var(--s1)', yMax: 100, fmt: (v) => nf(v) + '%', val: (l) => nf(l.cpu) + '%',
    sub: (s) => `${s.algorithm}${['RR', 'MLQ'].includes(s.algorithm) ? ' · q=' + s.quantum : ''}`,
    rows: (s, l) => [['Utilisation', nf(l.cpu, 1) + '%'], ['Busy ticks', nf(s.cpu.busy)], ['Idle ticks', nf(s.cpu.idle)], ['Context switches', nf(s.cpu.ctx)], ['Jobs finished', nf(s.cpu.completed)], ['Avg wait (ticks)', nf(s.cpu.avgWait, 2)], ['Avg turnaround', nf(s.cpu.avgTurnaround, 2)], ['Scheduler runs', nf(s.cpu.runs)]] },
  { id: 'mem', name: 'Memory', key: 'mem', color: 'var(--s3)', yMax: 100, fmt: (v) => nf(v) + '%', val: (l) => nf(l.mem) + '%',
    sub: (s) => `${kb(s.memory.used)} / ${kb(s.memory.total)}`,
    rows: (s) => [['In use', kb(s.memory.used)], ['Available', kb(s.memory.available)], ['Total', kb(s.memory.total)], ['Resident blocks', nf(s.memory.blocks.length)], ['LRU evictions', nf(s.memory.evictions)], ['Page frames', `${s.memory.frames.resident.length} / ${s.memory.frames.capacity}`]] },
  { id: 'faults', name: 'Paging', key: 'faults', color: 'var(--s4)', fmt: (v) => nf(v, 0) + '/s', val: (l) => nf(l.faults) + '/s',
    sub: (s) => `${nf(s.memory.frames.faults)} faults total`,
    rows: (s) => { const f = s.memory.frames, tot = f.hits + f.faults; return [['Page hits', nf(f.hits)], ['Page faults', nf(f.faults)], ['Hit rate', tot ? nf((f.hits * 100) / tot, 1) + '%' : '–'], ['LRU faults (recent refs)', nf(f.lruFaults)], ['FIFO faults (same refs)', nf(f.fifoFaults)], ['Frames', nf(f.capacity)]]; } },
  { id: 'disk', name: 'Disk', key: 'head', color: 'var(--s2)', yMax: 200, fmt: (v) => 'cyl ' + nf(v), val: (l) => 'cyl ' + nf(l.head),
    sub: (s) => `SSTF saved ${s.disk.fcfsTotal ? nf(100 - (s.disk.sstfTotal * 100) / s.disk.fcfsTotal, 0) : 0}%`,
    rows: (s) => [['Head position', 'cylinder ' + s.disk.head], ['Batches scheduled', nf(s.disk.runs)], ['SSTF head travel', nf(s.disk.sstfTotal)], ['FCFS head travel (same writes)', nf(s.disk.fcfsTotal)], ['Last batch SSTF / FCFS', `${s.disk.lastSstf} / ${s.disk.lastFcfs}`]] },
  { id: 'jps', name: 'Throughput', key: 'jps', color: 'var(--s5)', fmt: (v) => nf(v, 1) + '/s', val: (l) => nf(l.jps, 1) + '/s',
    sub: (s) => `${nf(s.cpu.completed)} jobs done`,
    rows: (s, l) => [['Jobs per second', nf(l.jps, 1)], ['Jobs finished', nf(s.cpu.completed)], ['Waiting for a run', nf(s.cpu.pending)], ['Live processes', nf(s.processes.length)], ['IPC messages', nf(s.ipc.sent)]] },
  { id: 'dead', name: 'Deadlocks', key: 'deadlocks', color: 'var(--bad)', fmt: (v) => nf(v), val: (l) => nf(l.deadlocks),
    sub: (s) => `${nf(s.resources.rollbacks)} rollbacks`,
    rows: (s) => [['Deadlocks detected', nf(s.resources.deadlocks)], ['Rollbacks', nf(s.resources.rollbacks)], ['Lock waits', nf(s.resources.lockWaits)]] },
];
VIEWS.performance = {
  title: 'Performance', sel: 'cpu',
  mount(root) {
    root.innerHTML = `<h1>Performance</h1><p class="sub">Live, one sample per second. Pick a resource on the left, like Task Manager. Hover a graph for exact values.</p>
      <div class="perf"><div class="perf-list" id="pf-list">${PERF.map((p) => `<button type="button" class="perf-item" data-p="${p.id}" aria-pressed="${p.id === this.sel}"><span class="sp"></span><span><b>${p.name}<span class="pv"></span></b><span class="ps"></span></span></button>`).join('')}</div>
      <div class="panel"><div style="display:flex;justify-content:space-between;align-items:baseline;flex-wrap:wrap"><h2 id="pf-title" style="margin:0"></h2><span class="big" id="pf-big"></span></div><div id="pf-chart" style="margin:10px 0"></div><div class="row cols-4" id="pf-rows"></div></div></div>`;
    $('#pf-list').addEventListener('click', (e) => { const b = e.target.closest('[data-p]'); if (!b) return; this.sel = b.dataset.p; root.querySelectorAll('.perf-item').forEach((x) => x.setAttribute('aria-pressed', String(x === b))); this.makeChart(); this.tick(); });
    this.makeChart();
  },
  makeChart() {
    const p = PERF.find((x) => x.id === this.sel);
    $('#pf-title').textContent = p.name; $('#pf-chart').innerHTML = '';
    const series = p.id === 'disk' ? [{ name: 'Head position', key: 'head', color: p.color }, { name: 'Travel this second', key: 'moved', color: 'var(--s1)' }] : [{ name: p.name, key: p.key, color: p.color }];
    this.chart = new LineChart($('#pf-chart'), { series, yMax: p.id === 'disk' ? 200 : p.yMax, fmt: p.fmt, height: 260, label: p.name + ' over time' });
  },
  tick() {
    const s = snap(); if (!s) { $('#pf-rows').innerHTML = offline; return; }
    const l = A.pts[A.pts.length - 1] || {};
    document.querySelectorAll('.perf-item').forEach((b, i) => {
      const p = PERF[i], vals = A.pts.slice(-40).map((x) => x[p.key] || 0);
      b.querySelector('.sp').innerHTML = sparkline(vals, p.color, p.yMax);
      b.querySelector('.pv').textContent = '  ' + p.val(l); b.querySelector('.ps').textContent = p.sub(s);
    });
    const p = PERF.find((x) => x.id === this.sel);
    $('#pf-big').textContent = p.val(l);
    $('#pf-rows').innerHTML = p.rows(s, l).map(([k, v]) => `<div class="tile"><div class="l">${k}</div><div class="n" style="font-size:19px">${v}</div></div>`).join('');
    this.chart.update(A.pts);
  },
};

// ============================================================ Processes
VIEWS.processes = {
  title: 'Processes', filter: 'ALL',
  mount(root) {
    root.innerHTML = `<h1>Processes</h1><p class="sub">Every job is a process with a PID. Daemons stay resident; request jobs are created, scheduled and terminated in milliseconds, so recent ones are listed too.</p>
      <div class="bar"><div><label for="pr-f">Show</label><select id="pr-f"><option value="ALL">Everything</option><option value="LIVE">Live processes</option><option value="DONE">Recently finished</option></select></div>
      <div><label for="pr-t">Job type</label><select id="pr-t"><option value="">All types</option></select></div></div><div id="pr-tbl"></div>`;
    $('#pr-f').value = this.filter;
    $('#pr-f').addEventListener('change', (e) => { this.filter = e.target.value; this.tick(); });
    $('#pr-t').addEventListener('change', () => this.tick());
  },
  tick() {
    const s = snap(); if (!s) { $('#pr-tbl').innerHTML = offline; return; }
    let rows = [...s.processes, ...s.recent.map((r) => ({ ...r, state: 'TERMINATED' }))];
    const types = [...new Set(rows.map((r) => r.type))].sort(), sel = $('#pr-t');
    if (sel.options.length - 1 !== types.length) { const cur = sel.value; sel.innerHTML = '<option value="">All types</option>' + types.map((t) => `<option ${t === cur ? 'selected' : ''}>${esc(t)}</option>`).join(''); }
    if (this.filter === 'LIVE') rows = rows.filter((r) => r.state !== 'TERMINATED'); else if (this.filter === 'DONE') rows = rows.filter((r) => r.state === 'TERMINATED');
    if (sel.value) rows = rows.filter((r) => r.type === sel.value);
    dataTable($('#pr-tbl'), [
      { k: 'pid', label: 'PID', num: true }, { k: 'name', label: 'Name', cls: 'mono' },
      { k: 'state', label: 'State', f: (r) => chip(r.state.toLowerCase(), stateClass[r.state] || '') },
      { k: 'type', label: 'Type' }, { k: 'user', label: 'User', num: true, f: (r) => (r.user ? r.user : '–') },
      { k: 'queue', label: 'Queue', f: (r) => qchip(r.queue) }, { k: 'priority', label: 'Prio', num: true },
      { k: 'burst', label: 'Burst', num: true, f: (r) => nf(r.burst) }, { k: 'cpuTime', label: 'CPU time', num: true, f: (r) => nf(r.cpuTime) },
      { k: 'wait', label: 'Wait', num: true, f: (r) => (r.wait != null ? nf(r.wait) : '–'), v: (r) => r.wait ?? -1 },
      { k: 'memKb', label: 'Memory', num: true, f: (r) => kb(r.memKb) },
    ], rows, { empty: 'No processes match.', maxHeight: 620 });
  },
};

// ============================================================ Live activity (audit feed)
VIEWS.activity = {
  title: 'Live activity', every: 2, events: [], lastId: 0,
  mount(root) {
    this.events = []; this.lastId = 0; this.fresh = new Set();
    root.innerHTML = `<h1>Live activity</h1><p class="sub">Everything customers and admins do, as it happens: sign-ups, sign-ins, carts, orders, stock changes and OS-engine actions. Each row links to the OS job that ran it.</p>
      <div class="bar"><div><label for="ac-q">Filter</label><input id="ac-q" placeholder="type, person or text" style="min-width:240px"></div>
      <div><label for="ac-w">Who</label><select id="ac-w"><option value="">Everyone</option><option value="CUSTOMER">Customers</option><option value="ADMIN">Admins</option><option value="NONE">Guests / system</option></select></div>
      <div><span class="msg" id="ac-n"></span></div></div><div id="ac-tbl"></div>`;
    $('#ac-q').addEventListener('input', () => this.draw()); $('#ac-w').addEventListener('change', () => this.draw());
  },
  async load() {
    const r = await aget(`/api/admin/activity?limit=${this.lastId ? 100 : 200}${this.lastId ? '&after=' + this.lastId : ''}`);
    if (r.events.length) {
      this.fresh = new Set(this.lastId ? r.events.map((e) => e.id) : []);
      this.events = [...r.events, ...this.events].slice(0, 600); this.lastId = this.events[0].id; this.draw();
    }
  },
  draw() {
    const q = $('#ac-q').value.trim().toLowerCase(), w = $('#ac-w').value;
    const rows = this.events.filter((e) => (!q || `${e.type} ${e.name || ''} ${e.email || ''} ${e.details}`.toLowerCase().includes(q)) && (!w || (w === 'NONE' ? !e.role : e.role === w)));
    $('#ac-n').textContent = `${rows.length} of ${this.events.length} shown`;
    const tone = (t) => (/FAIL|DENIED|BLOCK|CANCEL|DEACT|DELETE|HIDE/.test(t) ? 'warn' : /ORDER_PLACED|REGISTER|LOGIN$/.test(t) ? 'good' : /^ADMIN|OS_|LOAD|PRODUCT|STOCK/.test(t) ? 'q0' : '');
    $('#ac-tbl').innerHTML = rows.length ? `<div class="tbl-wrap"><table class="t"><thead><tr><th>Time</th><th>Event</th><th>By</th><th>What happened</th><th>IP</th><th class="num">OS job</th></tr></thead><tbody>${rows.map((e) =>
      `<tr class="${this.fresh.has(e.id) ? 'feed-new' : ''}"><td>${dateTime(e.at)}</td><td>${chip(e.type.replace(/_/g, ' ').toLowerCase(), tone(e.type))}</td><td>${e.role === 'ADMIN' ? chip('admin', 'q0') + ' ' : ''}${esc(e.name || 'guest / system')}${e.email ? `<div class="muted">${esc(e.email)}</div>` : ''}</td><td class="wrapcell">${esc(e.details)}</td><td class="mono">${esc(e.ip || '')}</td><td class="num mono">${e.jobId ?? ''}</td></tr>`).join('')}</tbody></table></div>`
      : '<div class="empty">No activity matches. Browse the store, create an account or place an order and it shows up here within two seconds.</div>';
  },
};

// ============================================================ CPU scheduler
const ALGO_TEXT = {
  MLQ: 'Multilevel Queue: three queues. Q0 (checkout, stock updates) is Round Robin with the quantum; Q1 (browse, cart, login) is Round Robin with double the quantum; Q2 (reports, audit flushes) is first-come first-served. A lower queue always preempts a higher one.',
  RR: 'Round Robin: one queue; every job gets at most one quantum of CPU, then goes to the back of the line. Fair, but urgent checkouts wait behind everything.',
  FCFS: 'First Come First Served: jobs run in arrival order until done. Simple, but one long report delays every order behind it.',
  SJF: 'Shortest Job First: the shortest ready job runs next. Lowest average wait, but long jobs can starve.',
  PRIORITY: 'Preemptive Priority: the most urgent ready job always runs; a new urgent job interrupts a running one.',
};
VIEWS.scheduler = {
  title: 'CPU scheduler', sig: '',
  mount(root) {
    root.innerHTML = `<h1>CPU scheduler</h1><p class="sub">Choose how the engine shares the CPU, then run a load test and compare. One tick is 10 ms of simulated CPU.</p>
      <div class="row cols-2">
        <div class="panel"><h2>Algorithm</h2>
          <div class="bar"><div><label for="sc-a">Policy</label><select id="sc-a"><option value="MLQ">Multilevel Queue</option><option value="RR">Round Robin</option><option value="FCFS">FCFS</option><option value="SJF">SJF</option><option value="PRIORITY">Priority</option></select></div>
          <div><label for="sc-q">Quantum (ticks)</label><input id="sc-q" type="number" min="1" max="64" value="4"></div><button class="primary" id="sc-apply" type="button">Apply</button></div>
          <p class="sub" id="sc-text" style="margin:0"></p><div class="msg" id="sc-msg" role="status"></div></div>
        <div class="panel"><h2>Load test</h2>
          <div class="bar"><div><label for="sc-n">Jobs</label><input id="sc-n" type="number" min="1" max="300" value="60"></div>
          <div><label for="sc-m">Traffic</label><select id="sc-m"><option value="mixed">Mixed shop traffic</option><option value="rush">Checkout rush</option><option value="batch">Reports and audit batch</option></select></div><button class="primary" id="sc-run" type="button">Run test</button></div>
          <p class="sub" style="margin:0">Submits simulated jobs at once so they compete for CPU, memory, locks and disk. Test jobs are tagged SIMULATION in the tracking tables.</p><div class="msg" id="sc-msg2" role="status"></div></div>
      </div>
      <div class="panel" style="margin-top:14px"><div class="bar" style="margin:0 0 8px"><div><label for="sc-r">Inspect run</label><select id="sc-r" style="min-width:300px"></select></div></div><div class="row cols-6" id="sc-tiles"></div>
        <h2 style="margin-top:14px">CPU time by queue</h2>${legend(QNAME.map((n, i) => [QCOL[i], n]))}<div id="sc-gantt"></div></div>
      <div class="row cols-2" style="margin-top:14px"><div class="panel"><h2>Jobs finished per queue (all time)</h2><div id="sc-q-bars"></div></div><div class="panel"><h2>Recent runs</h2><div id="sc-hist"></div></div></div>
      <div class="panel" style="margin-top:14px"><h2>Jobs in this run</h2><div id="sc-jobs"></div></div>`;
    this.synced = false; this.sig = ''; this.shown = null;
    $('#sc-a').addEventListener('change', () => { $('#sc-text').textContent = ALGO_TEXT[$('#sc-a').value]; });
    $('#sc-apply').addEventListener('click', async () => {
      try { const r = await aj('POST', '/api/admin/os/config', { algorithm: $('#sc-a').value, quantum: Number($('#sc-q').value) }); say($('#sc-msg'), `Now running ${r.config.algorithm}${['RR', 'MLQ'].includes(r.config.algorithm) ? ' with quantum ' + r.config.quantum : ''}.`, 'ok'); }
      catch (e) { say($('#sc-msg'), e.message, 'err'); }
    });
    $('#sc-run').addEventListener('click', async (ev) => {
      const b = ev.currentTarget; b.disabled = true; say($('#sc-msg2'), 'Running…');
      try { const r = await aj('POST', '/api/admin/os/simulate', { count: Number($('#sc-n').value), mix: $('#sc-m').value }); A.runId = r.run ? r.run.runId : null; this.sig = ''; say($('#sc-msg2'), `Scheduled ${r.submitted} jobs.`, 'ok'); await pollOs(); this.tick(); }
      catch (e) { say($('#sc-msg2'), e.message, 'err'); } b.disabled = false;
    });
    $('#sc-r').addEventListener('change', (e) => { A.runId = e.target.value === '' ? null : Number(e.target.value); this.shown = null; this.tick(); });
  },
  async tick() {
    const o = A.os; if (!o) return;
    if (!this.synced && o.config) { $('#sc-a').value = o.config.algorithm; $('#sc-q').value = o.config.quantum; $('#sc-text').textContent = ALGO_TEXT[o.config.algorithm]; this.synced = true; }
    const runs = o.runs, sig = runs.map((r) => r.runId).join(',') + '|' + A.runId;
    if (sig !== this.sig) { this.sig = sig; $('#sc-r').innerHTML = `<option value="" ${A.runId == null ? 'selected' : ''}>Latest busy run (follows new runs)</option>` + runOptions(A.runId); }
    const s = snap();
    if (s) {
      const q = s.cpu.queues, tot = Math.max(1, q[0] + q[1] + q[2]);
      $('#sc-q-bars').innerHTML = q.map((n, i) => hbar(QNAME[i], n, tot, QCOL[i], `${nf(n)} (${nf((n * 100) / tot, 0)}%)`)).join('') + `<p class="sub" style="margin:8px 0 0">Under FCFS, SJF and Priority the queue is only a label. Under MLQ it decides who runs first.</p>`;
    }
    dataTable($('#sc-hist'), [
      { k: 'runId', label: 'Run', num: true }, { k: 'at', label: 'Time', f: (r) => clockTime(r.at), v: (r) => r.at }, { k: 'algorithm', label: 'Policy' }, { k: 'jobs', label: 'Jobs', num: true },
      { k: 'avgWait', label: 'Avg wait', num: true, f: (r) => nf(r.avgWait, 1) }, { k: 'ctx', label: 'Switches', num: true }, { k: 'source', label: 'Source' },
    ], runs, { max: 12, empty: 'No runs yet.' });
    const id = currentRunId(); if (id == null) { $('#sc-gantt').innerHTML = ganttSvg([]); $('#sc-tiles').innerHTML = ''; $('#sc-jobs').innerHTML = '<div class="empty">No run selected.</div>'; return; }
    if (this.shown === id) return; this.shown = id;
    const r = await loadRun(id);
    if (A.view !== this) return;
    if (!r) { $('#sc-gantt').innerHTML = '<div class="empty">That run has aged out of memory. Its numbers remain in the tracking tables.</div>'; return; }
    $('#sc-tiles').innerHTML = tile('Policy', r.algorithm, ['RR', 'MLQ'].includes(r.algorithm) ? 'quantum ' + r.quantum : '') + tile('Jobs', nf(r.jobCount ?? r.jobs.length), `${r.waves} wave${r.waves === 1 ? '' : 's'}`) + tile('Avg wait', nf(r.avgWait, 1), 'ticks')
      + tile('Avg turnaround', nf(r.avgTurnaround, 1), 'ticks') + tile('Avg response', nf(r.avgResponse, 1), 'ticks') + tile('Context switches', nf(r.ctx), `CPU ${nf(r.util, 0)}% busy`);
    $('#sc-gantt').innerHTML = ganttSvg(r.gantt);
    dataTable($('#sc-jobs'), [
      { k: 'id', label: 'Job', num: true }, { k: 'type', label: 'Type' }, { k: 'queue', label: 'Queue', f: (j) => qchip(j.queue) }, { k: 'arrival', label: 'Arrived', num: true }, { k: 'start', label: 'Started', num: true }, { k: 'finish', label: 'Finished', num: true },
      { k: 'burst', label: 'Burst', num: true }, { k: 'wait', label: 'Wait', num: true }, { k: 'turnaround', label: 'Turnaround', num: true }, { k: 'response', label: 'Response', num: true },
      { k: 'pageFaults', label: 'Page faults', num: true }, { k: 'flags', label: 'Notes', sort: false, f: (j) => (j.deadlocked ? chip('deadlocked', 'bad') + ' ' : '') + (j.retried ? chip('rolled back', 'warn') : '') + (j.memWait ? chip('waited for memory', '') : '') },
    ], r.jobs, { maxHeight: 420, max: 400 });
  },
};

// ============================================================ Memory
VIEWS.memory = {
  title: 'Memory',
  mount(root) {
    root.innerHTML = `<h1>Memory</h1><p class="sub">Running jobs and system processes are pinned. Carts, sessions and cached product pages are kept only while there is room; when memory fills, the <b>least recently used</b> one is evicted first (LRU).</p>
      <div class="row cols-4" id="mm-tiles"></div>
      <div class="panel" style="margin-top:14px"><h2>Memory map</h2><div id="mm-seg"></div></div>
      <div class="row cols-2" style="margin-top:14px">
        <div class="panel"><h2>Page frames (LRU)</h2><p class="sub" style="margin:0 0 8px">Product pages held in frames, most recently used first. The last one is next to go.</p><div class="pages" id="mm-frames"></div><h2 style="margin-top:16px">LRU vs FIFO on recent traffic</h2><div id="mm-cmp"></div></div>
        <div class="panel"><h2>Settings</h2><div class="bar"><div><label for="mm-size">Memory (KB)</label><input id="mm-size" type="number" min="1024" max="1048576" step="1024" style="width:130px"></div><div><label for="mm-fr">Page frames</label><input id="mm-fr" type="number" min="1" max="256"></div><button class="primary" id="mm-apply" type="button">Apply</button></div>
          <p class="sub" style="margin:0">Lower the memory to watch evictions climb when you run a load test. Changing the size empties the caches.</p><div class="msg" id="mm-msg" role="status"></div></div>
      </div>
      <div class="panel" style="margin-top:14px"><h2>Resident blocks (most recently used first)</h2><div id="mm-blocks"></div></div>`;
    this.synced = false;
    $('#mm-apply').addEventListener('click', async () => {
      try { await aj('POST', '/api/admin/os/config', { memory: Number($('#mm-size').value), frames: Number($('#mm-fr').value) }); say($('#mm-msg'), 'Memory settings applied.', 'ok'); } catch (e) { say($('#mm-msg'), e.message, 'err'); }
    });
  },
  tick() {
    const s = snap(); if (!s) { $('#mm-tiles').innerHTML = offline; return; }
    const m = s.memory, f = m.frames;
    if (!this.synced) { $('#mm-size').value = m.total; $('#mm-fr').value = f.capacity; this.synced = true; }
    const kind = (b) => b.owner.split(':')[0], pinned = m.blocks.filter((b) => b.pinned).reduce((n, b) => n + b.size, 0), cache = m.used - pinned;
    const tot = f.hits + f.faults;
    $('#mm-tiles').innerHTML = tile('In use', kb(m.used), `of ${kb(m.total)}`) + tile('Free', kb(m.available), nf((m.available * 100) / m.total, 0) + '% free') + tile('LRU evictions', nf(m.evictions), 'blocks pushed out to make room') + tile('Page hit rate', tot ? nf((f.hits * 100) / tot, 0) + '%' : '–', `${nf(f.hits)} hits · ${nf(f.faults)} faults`);
    const seg = (n, c, t) => `<div style="width:${(n * 100) / m.total}%;background:${c}" title="${t}: ${kb(n)}"></div>`;
    $('#mm-seg').innerHTML = `<div class="seg" role="img" aria-label="Memory map">${seg(pinned, 'var(--s1)', 'Pinned (running jobs, daemons)')}${seg(cache, 'var(--s3)', 'Evictable cache')}</div>` + legend([['var(--s1)', `Pinned · ${kb(pinned)}`], ['var(--s3)', `Evictable cache (carts, sessions, pages) · ${kb(cache)}`], ['#0b0f14', `Free · ${kb(m.available)}`]]);
    $('#mm-frames').innerHTML = f.resident.length ? f.resident.map((p, i) => `<span class="pg" title="${i === 0 ? 'most recently used' : i === f.resident.length - 1 ? 'least recently used: next to be evicted' : ''}">page ${p}</span>`).join('') : '<span class="empty">No pages loaded yet. Browse a few products.</span>';
    const mx = Math.max(1, f.lruFaults, f.fifoFaults);
    $('#mm-cmp').innerHTML = f.refs ? hbar('LRU faults', f.lruFaults, mx, 'var(--s3)') + hbar('FIFO faults', f.fifoFaults, mx, 'var(--s2)') + `<p class="sub" style="margin:6px 0 0">Both policies replayed on the last ${f.refs} page references with ${f.capacity} frames. Fewer faults is better.</p>` : '<div class="empty">Needs some page references first.</div>';
    dataTable($('#mm-blocks'), [
      { k: 'owner', label: 'Owner', cls: 'mono' }, { k: 'kind', label: 'Kind', f: (b) => ({ daemon: 'System process', job: 'Running job', cart: 'Shopping cart', session: 'Login session', page: 'Product page' }[kind(b)] || kind(b)), v: kind },
      { k: 'size', label: 'Size', num: true, f: (b) => kb(b.size) }, { k: 'pinned', label: 'Eviction', f: (b) => (b.pinned ? chip('pinned', 'q0') : chip('evictable', 'good')), v: (b) => +b.pinned },
    ], m.blocks, { maxHeight: 360, empty: 'Nothing resident.' });
  },
};

// ============================================================ Disk
VIEWS.disk = {
  title: 'Disk', sig: null,
  mount(root) {
    root.innerHTML = `<h1>Disk</h1><p class="sub">Every finished job writes to a cylinder (orders, inventory, sessions, audit log ...). The disk manager reorders each batch with <b>SSTF</b>: always serve the closest cylinder next. The same writes in arrival order (FCFS) show what that saves.</p>
      <div class="row cols-4" id="dk-tiles"></div>
      <div class="row cols-2" style="margin-top:14px"><div class="panel"><h2>Total head travel</h2><div id="dk-bars"></div></div><div class="panel"><h2>Head position over time</h2><div id="dk-chart"></div></div></div>
      <div class="panel" style="margin-top:14px"><div class="bar" style="margin:0"><div><label for="dk-r">Batch from run</label><select id="dk-r" style="min-width:300px"></select></div></div><div class="row cols-2" id="dk-seek"></div><p class="sub" id="dk-order" style="margin:8px 0 0"></p></div>`;
    this.sig = null; this.shown = null;
    this.chart = new LineChart($('#dk-chart'), { series: [{ name: 'Head position', key: 'head', color: 'var(--s2)' }, { name: 'Travel this second', key: 'moved', color: 'var(--s1)' }], yMax: 200, fmt: (v) => nf(v), height: 150, label: 'Disk head position' });
    $('#dk-r').addEventListener('change', (e) => { A.runId = e.target.value === '' ? null : Number(e.target.value); this.shown = null; this.sig = null; this.tick(); });
  },
  async tick() {
    const s = snap(); if (!s) { $('#dk-tiles').innerHTML = offline; return; }
    const d = s.disk, saved = d.fcfsTotal ? 100 - (d.sstfTotal * 100) / d.fcfsTotal : 0;
    $('#dk-tiles').innerHTML = tile('Head position', 'cyl ' + d.head, `of ${d.cylinders} cylinders`) + tile('Batches scheduled', nf(d.runs)) + tile('Travel saved by SSTF', nf(saved, 0) + '%', `${nf(d.fcfsTotal - d.sstfTotal)} cylinders`) + tile('Last batch', `${d.lastSstf} vs ${d.lastFcfs}`, 'SSTF vs FCFS cylinders');
    $('#dk-bars').innerHTML = hbar('FCFS (arrival order)', d.fcfsTotal, Math.max(1, d.fcfsTotal), 'var(--s2)') + hbar('SSTF (nearest first)', d.sstfTotal, Math.max(1, d.fcfsTotal), 'var(--s3)') + '<p class="sub" style="margin:6px 0 0">Both columns cover exactly the same writes. Shorter is better.</p>';
    this.chart.update(A.pts);
    const sig = (A.os.runs.map((r) => r.runId).join(',')) + '|' + A.runId;
    if (sig !== this.sig) { this.sig = sig; $('#dk-r').innerHTML = `<option value="" ${A.runId == null ? 'selected' : ''}>Latest busy run</option>` + runOptions(A.runId); }
    const id = currentRunId(); if (id == null || this.shown === id) return; this.shown = id;
    const r = await loadRun(id), p = r && r.diskPlan;
    if (A.view !== this) return;
    if (!p) { $('#dk-seek').innerHTML = '<div class="empty">This run wrote nothing to disk.</div>'; $('#dk-order').textContent = ''; return; }
    $('#dk-seek').innerHTML = `<div>${seekSvg(p.headStart, p.requests, 'var(--s2)', 'FCFS: in arrival order', p.fcfs)}</div><div>${seekSvg(p.headStart, p.order, 'var(--s3)', 'SSTF: nearest first', p.sstf)}</div>`;
    $('#dk-order').textContent = `Head started at cylinder ${p.headStart}. ${p.requests.length} writes were reordered; SSTF moved the head ${p.sstf} cylinders against ${p.fcfs} for FCFS${p.requests.length > 40 ? ' (diagrams show the first 40 requests)' : ''}.`;
  },
};

// ============================================================ Locks & deadlocks
VIEWS.resources = {
  title: 'Locks & deadlocks', shown: null,
  mount(root) {
    root.innerHTML = `<h1>Locks & deadlocks</h1><p class="sub">A checkout locks each product it buys. Two checkouts that lock the same products in opposite order can wait on each other forever. The resource manager finds that cycle, rolls one checkout back and retries it with locks taken in a fixed order.</p>
      <div class="row cols-4" id="rs-tiles"></div>
      <div class="row cols-2" style="margin-top:14px"><div class="panel"><h2>Product locks in the last batch</h2><div id="rs-table"></div></div>
      <div class="panel"><h2>Deadlocks in the inspected run</h2><div class="bar" style="margin-bottom:8px"><div><label for="rs-r">Run</label><select id="rs-r" style="min-width:260px"></select></div></div><div id="rs-dead"></div></div></div>`;
    this.sig = null; this.shown = null;
    $('#rs-r').addEventListener('change', (e) => { A.runId = e.target.value === '' ? null : Number(e.target.value); this.shown = null; this.sig = null; this.tick(); });
  },
  async tick() {
    const s = snap(); if (!s) { $('#rs-tiles').innerHTML = offline; return; }
    const r = s.resources;
    $('#rs-tiles').innerHTML = tile('Deadlocks found', nf(r.deadlocks)) + tile('Rollbacks', nf(r.rollbacks), 'victims retried') + tile('Lock waits', nf(r.lockWaits), 'jobs that had to queue for a product') + tile('Locks in last batch', nf(r.table.length));
    dataTable($('#rs-table'), [
      { k: 'resource', label: 'Product', num: true }, { k: 'holder', label: 'Held by job', num: true, f: (x) => (x.holder ?? '–') },
      { k: 'waiters', label: 'Waiting jobs', f: (x) => (x.waiters.length ? x.waiters.join(', ') : chip('none', 'good')), sort: false },
    ], r.table, { empty: 'No product locks in the last batch. Locks appear when checkouts overlap.', maxHeight: 320 });
    const sig = A.os.runs.map((x) => x.runId).join(',') + '|' + A.runId;
    if (sig !== this.sig) { this.sig = sig; $('#rs-r').innerHTML = `<option value="" ${A.runId == null ? 'selected' : ''}>Latest busy run</option>` + runOptions(A.runId); }
    const id = currentRunId(); if (id == null || this.shown === id) return; this.shown = id;
    const run = await loadRun(id), dl = (run && run.deadlockInfo) || [];
    if (A.view !== this) return;
    $('#rs-dead').innerHTML = dl.length ? dl.map((d) => `<p>${chip('deadlock', 'bad')} Jobs <b>${d.jobs.join(', ')}</b> each held a product the other needed. Job <b>${d.victim}</b> was rolled back and retried.</p>`).join('') : '<div class="empty">No deadlock in this run.</div>';
  },
};

// ============================================================ IPC & events
VIEWS.ipc = {
  title: 'IPC & events',
  mount(root) {
    root.innerHTML = `<h1>IPC & events</h1><p class="sub">When a job finishes it sends a message through the IPC queue; the process monitor receives it and logs it. The event log below is what the monitor saw, and it is copied into the database as it arrives.</p>
      <div class="row cols-4" id="ip-tiles"></div>
      <div class="row cols-2" style="margin-top:14px"><div class="panel"><h2>Latest IPC messages</h2><div id="ip-msgs"></div></div><div class="panel"><h2>Monitor events</h2><div id="ip-ev"></div></div></div>`;
  },
  tick() {
    const s = snap(); if (!s) { $('#ip-tiles').innerHTML = offline; return; }
    $('#ip-tiles').innerHTML = tile('Messages sent', nf(s.ipc.sent), 'by finished jobs') + tile('Messages received', nf(s.ipc.received), 'by the monitor') + tile('Waiting in queue', nf(s.ipc.queued)) + tile('Events logged', nf(s.monitor.count));
    $('#ip-msgs').innerHTML = s.ipc.recent.length ? `<div class="tbl-wrap" style="max-height:480px"><table class="t"><tbody>${s.ipc.recent.map((m) => `<tr><td class="mono">${esc(m)}</td></tr>`).join('')}</tbody></table></div>` : '<div class="empty">No messages yet.</div>';
    dataTable($('#ip-ev'), [
      { k: 'seq', label: '#', num: true }, { k: 'level', label: 'Level', f: (e) => chip(e.level.toLowerCase(), e.level === 'WARN' ? 'warn' : e.level === 'ERROR' ? 'bad' : '') }, { k: 'source', label: 'Source' },
      { k: 'message', label: 'Message', cls: 'wrapcell', sort: false },
    ], s.monitor.events.filter((e) => e.source !== 'ipc').slice().reverse(), { maxHeight: 480, empty: 'No events.' });
  },
};
