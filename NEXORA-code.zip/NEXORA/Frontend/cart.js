'use strict';
// Cart + checkout. Checkout needs an account: guests see how to create one, and their cart follows them.
const view = document.getElementById('view');
let cart = { items: [], count: 0, total: 0 }, placed = null, busy = false;

async function loadCart() {
  if (session.user) { cart = await API.get('/api/cart'); }
  else {
    const guest = guestCart.get();
    if (!guest.length) { cart = { items: [], count: 0, total: 0 }; return; }
    const { products } = await API.get('/api/products');
    const items = guest.map((g) => { const p = products.find((x) => x.id === g.id); return p ? { productId: p.id, name: p.name, category: p.category, price: p.price, qty: Math.min(g.qty, Math.max(1, p.stock)), stock: p.stock, available: 1 } : null; }).filter(Boolean);
    guestCart.set(items.map((i) => ({ id: i.productId, qty: i.qty })));
    cart = { items, count: items.reduce((n, i) => n + i.qty, 0), total: Math.round(items.reduce((s, i) => s + i.price * i.qty, 0) * 100) / 100 };
  }
  setCartCount(cart.count);
}

function lines() {
  return cart.items.map((i) => `<div class="line" data-pid="${i.productId}">${tileFor(i.name, i.category)}
    <div><div class="name">${escapeHtml(i.name)}</div><div class="sub">${money(i.price)} each${i.stock <= 5 ? ` · <span style="color:var(--amber)">${i.stock} in stock</span>` : ''}</div></div>
    <div class="qty" role="group" aria-label="Quantity of ${escapeHtml(i.name)}"><button type="button" data-d="-1" aria-label="One fewer">−</button><span>${i.qty}</span><button type="button" data-d="1" aria-label="One more" ${i.qty >= i.stock ? 'disabled' : ''}>+</button></div>
    <div class="amount">${money(i.price * i.qty)}<div><button type="button" class="danger" data-rm="1" style="margin-top:6px;padding:3px 10px;font-size:13px">Remove</button></div></div></div>`).join('');
}

function checkoutPanel() {
  if (!session.user) {
    return `<div class="gate"><h3 style="margin-top:0">Create an account to place your order</h3>
      <p>You can look around and fill a cart as a guest, but an order needs an account so you can track it. Your cart comes with you.</p>
      <div class="row"><a class="btn" href="login.html?tab=register&next=cart.html">Create account</a><a class="btn secondary" href="login.html?next=cart.html">I already have one</a></div></div>`;
  }
  return `<form id="co" novalidate><label for="address">Delivery address</label>
    <textarea class="field" id="address" placeholder="Street, city, postcode" autocomplete="street-address" maxlength="500"></textarea>
    <p class="error" role="alert" id="coErr"></p><button type="submit" style="width:100%" ${busy ? 'disabled' : ''}>${busy ? 'Placing order…' : 'Place order'}</button>
    <p class="hint" style="margin:10px 0 0">No payment is taken in this demo.</p></form>`;
}

function render() {
  if (placed) {
    const o = placed.order, os = placed.os;
    view.innerHTML = `<div class="card done"><h2>Order #${o.id} placed</h2>
      <p>${o.items.map((i) => `${i.qty} × ${escapeHtml(i.name)}`).join(', ')}. Total <b>${money(o.total)}</b>.</p>
      ${os ? `<p class="proc">Handled by the NEXORA OS engine as <b>process #${os.pid}</b> in <b>queue Q${os.queue}</b>; it waited <b>${os.wait}</b> tick${os.wait === 1 ? '' : 's'}${os.retried ? ' and was rolled back once after a stock-lock deadlock, then completed' : ''}.</p>` : ''}
      <p><a class="btn" href="orders.html">Track this order</a> <a class="btn secondary" href="index.html">Keep shopping</a></p></div>`;
    return;
  }
  if (!cart.items.length) {
    view.innerHTML = `<div class="card empty"><h2>Your cart is empty</h2><p>Add a few things and they will wait for you here.</p><a class="btn" href="index.html">Browse products</a></div>`;
    return;
  }
  view.innerHTML = `<div class="two"><div class="card">${lines()}</div>
    <aside class="card summary"><h2>Summary</h2><dl><div><dt>Items</dt><dd>${cart.count}</dd></div><div class="total"><dt>Total</dt><dd>${money(cart.total)}</dd></div></dl>${checkoutPanel()}</aside></div>`;
}

async function change(pid, qty) {
  try {
    if (session.user) cart = qty > 0 ? await API.put('/api/cart/items/' + pid, { qty }) : await API.del('/api/cart/items/' + pid);
    else { guestCart.set(guestCart.get().map((g) => (g.id === pid ? { ...g, qty } : g)).filter((g) => g.qty > 0)); await loadCart(); }
    setCartCount(cart.count);
  } catch (e) { toast(e.message, 'bad'); await loadCart(); }
  render();
}

view.addEventListener('click', (ev) => {
  const row = ev.target.closest('.line'); if (!row) return;
  const pid = Number(row.dataset.pid), item = cart.items.find((i) => i.productId === pid); if (!item) return;
  const d = ev.target.closest('button[data-d]'), rm = ev.target.closest('button[data-rm]');
  if (d) change(pid, item.qty + Number(d.dataset.d)); else if (rm) change(pid, 0);
});

view.addEventListener('submit', async (ev) => {
  if (ev.target.id !== 'co') return;
  ev.preventDefault();
  const err = document.getElementById('coErr'), address = document.getElementById('address').value.trim();
  if (address.length < 8) { err.textContent = 'Enter your full delivery address (at least 8 characters).'; return; }
  busy = true; render(); document.getElementById('address').value = address;
  try { placed = await API.post('/api/checkout', { address }); setCartCount(0); }
  catch (e) {
    busy = false;
    if (e.code === 'AUTH_REQUIRED') { location.href = 'login.html?tab=register&next=cart.html'; return; }
    await loadCart().catch(() => {}); render();
    document.getElementById('address').value = address; document.getElementById('coErr').textContent = e.message; return;
  }
  busy = false; render();
});

window.pageReady = async () => { try { await loadCart(); } catch (e) { view.innerHTML = `<div class="card empty"><h2>Your cart could not load</h2><p>${escapeHtml(e.message)}</p></div>`; return; } render(); };
