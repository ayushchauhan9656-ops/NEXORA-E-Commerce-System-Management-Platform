'use strict';
// Bridge to the C++ OS engine (OS_Module/main.cpp, run as `nexora_kernel --serve`).
// Every storefront / admin operation is submitted here as a job; concurrent
// requests are collected for a few milliseconds and scheduled together, so
// they genuinely compete for the (simulated) CPU, memory, locks and disk.
const { spawn, spawnSync } = require('node:child_process');
const readline = require('node:readline');
const fs = require('node:fs');
const path = require('node:path');
const { EventEmitter } = require('node:events');

const OS_DIR = path.join(__dirname, '..', 'OS_Module');
const BINARY = path.join(OS_DIR, process.platform === 'win32' ? 'nexora_kernel.exe' : 'nexora_kernel');
const TICKS_PER_SEC = 100; // 1 simulated CPU tick = 10 ms

function buildKernel(log) {
  const sources = fs.readdirSync(OS_DIR).filter(f => f.endsWith('.cpp') && f !== 'tests.cpp').map(f => path.join(OS_DIR, f));
  const newest = Math.max(...sources.concat(fs.readdirSync(OS_DIR).filter(f => f.endsWith('.hpp')).map(f => path.join(OS_DIR, f))).map(f => fs.statSync(f).mtimeMs));
  if (fs.existsSync(BINARY) && fs.statSync(BINARY).mtimeMs >= newest) return true;
  const cxx = process.env.CXX || 'c++';
  log(`compiling OS engine with ${cxx} ...`);
  const r = spawnSync(cxx, ['-std=c++17', '-O2', '-o', BINARY, ...sources], { encoding: 'utf8' });
  if (r.status !== 0) { log('OS engine build failed:\n' + (r.stderr || r.error || '')); return false; }
  return true;
}

class Kernel extends EventEmitter {
  constructor({ windowMs = 15, log = console.log } = {}) {
    super();
    this.log = (m) => log('[kernel] ' + m);
    this.windowMs = windowMs;
    this.online = false;
    this.nextId = 1;
    this.waiters = [];      // FIFO of {resolve, reject} for protocol replies
    this.batch = [];        // jobs waiting for the next scheduling run
    this.timer = null;
    this.proc = null;
    this.stopping = false;
    this.config = { algorithm: 'MLQ', quantum: 4, memory: 8192, frames: 16 };
    this.runs = [];         // recent scheduling runs (with Gantt) for the admin panel
    this.runSeq = 0;
  }

  start() {
    this.stopping = false;
    if (!buildKernel(this.log)) { this.online = false; return false; }
    this.proc = spawn(BINARY, ['--serve'], { stdio: ['pipe', 'pipe', 'inherit'] });
    this.proc.on('error', (e) => { this.log('failed to start: ' + e.message); this.online = false; });
    this.proc.on('exit', (code) => {
      this.online = false;
      this._failAll(new Error('OS engine exited'));
      if (!this.stopping) { this.log(`exited (${code}); restarting in 1s`); setTimeout(() => this.start(), 1000); }
    });
    this.rl = readline.createInterface({ input: this.proc.stdout });
    this.rl.on('line', (line) => {
      const w = this.waiters.shift();
      if (!w) return;
      try { w.resolve(JSON.parse(line)); } catch (e) { w.reject(e); }
    });
    this.online = true;
    this.send(`CONFIG algo=${this.config.algorithm} quantum=${this.config.quantum} memory=${this.config.memory} frames=${this.config.frames}`).catch(() => {});
    this.log('online');
    return true;
  }

  stop() {
    this.stopping = true;
    if (this.proc) { try { this.proc.stdin.write('QUIT\n'); } catch {} setTimeout(() => this.proc && this.proc.kill(), 200).unref(); }
  }

  _failAll(err) {
    for (const w of this.waiters.splice(0)) w.reject(err);
    for (const b of this.batch.splice(0)) b.resolve(null);
  }

  send(line) {
    return new Promise((resolve, reject) => {
      if (!this.online || !this.proc || !this.proc.stdin.writable) return reject(new Error('OS engine offline'));
      const timer = setTimeout(() => reject(new Error('OS engine timeout')), 8000);
      this.waiters.push({ resolve: (v) => { clearTimeout(timer); resolve(v); }, reject: (e) => { clearTimeout(timer); reject(e); } });
      this.proc.stdin.write(line + '\n');
    });
  }

  async configure(patch) {
    const next = { ...this.config, ...patch };
    const r = await this.send(`CONFIG algo=${next.algorithm} quantum=${next.quantum} memory=${next.memory} frames=${next.frames}`);
    if (r.ok) this.config = { algorithm: r.algorithm, quantum: r.quantum, memory: r.memory, frames: r.frames };
    return r;
  }

  // since: when given, the monitor section carries every event after that sequence number (lossless DB tracking)
  snapshot(since) { return this.send(since >= 0 ? `SNAPSHOT since=${since | 0}` : 'SNAPSHOT'); }

  // Submit one operation. Resolves with the scheduler's verdict for this job
  // (queue, wait, turnaround, page faults ...) once its batch has been run.
  // Resolves with null when the OS engine is unavailable (the storefront keeps working).
  submit(spec) {
    if (!this.online) return Promise.resolve(null);
    return new Promise((resolve) => {
      const id = this.nextId++;
      this.batch.push({ id, spec, resolve });
      if (!this.timer) this.timer = setTimeout(() => this._flush(), this.windowMs);
    });
  }

  async _flush() {
    this.timer = null;
    const jobs = this.batch.splice(0);
    if (!jobs.length) return;
    const list = (a) => (a && a.length ? a.join(',') : '');
    try {
      const lines = jobs.map(({ id, spec }) => {
        const parts = [`SUBMIT id=${id}`, `type=${spec.type}`, `user=${spec.user || 0}`];
        if (spec.pages && spec.pages.length) parts.push(`pages=${list(spec.pages.slice(0, 16))}`);
        if (spec.locks && spec.locks.length) parts.push(`locks=${list(spec.locks.slice(0, 8))}`);
        if (spec.disk && spec.disk.length) parts.push(`disk=${list(spec.disk.slice(0, 16))}`);
        if (spec.burst) parts.push(`burst=${spec.burst | 0}`);
        return parts.join(' ');
      });
      // write everything now so the SUBMITs and the RUN stay contiguous on the wire
      const replies = lines.map(l => this.send(l));
      const runReply = this.send('RUN');
      await Promise.all(replies);
      const run = await runReply;
      if (!run.ok) throw new Error(run.error || 'run failed');
      const byId = new Map(run.jobs.map(j => [j.id, j]));
      const rec = { ...run, runId: ++this.runSeq, at: Date.now(), source: jobs[0].spec.source || 'USER' };
      this.runs.unshift(rec);
      if (this.runs.length > 30) this.runs.pop();
      this.emit('run', rec);
      for (const j of jobs) {
        const r = byId.get(j.id);
        j.resolve(r ? { ...r, runId: rec.runId } : null);
      }
    } catch (e) {
      this.log('batch failed: ' + e.message);
      for (const j of jobs) j.resolve(null);
    }
  }
}

module.exports = { Kernel, TICKS_PER_SEC };
