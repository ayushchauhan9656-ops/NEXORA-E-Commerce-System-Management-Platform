'use strict';
// Password hashing (scrypt), session tokens (random, stored only as SHA-256) and cookies.
const crypto = require('node:crypto');

const COOKIE = { CUSTOMER: 'nexora_sid', ADMIN: 'nexora_admin' };
const TTL_MS = { CUSTOMER: 7 * 24 * 3600e3, ADMIN: 8 * 3600e3 };

function hashPassword(password) {
  const salt = crypto.randomBytes(16);
  const hash = crypto.scryptSync(password, salt, 64);
  return `scrypt$${salt.toString('hex')}$${hash.toString('hex')}`;
}
function verifyPassword(password, stored) {
  const [scheme, saltHex, hashHex] = String(stored).split('$');
  if (scheme !== 'scrypt' || !saltHex || !hashHex) return false;
  const expected = Buffer.from(hashHex, 'hex');
  const actual = crypto.scryptSync(password, Buffer.from(saltHex, 'hex'), expected.length);
  return crypto.timingSafeEqual(actual, expected);
}
const sha256 = (s) => crypto.createHash('sha256').update(s).digest('hex');
const iso = (ms) => new Date(ms).toISOString();

function parseCookies(header) {
  const out = {};
  for (const part of String(header || '').split(';')) {
    const i = part.indexOf('=');
    if (i > 0) out[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1).trim());
  }
  return out;
}
function cookieHeader(role, token, clear = false) {
  const age = clear ? 0 : Math.floor(TTL_MS[role] / 1000);
  return `${COOKIE[role]}=${clear ? '' : token}; HttpOnly; SameSite=Strict; Path=/; Max-Age=${age}`;
}

function createSession(db, user, ip, ua) {
  const token = crypto.randomBytes(32).toString('hex');
  db.prepare(`INSERT INTO sessions(user_id, role, token_hash, ip_address, user_agent, expires_at) VALUES (?,?,?,?,?,?)`)
    .run(user.user_id, user.role, sha256(token), ip || null, String(ua || '').slice(0, 300), iso(Date.now() + TTL_MS[user.role]));
  return token;
}

// Returns the user row for a valid session of the given role, else null.
function authenticate(db, req, role) {
  const token = parseCookies(req.headers.cookie)[COOKIE[role]];
  if (!token) return null;
  const row = db.prepare(`
    SELECT u.user_id, u.full_name, u.email, u.role, u.is_active, s.session_id, s.last_seen_at
      FROM sessions s JOIN users u ON u.user_id = s.user_id
     WHERE s.token_hash = ? AND s.revoked = 0 AND s.expires_at > ? AND s.role = ?`).get(sha256(token), iso(Date.now()), role);
  if (!row || !row.is_active || row.role !== role) return null;
  if (Date.now() - Date.parse(row.last_seen_at) > 60e3)
    db.prepare(`UPDATE sessions SET last_seen_at = ? WHERE session_id = ?`).run(iso(Date.now()), row.session_id);
  return row;
}

function revoke(db, req, role) {
  const token = parseCookies(req.headers.cookie)[COOKIE[role]];
  if (token) db.prepare(`UPDATE sessions SET revoked = 1 WHERE token_hash = ?`).run(sha256(token));
}

module.exports = { hashPassword, verifyPassword, createSession, authenticate, revoke, cookieHeader, COOKIE };
