#pragma once
#include <map>
#include <string>
#include <vector>
using namespace std;
namespace nexora
{
    // Process control block. Every storefront / admin operation becomes one of these.
    struct Process
    {
        int pid{0};
        string name;
        string state{"READY"};      // READY | RUNNING | BLOCKED | SUSPENDED | TERMINATED
        string type{"PROCESS"};     // CHECKOUT, BROWSE, ... or DAEMON
        int user{0};                // owning customer/admin id (0 = system or guest)
        int queue{1};               // MLQ queue 0..2
        int priority{2};
        int burst{0};               // CPU ticks requested
        int arrival{0};
        int cpuTime{0};             // CPU ticks consumed
        long long memoryKb{0};
    };

    class ProcessManager
    {
        int nextPid_{1};
        map<int, Process> processes_;

    public:
        int create(const string &name);        // returns the new pid, or -1 for an empty name
        bool terminate(int pid);               // removes the process
        bool suspend(int pid);
        bool resume(int pid);
        bool setState(int pid, const string &state);
        Process *find(int pid);                // nullptr when there is no such pid
        const Process *find(int pid) const;
        int count() const;
        vector<Process> list() const;          // ordered by pid
    };
}
