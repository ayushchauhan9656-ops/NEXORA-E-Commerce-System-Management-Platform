#pragma once
#include <queue>
#include <string>
#include <vector>
using namespace std;
class IPCMessageQueue
{
    queue<string> queue_;

public:
    void send(const string &message) { queue_.push(message); }
    bool receive(string &output)
    {
        if (queue_.empty())
            return false;
        output = queue_.front();
        queue_.pop();
        return true;
    }
    size_t size() const { return queue_.size(); }
    bool empty() const { return queue_.empty(); }
    // Copy of the messages still waiting (oldest first) without consuming them.
    vector<string> snapshot() const
    {
        vector<string> out;
        queue<string> copy = queue_;
        while (!copy.empty())
        {
            out.push_back(copy.front());
            copy.pop();
        }
        return out;
    }
};
