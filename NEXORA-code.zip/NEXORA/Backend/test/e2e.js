'use strict';
// End-to-end test: boots the real server + C++ OS engine on a temp database.   npm test
const os = require('node:os'), path = require('node:path'), fs = require('node:fs'), assert = require('node:assert/strict');
const dbFile = path.join(os.tmpdir(), `nexora-test-${process.pid}.db`);
process.env.NEXORA_DB = dbFile;
const { server, kernel, db } = require('../server');

let base, passed = 0;
const jar = () => ({ cookie: '' });
async function call(j, method, url, body) {
  const res = await fetch(base + url, { method, headers: { 'Content-Type': 'application/json', Cookie: j.cookie }, body: body ? JSON.stringify(body) : undefined });
  const sc = res.headers.getSetCookie ? res.headers.getSetCookie() : [];
  if (sc.length) j.cookie = sc.map(c => c.split(';')[0]).filter(c => !/=$/.test(c)).join('; ');
  let data = null; try { data = await res.json(); } catch {}
  return { status: res.status, data, headers: res.headers };
}
async function test(name, fn) { try { await fn(); passed++; console.log('  ok  ' + name); } catch (e) { console.log('FAIL  ' + name + '\n      ' + (e.message || e)); process.exitCode = 1; } }
const sleep = (ms) => new Promise(r => setTimeout(r, ms));
const pw = 'Passw0rd!x';

(async () => {
  await new Promise(r => server.listen(0, r));
  base = 'http://localhost:' + server.address().port;
  for (let i = 0; i < 50 && !kernel.online; i++) await sleep(100);
  assert.ok(kernel.online, 'OS engine must be online');

  const guest = jar(), alice = jar(), bob = jar(), admin = jar();

  await test('guests can browse but cannot cart or check out', async () => {
    assert.equal((await call(guest, 'GET', '/api/products')).data.products.length, 8);
    assert.equal((await call(guest, 'POST', '/api/cart/items', { productId: 1 })).status, 401);
    const r = await call(guest, 'POST', '/api/checkout', { address: '1 Some Street, Delhi' });
    assert.equal(r.status, 401); assert.equal(r.data.code, 'AUTH_REQUIRED');
  });
  await test('registration validates input and rejects duplicates', async () => {
    assert.equal((await call(guest, 'POST', '/api/auth/register', { name: 'A', email: 'x', password: 'abc' })).status, 400);
    assert.equal((await call(alice, 'POST', '/api/auth/register', { name: 'Alice A', email: 'alice@example.com', password: pw })).status, 201);
    assert.equal((await call(guest, 'POST', '/api/auth/register', { name: 'Alice 2', email: 'ALICE@example.com', password: pw })).status, 409);
    assert.equal((await call(alice, 'GET', '/api/auth/me')).data.user.email, 'alice@example.com');
  });
  await test('login: wrong password rejected, correct accepted, logout revokes', async () => {
    const j = jar();
    assert.equal((await call(j, 'POST', '/api/auth/login', { email: 'alice@example.com', password: 'wrong-pass1' })).status, 401);
    assert.equal((await call(j, 'POST', '/api/auth/login', { email: 'alice@example.com', password: pw })).status, 200);
    assert.ok((await call(j, 'GET', '/api/cart')).status === 200);
    await call(j, 'POST', '/api/auth/logout');
    assert.equal((await call(j, 'GET', '/api/cart')).status, 401);
  });
  await test('guest cart merges into account cart', async () => {
    await call(bob, 'POST', '/api/auth/register', { name: 'Bob B', email: 'bob@example.com', password: pw });
    const r = await call(bob, 'POST', '/api/cart/merge', { items: [{ id: 2, qty: 2 }, { id: 999, qty: 1 }] });
    assert.equal(r.data.items.length, 1); assert.equal(r.data.items[0].qty, 2);
    await call(bob, 'DELETE', '/api/cart/items/2');
  });
  await test('checkout decrements stock, records order, items, history and movement', async () => {
    await call(alice, 'POST', '/api/cart/items', { productId: 1, qty: 2 });
    const before = db.prepare('SELECT quantity q FROM inventory WHERE product_id=1').get().q;
    const r = await call(alice, 'POST', '/api/checkout', { address: '12 Test Street, Delhi' });
    assert.equal(r.status, 201); assert.ok(r.data.os && r.data.os.pid > 0, 'order processed by OS engine');
    assert.equal(db.prepare('SELECT quantity q FROM inventory WHERE product_id=1').get().q, before - 2);
    assert.equal(db.prepare('SELECT COUNT(*) n FROM order_items WHERE order_id=?').get(r.data.order.id).n, 1);
    assert.equal(db.prepare("SELECT COUNT(*) n FROM inventory_movements WHERE order_id=? AND reason='ORDER_PLACED'").get(r.data.order.id).n, 1);
    assert.equal((await call(alice, 'GET', '/api/cart')).data.count, 0);
    const o = (await call(alice, 'GET', '/api/orders')).data.orders[0];
    assert.equal(o.history[0].status, 'PLACED');
    assert.equal((await call(bob, 'GET', '/api/orders')).data.orders.length, 0, 'orders are private');
  });
  await test('cancelling restocks and is tracked', async () => {
    const o = (await call(alice, 'GET', '/api/orders')).data.orders[0];
    const before = db.prepare('SELECT quantity q FROM inventory WHERE product_id=1').get().q;
    assert.equal((await call(alice, 'POST', `/api/orders/${o.id}/cancel`)).status, 200);
    assert.equal(db.prepare('SELECT quantity q FROM inventory WHERE product_id=1').get().q, before + 2);
    const hist = (await call(alice, 'GET', '/api/orders')).data.orders[0].history.map(h => h.status);
    assert.deepEqual(hist, ['PLACED', 'CANCELLED']);
    assert.equal((await call(alice, 'POST', `/api/orders/${o.id}/cancel`)).status, 409);
  });
  await test('concurrent checkouts never oversell', async () => {
    db.prepare('UPDATE inventory SET quantity = 5 WHERE product_id = 3').run();
    const users = [];
    for (let i = 0; i < 12; i++) {
      const j = jar();
      await call(j, 'POST', '/api/auth/register', { name: 'Buyer ' + i, email: `buyer${i}@example.com`, password: pw });
      await call(j, 'POST', '/api/cart/items', { productId: 3, qty: 1 });
      users.push(j);
    }
    const res = await Promise.all(users.map(j => call(j, 'POST', '/api/checkout', { address: '99 Race Condition Rd, Delhi' })));
    assert.equal(res.filter(r => r.status === 201).length, 5);
    assert.equal(res.filter(r => r.status === 409).length, 7);
    assert.equal(db.prepare('SELECT quantity q FROM inventory WHERE product_id=3').get().q, 0);
  });
  await test('opposite-order checkouts form a deadlock the OS engine detects and resolves', async () => {
    const mk = async (email, items) => { const j = jar(); await call(j, 'POST', '/api/auth/register', { name: email, email, password: pw }); for (const p of items) await call(j, 'POST', '/api/cart/items', { productId: p }); return j; };
    const a = await mk('dl1@example.com', [5, 6]), b = await mk('dl2@example.com', [6, 5]);
    const before = db.prepare("SELECT COUNT(*) n FROM security_events WHERE event_type='DEADLOCK'").get().n;
    const rs = await Promise.all([a, b].map(j => call(j, 'POST', '/api/checkout', { address: '1 Deadlock Lane, Delhi' })));
    assert.deepEqual(rs.map(r => r.status), [201, 201], 'both orders still complete');
    assert.equal(db.prepare("SELECT COUNT(*) n FROM security_events WHERE event_type='DEADLOCK'").get().n, before + 1);
    assert.ok(rs.some(r => r.data.os.retried), 'one victim was rolled back and retried');
  });
  await test('brute force on a customer account is locked out', async () => {
    const j = jar();
    for (let i = 0; i < 5; i++) await call(j, 'POST', '/api/auth/login', { email: 'bob@example.com', password: 'nope-nope1' });
    const r = await call(j, 'POST', '/api/auth/login', { email: 'bob@example.com', password: pw });
    assert.equal(r.status, 429);
    assert.ok(db.prepare("SELECT COUNT(*) n FROM security_events WHERE event_type='BRUTE_FORCE'").get().n >= 1);
  });
  await test('admin area is separate: customers and guests are refused', async () => {
    assert.equal((await call(guest, 'GET', '/api/admin/os')).status, 401);
    assert.equal((await call(alice, 'GET', '/api/admin/stats')).status, 401, 'customer session is not an admin session');
    assert.equal((await call(admin, 'POST', '/api/admin/login', { username: 'admin', password: 'wrong' })).status, 401);
    assert.equal((await call(admin, 'POST', '/api/admin/login', { username: 'alice@example.com', password: pw })).status, 401, 'customer credentials do not work on admin login');
    assert.equal((await call(admin, 'POST', '/api/admin/login', { username: 'admin', password: 'NexoraDemo123!' })).status, 200);
    assert.equal((await call(admin, 'GET', '/api/admin/me')).status, 200);
  });
  await test('admin sees live OS state: processes, memory (LRU), disk (SSTF), IPC, monitor', async () => {
    const s = (await call(admin, 'GET', '/api/admin/os')).data;
    assert.ok(s.online); const k = s.snapshot;
    assert.ok(k.processes.length >= 6 && k.processes.some(p => p.name === 'cpu-scheduler'));
    assert.ok(k.cpu.completed > 20); assert.equal(k.algorithm, 'MLQ');
    assert.ok(k.memory.blocks.some(b => b.owner.startsWith('session:')), 'resident sessions in LRU memory');
    assert.ok(k.disk.sstfTotal <= k.disk.fcfsTotal, 'SSTF moves the head no more than FCFS');
    assert.ok(k.ipc.received > 0 && k.monitor.events.length > 0);
    assert.ok(k.cpu.queues[0] > 0 && k.cpu.queues[1] > 0, 'jobs ran in several MLQ queues');
  });
  await test('admin can switch scheduler and run a load test; runs are tracked', async () => {
    assert.equal((await call(admin, 'POST', '/api/admin/os/config', { algorithm: 'RR', quantum: 3 })).data.config.algorithm, 'RR');
    assert.equal((await call(admin, 'POST', '/api/admin/os/config', { algorithm: 'BOGUS' })).status, 400);
    const r = await call(admin, 'POST', '/api/admin/os/simulate', { count: 120, mix: 'rush' });
    assert.equal(r.status, 200); assert.equal(r.data.run.jobs, 120); assert.equal(r.data.run.algorithm, 'RR');
    assert.ok(r.data.run.waves >= 1);
    const run = (await call(admin, 'GET', `/api/admin/os/run?id=${r.data.run.runId}`)).data;
    assert.ok(run.gantt.length >= 120);
    await call(admin, 'POST', '/api/admin/os/config', { algorithm: 'MLQ', quantum: 4 });
    const big = (await call(admin, 'POST', '/api/admin/os/simulate', { count: 300, mix: 'batch' })).data.run;
    assert.ok(big.waves > 1, 'memory-bound: batch jobs are admitted in waves');
  });
  await test('every operation is tracked in the database', async () => {
    await kernel.submit({ type: 'BROWSE' }); await sleep(3500);
    const n = (sql) => db.prepare(sql).get().n;
    assert.ok(n('SELECT COUNT(*) n FROM os_jobs') > 100, 'os_jobs');
    assert.ok(n("SELECT COUNT(*) n FROM os_jobs WHERE job_type='CHECKOUT' AND user_id IS NOT NULL") >= 5, 'checkout jobs link to users');
    assert.ok(n('SELECT COUNT(*) n FROM os_runs') > 3 && n('SELECT COUNT(*) n FROM audit_logs') > 20 && n('SELECT COUNT(*) n FROM login_history') > 10);
    assert.ok(n('SELECT COUNT(*) n FROM sessions') > 3 && n('SELECT COUNT(*) n FROM order_status_history') > 5 && n('SELECT COUNT(*) n FROM inventory_movements') > 10);
    const st = (await call(admin, 'GET', '/api/admin/stats')).data;
    assert.ok(st.orders >= 7 && st.revenue > 0 && st.customers >= 15);
    assert.ok((await call(admin, 'GET', '/api/admin/activity?limit=5')).data.events.length === 5);
  });
  await test('admin manages orders, products, users', async () => {
    const o = (await call(admin, 'GET', '/api/admin/orders?status=PLACED')).data.orders[0];
    assert.equal((await call(admin, 'PATCH', `/api/admin/orders/${o.id}`, { status: 'SHIPPED' })).status, 200);
    assert.deepEqual((await call(admin, 'GET', '/api/admin/orders')).data.orders.find(x => x.id === o.id).history.map(h => h.status), ['PLACED', 'SHIPPED']);
    const p = await call(admin, 'POST', '/api/admin/products', { name: 'Test Gadget', category: 'Test', price: 9.5, stock: 7 });
    assert.equal(p.status, 201);
    assert.equal((await call(admin, 'PATCH', `/api/admin/products/${p.data.id}`, { stock: 10, price: 11 })).status, 200);
    assert.equal(db.prepare("SELECT delta FROM inventory_movements WHERE product_id=? AND reason='ADMIN_ADJUST'").get(p.data.id).delta, 3);
    assert.equal((await call(admin, 'DELETE', `/api/admin/products/${p.data.id}`)).status, 200);
    const u = (await call(admin, 'GET', '/api/admin/users')).data.users.find(x => x.email === 'bob@example.com');
    await call(admin, 'PATCH', `/api/admin/users/${u.id}`, { active: false });
    assert.equal((await call(bob, 'GET', '/api/cart')).status, 401, 'deactivated user loses session');
  });
  await test('security: cross-origin writes and non-JSON bodies are refused', async () => {
    const r = await fetch(base + '/api/auth/login', { method: 'POST', headers: { 'Content-Type': 'application/json', Origin: 'http://evil.example' }, body: '{}' });
    assert.equal(r.status, 403);
    const r2 = await fetch(base + '/api/auth/login', { method: 'POST', headers: { 'Content-Type': 'text/plain' }, body: 'x' });
    assert.equal(r2.status, 415);
    assert.equal((await fetch(base + '/..%2f..%2fetc/passwd')).status, 404);
  });

  console.log(`\n${passed} test groups passed${process.exitCode ? ' (with failures)' : ''}`);
  server.close(); kernel.stop();
  setTimeout(() => { for (const s of ['', '-wal', '-shm']) try { fs.unlinkSync(dbFile + s); } catch {} process.exit(process.exitCode || 0); }, 400);
})();
