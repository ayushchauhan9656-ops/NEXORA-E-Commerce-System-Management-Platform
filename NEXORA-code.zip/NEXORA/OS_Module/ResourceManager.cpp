#include "ResourceManager.hpp"
using namespace std;
namespace nexora
{
    vector<int> ResourceManager::deadlockedProcesses(const vector<int> &available,
                                                     const vector<vector<int>> &allocation,
                                                     const vector<vector<int>> &request)
    {
        vector<int> stuck;
        bool malformed = allocation.size() != request.size();
        for (int x : available)
            if (x < 0)
                malformed = true;
        if (malformed)
        { // inconsistent input is reported as "nobody can finish"
            for (size_t i = 0; i < allocation.size(); ++i)
                stuck.push_back(static_cast<int>(i));
            return stuck;
        }

        // Banker's-style safety scan: repeatedly let any process whose request fits finish and
        // hand back what it holds. Whoever is left over is deadlocked.
        auto work = available;
        vector<bool> finished(allocation.size(), false);
        bool progress = true;
        while (progress)
        {
            progress = false;
            for (size_t i = 0; i < allocation.size(); ++i)
            {
                if (finished[i] || request[i].size() != work.size() || allocation[i].size() != work.size())
                    continue;
                bool canFinish = true;
                for (size_t j = 0; j < work.size(); ++j)
                    if (request[i][j] < 0 || allocation[i][j] < 0 || request[i][j] > work[j])
                        canFinish = false;
                if (!canFinish)
                    continue;
                for (size_t j = 0; j < work.size(); ++j)
                    work[j] += allocation[i][j];
                finished[i] = true;
                progress = true;
            }
        }
        for (size_t i = 0; i < finished.size(); ++i)
            if (!finished[i])
                stuck.push_back(static_cast<int>(i));
        return stuck;
    }

    bool ResourceManager::hasDeadlock(const vector<int> &available,
                                      const vector<vector<int>> &allocation,
                                      const vector<vector<int>> &request)
    {
        return !deadlockedProcesses(available, allocation, request).empty();
    }
}
