#pragma once
#include <list>
#include <vector>
using namespace std;
namespace nexora
{
    // Page faults for a reference string with `frameCount` frames.
    int fifoPageFaults(const vector<int> &pages, int frameCount); // original policy
    int lruPageFaults(const vector<int> &pages, int frameCount);  // Least Recently Used

    // Live LRU page-frame table (the product pages currently cached).
    class LRUPageTable
    {
    public:
        explicit LRUPageTable(int capacity = 16) : capacity_(capacity < 0 ? 0 : capacity) {}

        // Reference a page. Returns true on a hit. On a miss the page is loaded, and if a
        // page had to be evicted its number is stored in *victim (-1 when nothing was evicted).
        bool access(int page, int *victim = nullptr);
        bool contains(int page) const;
        vector<int> frames() const; // most recently used first; the last one is next to go
        int capacity() const { return capacity_; }
        int size() const { return static_cast<int>(order_.size()); }

    private:
        int capacity_;
        list<int> order_; // front = most recently used
    };
}
