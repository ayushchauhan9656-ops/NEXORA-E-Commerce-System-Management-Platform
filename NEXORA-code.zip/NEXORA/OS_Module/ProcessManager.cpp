#include "ProcessManager.hpp"
using namespace std;
namespace nexora
{
    int ProcessManager::create(const string &name)
    {
        if (name.empty())
            return -1;
        const int pid = nextPid_++;
        Process p;
        p.pid = pid;
        p.name = name;
        p.state = "READY";
        processes_[pid] = p;
        return pid;
    }
    bool ProcessManager::terminate(int pid)
    {
        return processes_.erase(pid) > 0;
    }
    bool ProcessManager::suspend(int pid)
    {
        return setState(pid, "SUSPENDED");
    }
    bool ProcessManager::resume(int pid)
    {
        return setState(pid, "READY");
    }
    bool ProcessManager::setState(int pid, const string &state)
    {
        auto it = processes_.find(pid);
        if (it == processes_.end())
            return false;
        it->second.state = state;
        return true;
    }
    Process *ProcessManager::find(int pid)
    {
        auto it = processes_.find(pid);
        return it == processes_.end() ? nullptr : &it->second;
    }
    const Process *ProcessManager::find(int pid) const
    {
        auto it = processes_.find(pid);
        return it == processes_.end() ? nullptr : &it->second;
    }
    int ProcessManager::count() const
    {
        return static_cast<int>(processes_.size());
    }
    vector<Process> ProcessManager::list() const
    {
        vector<Process> result;
        for (const auto &entry : processes_)
            result.push_back(entry.second);
        return result;
    }
}
