#pragma once
#include <deque>
#include <string>
#include <vector>
using namespace std;
namespace nexora
{
    // The event log the admin panel reads. Sequence numbers start at 1 and never repeat, so
    // the backend can copy "everything after seq N" into the database without gaps.
    struct MonitorEvent
    {
        long long seq{0};
        int tick{0};
        string level;   // INFO | WARN | ERROR
        string source;  // kernel, cpu, memory, disk, resource, ipc ...
        string message;
    };

    class SystemMonitor
    {
        deque<MonitorEvent> events_; // bounded: only the newest kKeep are retained
        long long total_{0};

    public:
        static constexpr size_t kKeep = 5000;

        void record(const string &event); // original one-line form (INFO / system)
        void record(const string &level, const string &source, const string &message, long long tick);
        long long eventCount() const; // events recorded since boot
        vector<MonitorEvent> recent(size_t n) const;                    // newest n, oldest first
        vector<MonitorEvent> since(long long seq, size_t limit) const;  // events with seq > `seq`, oldest first
        void print() const;
    };
}
