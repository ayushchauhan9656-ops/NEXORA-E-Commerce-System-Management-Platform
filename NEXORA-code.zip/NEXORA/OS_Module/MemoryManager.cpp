#include "MemoryManager.hpp"
#include <algorithm>
using namespace std;
namespace nexora
{
    // ------------------------------------------------------------ original API
    bool MemoryManager::allocate(long long amount)
    {
        if (amount < 0 || amount > total_ - used())
        {
            return false;
        }
        anon_ += amount;
        return true;
    }
    bool MemoryManager::release(long long amount)
    {
        if (amount < 0 || amount > anon_)
        {
            return false;
        }
        anon_ -= amount;
        return true;
    }
    long long MemoryManager::available() const
    {
        return total_ - used();
    }
    long long MemoryManager::used() const
    {
        return anon_ + blockKb_;
    }
    long long MemoryManager::total() const
    {
        return total_;
    }

    // ------------------------------------------------------------- LRU API
    int MemoryManager::find(const string &owner) const
    {
        for (size_t i = 0; i < blocks_.size(); ++i)
            if (blocks_[i].owner == owner)
                return static_cast<int>(i);
        return -1;
    }

    // Free up `need` KB by evicting from the least-recently-used end. All or nothing.
    bool MemoryManager::makeRoom(long long need, vector<string> &evicted, const string &protectOwner)
    {
        if (need <= available())
            return true;
        long long evictable = 0;
        for (const auto &b : blocks_)
            if (!b.pinned && b.owner != protectOwner)
                evictable += b.size;
        if (available() + evictable < need)
            return false; // would not fit even after evicting everything: touch nothing

        for (int i = static_cast<int>(blocks_.size()) - 1; i >= 0 && available() < need; --i)
        {
            if (blocks_[i].pinned || blocks_[i].owner == protectOwner)
                continue;
            evicted.push_back(blocks_[i].owner);
            blockKb_ -= blocks_[i].size;
            ++evictions_;
            blocks_.erase(blocks_.begin() + i);
        }
        return available() >= need;
    }

    bool MemoryManager::allocateFor(const string &owner, long long size, vector<string> &evicted, bool pinned)
    {
        if (size < 0 || owner.empty())
            return false;
        const int at = find(owner);
        if (at >= 0)
        { // already resident: grow/shrink in place, then it becomes most recently used
            const long long delta = size - blocks_[at].size;
            if (delta > 0 && !makeRoom(delta, evicted, owner))
                return false;
            const int now = find(owner); // eviction may have shifted the index
            Block b = blocks_[now];
            blockKb_ += size - b.size;
            b.size = size;
            b.pinned = b.pinned || pinned;
            blocks_.erase(blocks_.begin() + now);
            blocks_.insert(blocks_.begin(), b);
            return true;
        }
        if (!makeRoom(size, evicted, ""))
            return false;
        blocks_.insert(blocks_.begin(), Block{owner, size, pinned});
        blockKb_ += size;
        return true;
    }

    bool MemoryManager::touch(const string &owner)
    {
        const int at = find(owner);
        if (at < 0)
            return false;
        Block b = blocks_[at];
        blocks_.erase(blocks_.begin() + at);
        blocks_.insert(blocks_.begin(), b);
        return true;
    }

    bool MemoryManager::resident(const string &owner) const
    {
        return find(owner) >= 0;
    }

    bool MemoryManager::releaseOwner(const string &owner)
    {
        const int at = find(owner);
        if (at < 0)
            return false;
        blockKb_ -= blocks_[at].size;
        blocks_.erase(blocks_.begin() + at);
        return true;
    }

    long long MemoryManager::evictions() const
    {
        return evictions_;
    }

    const vector<MemoryManager::Block> &MemoryManager::blocks() const
    {
        return blocks_;
    }
}
