#pragma once
#include <string>
#include <vector>
using namespace std;
namespace nexora
{
    struct Job
    {
        int id;
        int arrival;
        int burst;
        int priority;  // lower number = more urgent
        int queue = -1; // explicit MLQ queue 0..2; -1 = derive from priority
    };

    // One contiguous stretch of CPU time given to a job (the Gantt chart).
    struct Slice
    {
        int jobId, start, end, queue;
    };

    struct JobStat
    {
        int id, queue, arrival, burst, firstRun, completion, waiting, turnaround, response;
    };

    struct ScheduleResult
    {
        string algorithm;
        vector<Slice> slices;
        vector<JobStat> stats;
        double avgWaiting{0}, avgTurnaround{0}, avgResponse{0};
        int makespan{0}, contextSwitches{0}, busyTicks{0}, idleTicks{0};
    };

    class CPUScheduler
    {
    public:
        // ---- original policies: return the order in which jobs get the CPU ----
        static vector<int> fcfs(vector<Job> jobs);
        static vector<int> sjf(vector<Job> jobs);
        static vector<int> priority(vector<Job> jobs, int priority);

        // ---- Round Robin: one queue, every job gets at most `quantum` ticks per turn ----
        static vector<int> roundRobin(vector<Job> jobs, int quantum);
        static ScheduleResult scheduleRoundRobin(vector<Job> jobs, int quantum);

        // ---- Multilevel Queue ----
        //   Q0 urgent      Round Robin, quantum q
        //   Q1 interactive Round Robin, quantum 2q
        //   Q2 batch       First-Come First-Served
        // A lower queue always preempts a higher one.
        static vector<int> multilevelQueue(vector<Job> jobs, int quantum);
        static ScheduleResult scheduleMLQ(vector<Job> jobs, int quantum);

        // ---- full timelines (slices + per-job statistics) for the other policies ----
        static ScheduleResult scheduleFCFS(vector<Job> jobs);
        static ScheduleResult scheduleSJF(vector<Job> jobs);
        static ScheduleResult schedulePriority(vector<Job> jobs); // preemptive

        // algorithm: FCFS | SJF | PRIORITY | RR | MLQ  (throws invalid_argument otherwise)
        static ScheduleResult run(const string &algorithm, vector<Job> jobs, int quantum);

        // Which MLQ queue a job belongs to.
        static int queueLevel(const Job &job);
    };
}
