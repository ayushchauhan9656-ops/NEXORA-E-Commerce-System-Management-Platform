'use strict';
// NEXORA backend.  Zero dependencies (Node >= 22.13: node:sqlite built in).
//
//   Browser  ->  this server  ->  C++ OS engine (every request is a scheduled job)
//                     |
//                     +-> SQLite (DB/schema_sqlite.sql) with tracking tables
//
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const { open, tx, ADMIN_EMAIL, DEFAULT_ADMIN_PASSWORD } = require('./db');
const auth = require('./auth');
const { Kernel, TICKS_PER_SEC } = require('./kernel');

const PORT = Number(process.env.PORT) || 3000;
const FRONTEND = path.join(__dirname, '..', 'Frontend');
const log = (m) => console.log(`${new Date().toISOString().slice(11, 19)} ${m}`);

const db = open(process.env.NEXORA_DB || path.join(__dirname, 'nexora.db'));
const kernel = new Kernel({ log });
kernel.start();
kernel.nextId = db.prepare('SELECT COALESCE(MAX(job_id),0)+1 n FROM os_jobs').get().n;

// ------------------------------------------------------------------ utilities
class HttpError extends Error { constructor(status, message, code) { super(message); this.status = status; this.code = code; } }
const nowIso = () => new Date().toISOString();
const clamp = (n, lo, hi) => Math.max(lo, Math.min(hi, n));
const int = (v, d = 0) => { const n = parseInt(v, 10); return Number.isFinite(n) ? n : d; };
const EMAIL_RE = /^[^\s@]{1,64}@[^\s@]{1,190}\.[^\s@]{2,}$/;
const STATUSES = ['PLACED', 'PROCESSING', 'SHIPPED', 'DELIVERED', 'CANCELLED'];

// Disk cylinder (0-199) a table row lives on: lets the disk scheduler see realistic access patterns.
const CYL_BASE = { sessions: 10, users: 20, products: 60, inventory: 95, carts: 130, orders: 170, audit: 190 };
const cyl = (table, id = 0) => (CYL_BASE[table] + (Math.abs(int(id)) * 7) % 20) % 200;

function audit(ctx, type, details, entity = {}) {
  db.prepare(`INSERT INTO audit_logs(user_id, event_type, details, ip_address, entity_type, entity_id, os_job_id) VALUES (?,?,?,?,?,?,?)`)
    .run(ctx.user ? ctx.user.user_id : (entity.userId || null), type, String(details).slice(0, 1900), ctx.ip || null,
      entity.type || null, entity.id || null, ctx.job ? ctx.job.id : null);
}
function secEvent(severity, type, message, risk = 10) {
  db.prepare(`INSERT INTO security_events(severity, event_type, message, risk_score) VALUES (?,?,?,?)`).run(severity, type, String(message).slice(0, 1900), risk);
}

// ------------------------------------------------------- queries shared by routes
function listProducts(q = '', includeHidden = false) {
  const like = `%${q.toLowerCase()}%`;
  return db.prepare(`
    SELECT p.product_id id, p.name, p.category, p.price, p.is_available available,
           i.quantity - i.reserved_quantity stock, i.quantity, i.reorder_level reorderLevel
      FROM products p JOIN inventory i ON i.product_id = p.product_id
     WHERE (? OR p.is_available = 1) AND (lower(p.name) LIKE ? OR lower(IFNULL(p.category,'')) LIKE ?)
     ORDER BY p.product_id`).all(includeHidden ? 1 : 0, like, like);
}
function cartId(userId) {
  const row = db.prepare(`SELECT cart_id FROM carts WHERE user_id = ?`).get(userId);
  return row ? row.cart_id : Number(db.prepare(`INSERT INTO carts(user_id) VALUES (?)`).run(userId).lastInsertRowid);
}
function cartItems(userId) {
  return db.prepare(`
    SELECT p.product_id productId, p.name, p.category, p.price, ci.quantity qty, i.quantity - i.reserved_quantity stock, p.is_available available
      FROM carts c JOIN cart_items ci ON ci.cart_id = c.cart_id
      JOIN products p ON p.product_id = ci.product_id JOIN inventory i ON i.product_id = p.product_id
     WHERE c.user_id = ? ORDER BY ci.rowid`).all(userId);
}
function cartPayload(userId) {
  const items = cartItems(userId);
  return { items, count: items.reduce((n, i) => n + i.qty, 0), total: round2(items.reduce((s, i) => s + i.price * i.qty, 0)) };
}
const round2 = (n) => Math.round(n * 100) / 100;

function orderWithDetails(o) {
  return {
    id: o.order_id, userId: o.user_id, customer: o.full_name, email: o.email, total: o.total_amount, status: o.status, address: o.shipping_address,
    createdAt: o.created_at, updatedAt: o.updated_at,
    items: db.prepare(`SELECT product_id productId, product_name name, unit_price price, quantity qty FROM order_items WHERE order_id = ?`).all(o.order_id),
    history: db.prepare(`SELECT new_status status, changed_at at FROM order_status_history WHERE order_id = ? ORDER BY history_id`).all(o.order_id),
  };
}
const ORDER_SELECT = `SELECT o.*, u.full_name, u.email FROM orders o JOIN users u ON u.user_id = o.user_id`;

// Restock the items of an order (cancellation). Caller supplies the transaction.
function restock(orderId, userId, reason) {
  for (const it of db.prepare(`SELECT product_id, quantity FROM order_items WHERE order_id = ?`).all(orderId)) {
    db.prepare(`UPDATE inventory SET quantity = quantity + ? WHERE product_id = ?`).run(it.quantity, it.product_id);
    const after = db.prepare(`SELECT quantity FROM inventory WHERE product_id = ?`).get(it.product_id);
    if (after) db.prepare(`INSERT INTO inventory_movements(product_id, delta, quantity_after, reason, order_id, user_id) VALUES (?,?,?,?,?,?)`)
      .run(it.product_id, it.quantity, after.quantity, reason, orderId, userId);
  }
}

// ------------------------------------------------------------------- router
const routes = [];
// opts: auth: 'customer' | 'admin' | 'optional' | undefined; job(ctx) -> spec | null
function route(method, pattern, opts, handler) {
  const keys = [];
  const re = new RegExp('^' + pattern.replace(/:(\w+)/g, (_, k) => { keys.push(k); return '([^/]+)'; }) + '/?$');
  routes.push({ method, re, keys, opts, handler });
}

async function readBody(req) {
  if (!['POST', 'PUT', 'PATCH', 'DELETE'].includes(req.method)) return {};
  const chunks = []; let size = 0;
  for await (const c of req) { size += c.length; if (size > 64 * 1024) throw new HttpError(413, 'Request too large'); chunks.push(c); }
  if (!size) return {};
  if (!String(req.headers['content-type'] || '').includes('application/json')) throw new HttpError(415, 'Send JSON');
  try { return JSON.parse(Buffer.concat(chunks).toString('utf8')); } catch { throw new HttpError(400, 'Invalid JSON'); }
}

const SEC_HEADERS = {
  'X-Content-Type-Options': 'nosniff', 'X-Frame-Options': 'DENY', 'Referrer-Policy': 'no-referrer',
  'Content-Security-Policy': "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'",
};
function send(res, status, body, headers = {}) {
  const payload = JSON.stringify(body);
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', ...SEC_HEADERS, ...headers });
  res.end(payload);
}

const throttle = new Map();
const once = (key, ms) => { const t = Date.now(); if ((throttle.get(key) || 0) > t - ms) return false; throttle.set(key, t); return true; };

async function dispatchApi(req, res, url) {
  const started = Date.now();
  const ip = req.socket.remoteAddress || '';
  let r = null, params = {};
  for (const cand of routes) {
    if (cand.method !== req.method) continue;
    const m = cand.re.exec(url.pathname);
    if (m) { r = cand; cand.keys.forEach((k, i) => (params[k] = decodeURIComponent(m[i + 1]))); break; }
  }
  if (!r) return send(res, 404, { error: 'Not found' });

  // CSRF defence-in-depth on top of SameSite=Strict cookies
  if (req.method !== 'GET' && req.headers.origin) {
    let ok = false; try { ok = new URL(req.headers.origin).host === req.headers.host; } catch {}
    if (!ok) return send(res, 403, { error: 'Cross-origin request blocked' });
  }

  let user = null;
  const mode = r.opts.auth;
  if (mode === 'customer') user = auth.authenticate(db, req, 'CUSTOMER');
  else if (mode === 'admin') user = auth.authenticate(db, req, 'ADMIN');
  else if (mode === 'optional') user = auth.authenticate(db, req, 'CUSTOMER');
  if ((mode === 'customer' || mode === 'admin') && !user) {
    if (mode === 'admin' && once('admin401' + ip, 60e3)) secEvent('MEDIUM', 'UNAUTHORIZED_ADMIN_API', `Unauthenticated call to ${req.method} ${url.pathname} from ${ip}`, 40);
    if (mode === 'customer' && url.pathname === '/api/checkout' && once('checkout401' + ip, 60e3))
      secEvent('LOW', 'CHECKOUT_WITHOUT_ACCOUNT', `Order attempt without an account from ${ip}`, 5);
    return send(res, 401, { error: mode === 'admin' ? 'Admin sign-in required' : 'Please sign in or create an account first.', code: 'AUTH_REQUIRED' });
  }

  const ctx = { req, res, user, params, ip, query: Object.fromEntries(url.searchParams), body: {}, job: null };
  let status = 200, out;
  let spec = null;
  try {
    ctx.body = await readBody(req);
    spec = r.opts.job ? r.opts.job(ctx) : null;
    if (spec) {
      ctx.job = await kernel.submit({ ...spec, user: user ? user.user_id : 0 });
    }
    const result = await r.handler(ctx);
    status = result.status || 200;
    out = result;
  } catch (e) {
    if (e instanceof HttpError) { status = e.status; out = { body: { error: e.message, code: e.code }, status }; }
    else { status = 500; out = { body: { error: 'Internal error' }, status }; log('ERROR ' + req.method + ' ' + url.pathname + ' ' + (e.stack || e)); }
  }
  const headers = { ...(out.headers || {}) };
  if (ctx.job) { headers['X-Nexora-Pid'] = String(ctx.job.pid); headers['X-Nexora-Queue'] = 'Q' + ctx.job.queue; }
  send(res, status, out.body, headers);
  if (ctx.job) trackJob(ctx.job, spec, { method: req.method, path: url.pathname, status, ms: Date.now() - started, userId: user ? user.user_id : null, source: spec.source || (mode === 'admin' ? 'ADMIN' : 'USER') });
}

// ----------------------------------------------------- OS tracking (DB side)
let jobRows = [];
let lastEventSeq = 0;
function trackJob(job, spec, info) {
  jobRows.push({ job, info: { ...info, type: spec.type } });
  if (jobRows.length > 5000) jobRows.shift();
}
const INSERT_JOB = `INSERT OR REPLACE INTO os_jobs(job_id, pid, job_type, user_id, source, http_method, http_path, status_code, duration_ms,
  queue_level, priority, arrival_tick, start_tick, finish_tick, burst, wait_ticks, turnaround, response_ticks, memory_kb, page_faults, page_hits,
  deadlocked, retried, algorithm, run_id) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`;
function writeJobRow(r) {
  const j = r.job, i = r.info;
  db.prepare(INSERT_JOB).run(j.id, j.pid, j.type, i.userId, i.source, i.method || null, i.path || null, i.status || null, i.ms || null,
    j.queue, j.priority, j.arrival, j.start, j.finish, j.burst, j.wait, j.turnaround, j.response, j.memKb, j.pageFaults, j.pageHits,
    j.deadlocked ? 1 : 0, j.retried ? 1 : 0, j.algorithm || kernel.config.algorithm, j.dbRunId || null);
}

kernel.on('run', (rec) => {
  const rs = db.prepare(`INSERT INTO os_runs(algorithm, quantum, job_count, waves, avg_wait, avg_turnaround, avg_response, context_switches, cpu_utilization, disk_fcfs, disk_sstf, deadlocks)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`).run(rec.algorithm, rec.quantum, rec.jobs.length, rec.waves, rec.avgWait, rec.avgTurnaround, rec.avgResponse, rec.ctx, rec.util,
    rec.disk ? rec.disk.fcfs : 0, rec.disk ? rec.disk.sstf : 0, rec.deadlocks.length);
  rec.dbRunId = Number(rs.lastInsertRowid);
  for (const j of rec.jobs) { j.dbRunId = rec.dbRunId; j.algorithm = rec.algorithm; }
  for (const d of rec.deadlocks)
    secEvent('MEDIUM', 'DEADLOCK', `Checkout jobs ${d.jobs.join(', ')} formed a circular wait on product locks; job ${d.victim} was rolled back and retried`, 35);
});

let flushing = false;
async function flushTracking() {
  if (flushing || !jobRows.length) return;
  flushing = true;
  try {
    // the flush itself is a batch job (Q2) whose disk write the disk scheduler orders with SSTF
    const fj = await kernel.submit({ type: 'AUDIT_FLUSH', source: 'SYSTEM', disk: [cyl('audit', jobRows.length), cyl('sessions', 1)] });
    const rows = jobRows.splice(0);
    const events = kernel.online ? (await kernel.snapshot(lastEventSeq).catch(() => null)) : null;
    tx(db, () => {
      for (const r of rows) writeJobRow(r);
      if (fj) writeJobRow({ job: { ...fj, dbRunId: fj.dbRunId }, info: { type: 'AUDIT_FLUSH', source: 'SYSTEM', userId: null, method: null, path: null, status: 200, ms: 0 } });
      if (events && events.monitor) {
        const add = db.prepare(`INSERT OR IGNORE INTO os_events(kernel_seq, source, severity, message, tick) VALUES (?,?,?,?,?)`);
        for (const e of events.monitor.events) if (e.seq > lastEventSeq && e.source !== 'ipc') add.run(e.seq, e.source, e.level, e.message, e.tick);
        if (events.monitor.events.length) lastEventSeq = Math.max(lastEventSeq, events.monitor.events[events.monitor.events.length - 1].seq);
      }
    });
  } catch (e) { log('flush failed: ' + e.message); }
  finally { flushing = false; }
}
setInterval(flushTracking, 3000).unref();

// ------------------------------------------------- sampler -> task-manager graphs
const series = [];
let prev = null;
async function sample() {
  if (!kernel.online) return;
  let s; try { s = await kernel.snapshot(); } catch { return; }
  if (!s.ok) return;
  const t = Date.now();
  if (prev) {
    const dt = Math.max(0.2, (t - prev.t) / 1000);
    const pt = {
      t,
      cpu: clamp(((s.cpu.busy - prev.s.cpu.busy) / (dt * TICKS_PER_SEC)) * 100, 0, 100),
      memUsed: s.memory.used, memTotal: s.memory.total,
      procs: s.processes.length,
      jps: (s.cpu.completed - prev.s.cpu.completed) / dt,
      faults: s.memory.frames.faults - prev.s.memory.frames.faults,
      evictions: s.memory.evictions - prev.s.memory.evictions,
      head: s.disk.head,
      sstf: s.disk.sstfTotal, fcfs: s.disk.fcfsTotal,
      moved: s.disk.sstfTotal - prev.s.disk.sstfTotal,
      deadlocks: s.resources.deadlocks,
      wait: s.cpu.lastRun.avgWait,
    };
    series.push(pt); if (series.length > 600) series.shift();
    if (series.length % 5 === 0)
      db.prepare(`INSERT INTO os_metrics(cpu_utilization, memory_used_kb, memory_total_kb, process_count, jobs_per_sec, page_faults, evictions, disk_head, disk_sstf_total, disk_fcfs_total, deadlocks)
        VALUES (?,?,?,?,?,?,?,?,?,?,?)`).run(round2(pt.cpu), pt.memUsed, pt.memTotal, pt.procs, round2(pt.jps), s.memory.frames.faults, s.memory.evictions, pt.head, pt.sstf, pt.fcfs, pt.deadlocks);
  }
  prev = { t, s };
}
setInterval(sample, 1000).unref();

// =============================================================== CUSTOMER ROUTES
const userView = (u) => ({ id: u.user_id, name: u.full_name, email: u.email });
const recentFailures = (email, ip) => ({
  byEmail: db.prepare(`SELECT COUNT(*) n FROM login_history WHERE email_attempted = ? AND success = 0 AND created_at > ?`).get(email, new Date(Date.now() - 10 * 60e3).toISOString()).n,
  byIp: db.prepare(`SELECT COUNT(*) n FROM login_history WHERE ip_address = ? AND success = 0 AND created_at > ?`).get(ip, new Date(Date.now() - 10 * 60e3).toISOString()).n,
});
function loginHistory(email, userId, ok, reason, ctx) {
  db.prepare(`INSERT INTO login_history(user_id, email_attempted, success, failure_reason, ip_address, user_agent) VALUES (?,?,?,?,?,?)`)
    .run(userId || null, email, ok ? 1 : 0, reason || null, ctx.ip, String(ctx.req.headers['user-agent'] || '').slice(0, 300));
}
// A throwaway hash so unknown e-mails cost the same time as wrong passwords.
const DUMMY_HASH = auth.hashPassword('not-a-real-password');

route('GET', '/api/auth/me', { auth: 'optional' }, (ctx) => ({ body: { user: ctx.user ? userView(ctx.user) : null } }));

route('POST', '/api/auth/register', { job: () => ({ type: 'REGISTER', disk: [cyl('users', Date.now() % 100), cyl('carts', 1)] }) }, (ctx) => {
  const name = String(ctx.body.name || '').trim(), email = String(ctx.body.email || '').trim().toLowerCase(), password = String(ctx.body.password || '');
  if (name.length < 2 || name.length > 100) throw new HttpError(400, 'Please enter your full name.');
  if (!EMAIL_RE.test(email)) throw new HttpError(400, 'Please enter a valid e-mail address.');
  if (password.length < 8 || !/[A-Za-z]/.test(password) || !/\d/.test(password)) throw new HttpError(400, 'Password must be at least 8 characters and contain a letter and a number.');
  if (db.prepare(`SELECT 1 FROM users WHERE email = ?`).get(email)) throw new HttpError(409, 'An account with this e-mail already exists. Please sign in instead.', 'EMAIL_TAKEN');
  const id = Number(db.prepare(`INSERT INTO users(full_name, email, password_hash) VALUES (?,?,?)`).run(name, email, auth.hashPassword(password)).lastInsertRowid);
  cartId(id);
  const user = db.prepare(`SELECT * FROM users WHERE user_id = ?`).get(id);
  ctx.user = user;
  const token = auth.createSession(db, user, ctx.ip, ctx.req.headers['user-agent']);
  loginHistory(email, id, true, null, ctx);
  audit(ctx, 'USER_REGISTER', `New customer account ${email}`, { type: 'user', id });
  return { status: 201, body: { user: userView(user) }, headers: { 'Set-Cookie': auth.cookieHeader('CUSTOMER', token) } };
});

route('POST', '/api/auth/login', { job: () => ({ type: 'LOGIN', disk: [cyl('users', 1), cyl('sessions', 1)] }) }, (ctx) => {
  const email = String(ctx.body.email || '').trim().toLowerCase(), password = String(ctx.body.password || '');
  if (!email || !password) throw new HttpError(400, 'Enter your e-mail and password.');
  const f = recentFailures(email, ctx.ip);
  if (f.byEmail >= 5 || f.byIp >= 20) {
    if (once('lock' + email, 60e3)) secEvent('HIGH', 'BRUTE_FORCE', `Login temporarily blocked for ${email} (${f.byEmail} failures, ${f.byIp} from ${ctx.ip})`, 80);
    throw new HttpError(429, 'Too many failed attempts. Please wait 10 minutes and try again.', 'LOCKED');
  }
  const u = db.prepare(`SELECT * FROM users WHERE email = ? AND role = 'CUSTOMER'`).get(email);
  const ok = auth.verifyPassword(password, u ? u.password_hash : DUMMY_HASH) && !!u;
  if (!ok) {
    loginHistory(email, u && u.user_id, false, u ? 'BAD_PASSWORD' : 'UNKNOWN_USER', ctx);
    secEvent('LOW', 'LOGIN_FAILED', `Failed customer login for ${email} from ${ctx.ip}`, 15);
    throw new HttpError(401, 'Incorrect e-mail or password.', 'BAD_CREDENTIALS');
  }
  if (!u.is_active) { loginHistory(email, u.user_id, false, 'DEACTIVATED', ctx); throw new HttpError(403, 'This account has been deactivated. Contact support.'); }
  ctx.user = u;
  const token = auth.createSession(db, u, ctx.ip, ctx.req.headers['user-agent']);
  db.prepare(`UPDATE users SET last_login_at = ? WHERE user_id = ?`).run(nowIso(), u.user_id);
  loginHistory(email, u.user_id, true, null, ctx);
  audit(ctx, 'USER_LOGIN', `Signed in as ${email}`, { type: 'user', id: u.user_id });
  return { body: { user: userView(u) }, headers: { 'Set-Cookie': auth.cookieHeader('CUSTOMER', token) } };
});

route('POST', '/api/auth/logout', { auth: 'optional', job: () => ({ type: 'LOGOUT' }) }, (ctx) => {
  if (ctx.user) audit(ctx, 'USER_LOGOUT', `Signed out ${ctx.user.email}`, { type: 'user', id: ctx.user.user_id });
  auth.revoke(db, ctx.req, 'CUSTOMER');
  return { body: { ok: true }, headers: { 'Set-Cookie': auth.cookieHeader('CUSTOMER', '', true) } };
});

route('GET', '/api/products', {
  auth: 'optional',
  job: (ctx) => ({ type: 'BROWSE', pages: listProducts(ctx.query.q || '').slice(0, 10).map(p => p.id), disk: [cyl('products', 1)] }),
}, (ctx) => ({ body: { products: listProducts(String(ctx.query.q || '').slice(0, 60)).map(({ quantity, reorderLevel, ...p }) => p) } }));

// ---- cart (needs an account) ----
const cartJob = (ctx) => ({ type: 'CART', pages: ctx.params.pid ? [int(ctx.params.pid)] : (ctx.body.productId ? [int(ctx.body.productId)] : []), disk: [cyl('carts', ctx.user && ctx.user.user_id)] });
route('GET', '/api/cart', { auth: 'customer' }, (ctx) => ({ body: cartPayload(ctx.user.user_id) }));

function addToCart(userId, productId, qty) {
  const p = db.prepare(`SELECT p.name, p.is_available, i.quantity - i.reserved_quantity stock FROM products p JOIN inventory i ON i.product_id = p.product_id WHERE p.product_id = ?`).get(productId);
  if (!p || !p.is_available) throw new HttpError(404, 'That product is not available.');
  const cid = cartId(userId);
  const have = (db.prepare(`SELECT quantity FROM cart_items WHERE cart_id = ? AND product_id = ?`).get(cid, productId) || { quantity: 0 }).quantity;
  const want = have + qty;
  if (want > p.stock) throw new HttpError(409, p.stock > 0 ? `Only ${p.stock} of "${p.name}" in stock.` : `"${p.name}" is out of stock.`, 'STOCK');
  db.prepare(`INSERT INTO cart_items(cart_id, product_id, quantity) VALUES (?,?,?) ON CONFLICT(cart_id, product_id) DO UPDATE SET quantity = excluded.quantity`).run(cid, productId, want);
  return p.name;
}
route('POST', '/api/cart/items', { auth: 'customer', job: cartJob }, (ctx) => {
  const pid = int(ctx.body.productId), qty = clamp(int(ctx.body.qty, 1), 1, 50);
  const name = addToCart(ctx.user.user_id, pid, qty);
  audit(ctx, 'CART_ADD', `Added ${qty} × ${name} to cart`, { type: 'product', id: pid });
  return { body: cartPayload(ctx.user.user_id) };
});
route('PUT', '/api/cart/items/:pid', { auth: 'customer', job: cartJob }, (ctx) => {
  const pid = int(ctx.params.pid), qty = clamp(int(ctx.body.qty), 0, 50), cid = cartId(ctx.user.user_id);
  if (qty === 0) db.prepare(`DELETE FROM cart_items WHERE cart_id = ? AND product_id = ?`).run(cid, pid);
  else {
    const p = db.prepare(`SELECT i.quantity - i.reserved_quantity stock FROM inventory i WHERE i.product_id = ?`).get(pid);
    if (!p) throw new HttpError(404, 'Product not found');
    if (qty > p.stock) throw new HttpError(409, `Only ${p.stock} in stock.`, 'STOCK');
    db.prepare(`UPDATE cart_items SET quantity = ? WHERE cart_id = ? AND product_id = ?`).run(qty, cid, pid);
  }
  audit(ctx, 'CART_UPDATE', `Set product ${pid} quantity to ${qty}`, { type: 'product', id: pid });
  return { body: cartPayload(ctx.user.user_id) };
});
route('DELETE', '/api/cart/items/:pid', { auth: 'customer', job: cartJob }, (ctx) => {
  db.prepare(`DELETE FROM cart_items WHERE cart_id = ? AND product_id = ?`).run(cartId(ctx.user.user_id), int(ctx.params.pid));
  audit(ctx, 'CART_REMOVE', `Removed product ${ctx.params.pid} from cart`, { type: 'product', id: int(ctx.params.pid) });
  return { body: cartPayload(ctx.user.user_id) };
});
// Guest cart (kept in the browser) is merged into the account cart right after sign-in.
route('POST', '/api/cart/merge', { auth: 'customer', job: (ctx) => ({ type: 'CART', pages: (ctx.body.items || []).map(i => int(i.id)).slice(0, 10), disk: [cyl('carts', ctx.user.user_id)] }) }, (ctx) => {
  let merged = 0;
  for (const it of Array.isArray(ctx.body.items) ? ctx.body.items.slice(0, 30) : []) {
    const pid = int(it.id), qty = clamp(int(it.qty), 1, 50);
    try { addToCart(ctx.user.user_id, pid, qty); merged++; }
    catch (e) { if (!(e instanceof HttpError)) throw e; }
  }
  if (merged) audit(ctx, 'CART_MERGE', `Merged ${merged} guest cart item(s) after sign-in`);
  return { body: cartPayload(ctx.user.user_id) };
});

// ---- checkout: account required, stock checked + decremented atomically ----
route('POST', '/api/checkout', {
  auth: 'customer',
  job: (ctx) => {
    const items = cartItems(ctx.user.user_id);
    return { type: 'CHECKOUT', pages: items.map(i => i.productId), locks: items.map(i => i.productId),
      disk: [cyl('orders', ctx.user.user_id), ...items.map(i => cyl('inventory', i.productId))] };
  },
}, (ctx) => {
  const address = String(ctx.body.address || '').trim();
  if (address.length < 8 || address.length > 500) throw new HttpError(400, 'Please enter a full delivery address.');
  const order = tx(db, () => {
    const items = cartItems(ctx.user.user_id);
    if (!items.length) throw new HttpError(400, 'Your cart is empty.');
    for (const it of items) {
      if (!it.available) throw new HttpError(409, `"${it.name}" is no longer available.`);
      if (it.qty > it.stock) throw new HttpError(409, it.stock > 0 ? `Only ${it.stock} of "${it.name}" left - please reduce the quantity.` : `"${it.name}" just sold out.`, 'STOCK');
    }
    const total = round2(items.reduce((s, i) => s + i.price * i.qty, 0));
    const oid = Number(db.prepare(`INSERT INTO orders(user_id, total_amount, status, shipping_address) VALUES (?,?, 'PLACED', ?)`).run(ctx.user.user_id, total, address).lastInsertRowid);
    for (const it of items) {
      const upd = db.prepare(`UPDATE inventory SET quantity = quantity - ? WHERE product_id = ? AND quantity - reserved_quantity >= ?`).run(it.qty, it.productId, it.qty);
      if (upd.changes !== 1) throw new HttpError(409, `"${it.name}" just sold out.`, 'STOCK');
      db.prepare(`INSERT INTO order_items(order_id, product_id, product_name, unit_price, quantity) VALUES (?,?,?,?,?)`).run(oid, it.productId, it.name, it.price, it.qty);
      const inv = db.prepare(`SELECT quantity, reorder_level FROM inventory WHERE product_id = ?`).get(it.productId);
      db.prepare(`INSERT INTO inventory_movements(product_id, delta, quantity_after, reason, order_id, user_id) VALUES (?,?,?, 'ORDER_PLACED', ?, ?)`).run(it.productId, -it.qty, inv.quantity, oid, ctx.user.user_id);
      if (inv.quantity <= inv.reorder_level) secEvent('LOW', 'LOW_STOCK', `"${it.name}" is down to ${inv.quantity} units (reorder level ${inv.reorder_level})`, 8);
    }
    db.prepare(`DELETE FROM cart_items WHERE cart_id = ?`).run(cartId(ctx.user.user_id));
    return { id: oid, total, status: 'PLACED', items: items.map(i => ({ name: i.name, qty: i.qty, price: i.price })) };
  });
  audit(ctx, 'ORDER_PLACED', `Order #${order.id} placed - $${order.total.toFixed(2)}, ${order.items.length} line(s)`, { type: 'order', id: order.id });
  const j = ctx.job;
  return { status: 201, body: { order, os: j ? { pid: j.pid, queue: j.queue, wait: j.wait, turnaround: j.turnaround, retried: j.retried } : null } };
});

route('GET', '/api/orders', { auth: 'customer' }, (ctx) => ({
  body: { orders: db.prepare(`${ORDER_SELECT} WHERE o.user_id = ? ORDER BY o.order_id DESC LIMIT 100`).all(ctx.user.user_id).map(o => ({ ...orderWithDetails(o), canCancel: o.status === 'PLACED' })) },
}));
route('POST', '/api/orders/:id/cancel', { auth: 'customer', job: (ctx) => ({ type: 'ORDER_UPDATE', disk: [cyl('orders', ctx.user.user_id), cyl('inventory', 1)] }) }, (ctx) => {
  const id = int(ctx.params.id);
  tx(db, () => {
    const o = db.prepare(`SELECT * FROM orders WHERE order_id = ? AND user_id = ?`).get(id, ctx.user.user_id);
    if (!o) throw new HttpError(404, 'Order not found.');
    if (o.status !== 'PLACED') throw new HttpError(409, 'This order is already being processed and can no longer be cancelled.');
    db.prepare(`UPDATE orders SET status = 'CANCELLED' WHERE order_id = ?`).run(id);
    restock(id, ctx.user.user_id, 'ORDER_CANCELLED');
  });
  audit(ctx, 'ORDER_CANCELLED', `Customer cancelled order #${id}`, { type: 'order', id });
  return { body: { ok: true } };
});

// ================================================================= ADMIN ROUTES
route('POST', '/api/admin/login', { job: () => ({ type: 'LOGIN', source: 'ADMIN', disk: [cyl('users', 0), cyl('sessions', 0)] }) }, (ctx) => {
  const id = String(ctx.body.username || '').trim().toLowerCase(), password = String(ctx.body.password || '');
  const email = id === 'admin' ? ADMIN_EMAIL : id;
  const f = recentFailures(email, ctx.ip);
  if (f.byEmail >= 5 || f.byIp >= 20) {
    if (once('adminlock' + ctx.ip, 60e3)) secEvent('CRITICAL', 'ADMIN_BRUTE_FORCE', `Admin login blocked after repeated failures from ${ctx.ip}`, 95);
    throw new HttpError(429, 'Too many failed attempts. Try again in 10 minutes.', 'LOCKED');
  }
  const u = db.prepare(`SELECT * FROM users WHERE email = ? AND role = 'ADMIN'`).get(email);
  const ok = auth.verifyPassword(password, u ? u.password_hash : DUMMY_HASH) && !!u && !!u.is_active;
  if (!ok) {
    loginHistory(email, u && u.user_id, false, 'ADMIN_BAD_CREDENTIALS', ctx);
    secEvent('HIGH', 'ADMIN_LOGIN_FAILED', `Failed admin login for "${id}" from ${ctx.ip}`, 60);
    throw new HttpError(401, 'Invalid username or password.');
  }
  ctx.user = u;
  const token = auth.createSession(db, u, ctx.ip, ctx.req.headers['user-agent']);
  db.prepare(`UPDATE users SET last_login_at = ? WHERE user_id = ?`).run(nowIso(), u.user_id);
  loginHistory(email, u.user_id, true, null, ctx);
  secEvent('MEDIUM', 'ADMIN_LOGIN', `Admin session started from ${ctx.ip}`, 20);
  audit(ctx, 'ADMIN_LOGIN', 'Admin signed in', { type: 'user', id: u.user_id });
  return { body: { admin: { name: u.full_name, email: u.email }, defaultPassword: process.env.NEXORA_ADMIN_PASSWORD ? false : true }, headers: { 'Set-Cookie': auth.cookieHeader('ADMIN', token) } };
});
route('POST', '/api/admin/logout', { auth: 'admin' }, (ctx) => {
  audit(ctx, 'ADMIN_LOGOUT', 'Admin signed out');
  auth.revoke(db, ctx.req, 'ADMIN');
  return { body: { ok: true }, headers: { 'Set-Cookie': auth.cookieHeader('ADMIN', '', true) } };
});
route('GET', '/api/admin/me', { auth: 'admin' }, (ctx) => ({ body: { admin: { name: ctx.user.full_name, email: ctx.user.email } } }));

// ---- OS engine: the task-manager data ----
const runSummary = (r) => ({ runId: r.runId, at: r.at, algorithm: r.algorithm, quantum: r.quantum, jobs: r.jobs.length, waves: r.waves, avgWait: r.avgWait,
  avgTurnaround: r.avgTurnaround, avgResponse: r.avgResponse, ctx: r.ctx, util: r.util, deadlocks: r.deadlocks.length, source: r.source,
  disk: r.disk ? { fcfs: r.disk.fcfs, sstf: r.disk.sstf } : null });
route('GET', '/api/admin/os', { auth: 'admin' }, async (ctx) => {
  let snapshot = null;
  if (kernel.online) { try { snapshot = await kernel.snapshot(); } catch {} }
  const focus = kernel.runs.find(r => r.jobs.length >= 2) || kernel.runs[0] || null;
  return { body: { online: kernel.online && !!snapshot, config: kernel.config, ticksPerSec: TICKS_PER_SEC, snapshot, series: series.slice(-int(ctx.query.points, 120)),
    runs: kernel.runs.map(runSummary), focusRunId: focus ? focus.runId : null, serverTime: Date.now() } };
});
route('GET', '/api/admin/os/run', { auth: 'admin' }, (ctx) => {
  const r = kernel.runs.find(x => x.runId === int(ctx.query.id));
  if (!r) throw new HttpError(404, 'That run is no longer in memory.');
  return { body: { ...runSummary(r), jobCount: r.jobs.length, gantt: r.gantt, jobs: r.jobs.slice(0, 400), locks: r.locks, diskPlan: r.disk, deadlockInfo: r.deadlocks } };
});
route('POST', '/api/admin/os/config', { auth: 'admin', job: () => ({ type: 'ADMIN_ACTION', source: 'ADMIN' }) }, async (ctx) => {
  const patch = {};
  if (ctx.body.algorithm !== undefined) patch.algorithm = String(ctx.body.algorithm).toUpperCase();
  if (ctx.body.quantum !== undefined) patch.quantum = int(ctx.body.quantum);
  if (ctx.body.memory !== undefined) patch.memory = int(ctx.body.memory);
  if (ctx.body.frames !== undefined) patch.frames = int(ctx.body.frames);
  const r = await kernel.configure(patch).catch(() => ({ ok: false, error: 'OS engine offline' }));
  if (!r.ok) throw new HttpError(400, r.error);
  audit(ctx, 'OS_CONFIG', `OS engine configured: ${JSON.stringify(patch)}`, { type: 'os' });
  return { body: { config: kernel.config } };
});
route('POST', '/api/admin/os/simulate', { auth: 'admin' }, async (ctx) => {
  if (!kernel.online) throw new HttpError(503, 'OS engine offline');
  const count = clamp(int(ctx.body.count, 40), 1, 300), mix = String(ctx.body.mix || 'mixed');
  const ids = db.prepare(`SELECT product_id id FROM products WHERE is_available = 1`).all().map(r => r.id);
  const pick = (n) => Array.from({ length: n }, () => ids[Math.floor(Math.random() * ids.length)]);
  const uniq = (a) => [...new Set(a)];
  const weights = { mixed: [['BROWSE', 35], ['CART', 20], ['LOGIN', 10], ['CHECKOUT', 20], ['STOCK_UPDATE', 5], ['REPORT', 6], ['ADMIN_ACTION', 4]],
    rush: [['CHECKOUT', 80], ['BROWSE', 10], ['STOCK_UPDATE', 10]], batch: [['REPORT', 60], ['AUDIT_FLUSH', 20], ['BROWSE', 20]] }[mix] || null;
  if (!weights) throw new HttpError(400, 'mix must be mixed, rush or batch');
  const total = weights.reduce((s, w) => s + w[1], 0);
  const jobs = Array.from({ length: count }, () => {
    let x = Math.random() * total, type = weights[0][0];
    for (const [t, w] of weights) { if ((x -= w) < 0) { type = t; break; } }
    const pages = uniq(pick(type === 'CHECKOUT' ? 3 : type === 'BROWSE' ? 5 : 1));
    const spec = { type, source: 'SIMULATION', user: 1000 + Math.floor(Math.random() * 20), pages, disk: pages.map(p => cyl('inventory', p)).concat([cyl('audit', Math.random() * 50)]) };
    if (type === 'CHECKOUT') spec.locks = uniq(pick(2 + Math.floor(Math.random() * 2))).slice(0, 3);
    return spec;
  });
  const results = await Promise.all(jobs.map(s => kernel.submit(s)));
  results.forEach((r, i) => { if (r) trackJob(r, jobs[i], { method: 'POST', path: '/api/admin/os/simulate', status: 200, ms: 0, userId: null, source: 'SIMULATION' }); });
  audit(ctx, 'LOAD_TEST', `Admin started a "${mix}" load test with ${count} jobs`, { type: 'os' });
  const run = kernel.runs[0];
  return { body: { run: run ? runSummary(run) : null, submitted: count } };
});

// ---- activity, jobs, logins, security ----
route('GET', '/api/admin/activity', { auth: 'admin' }, (ctx) => {
  const after = int(ctx.query.after), limit = clamp(int(ctx.query.limit, 100), 1, 500);
  const rows = db.prepare(`SELECT a.log_id id, a.created_at at, a.event_type type, a.details, a.ip_address ip, a.entity_type entityType, a.entity_id entityId, a.os_job_id jobId,
      u.full_name name, u.email, u.role FROM audit_logs a LEFT JOIN users u ON u.user_id = a.user_id WHERE a.log_id > ? ORDER BY a.log_id DESC LIMIT ?`).all(after, limit);
  return { body: { events: rows } };
});
route('GET', '/api/admin/jobs', { auth: 'admin' }, (ctx) => {
  const limit = clamp(int(ctx.query.limit, 100), 1, 500), type = String(ctx.query.type || '');
  const rows = db.prepare(`SELECT j.*, u.email FROM os_jobs j LEFT JOIN users u ON u.user_id = j.user_id WHERE (? = '' OR j.job_type = ?) ORDER BY j.job_id DESC LIMIT ?`).all(type, type, limit);
  return { body: { jobs: rows, pendingWrites: jobRows.length } };
});
route('GET', '/api/admin/logins', { auth: 'admin' }, (ctx) => ({
  body: { logins: db.prepare(`SELECT login_id id, user_id userId, email_attempted email, success, failure_reason reason, ip_address ip, user_agent agent, created_at at FROM login_history ORDER BY login_id DESC LIMIT ?`).all(clamp(int(ctx.query.limit, 100), 1, 500)),
    sessions: db.prepare(`SELECT s.session_id id, u.email, s.role, s.ip_address ip, s.created_at createdAt, s.last_seen_at lastSeen, s.expires_at expiresAt FROM sessions s JOIN users u ON u.user_id = s.user_id
      WHERE s.revoked = 0 AND s.expires_at > ? ORDER BY s.last_seen_at DESC LIMIT 100`).all(nowIso()) },
}));
route('GET', '/api/admin/security', { auth: 'admin' }, (ctx) => ({
  body: { events: db.prepare(`SELECT event_id id, severity, event_type type, message, risk_score risk, resolved, created_at at FROM security_events ORDER BY event_id DESC LIMIT ?`).all(clamp(int(ctx.query.limit, 150), 1, 500)) },
}));
route('POST', '/api/admin/security/:id/resolve', { auth: 'admin', job: () => ({ type: 'ADMIN_ACTION', source: 'ADMIN' }) }, (ctx) => {
  db.prepare(`UPDATE security_events SET resolved = 1 WHERE event_id = ?`).run(int(ctx.params.id));
  audit(ctx, 'SECURITY_RESOLVED', `Resolved security event #${ctx.params.id}`, { type: 'security', id: int(ctx.params.id) });
  return { body: { ok: true } };
});

route('GET', '/api/admin/stats', { auth: 'admin' }, () => {
  const one = (sql, ...a) => db.prepare(sql).get(...a).n;
  const dayAgo = new Date(Date.now() - 24 * 3600e3).toISOString(), hourAgo = new Date(Date.now() - 3600e3).toISOString();
  return { body: {
    customers: one(`SELECT COUNT(*) n FROM users WHERE role='CUSTOMER'`), activeSessions: one(`SELECT COUNT(*) n FROM sessions WHERE revoked=0 AND expires_at > ? AND role='CUSTOMER'`, nowIso()),
    orders: one(`SELECT COUNT(*) n FROM orders`), orders24h: one(`SELECT COUNT(*) n FROM orders WHERE created_at > ?`, dayAgo),
    revenue: round2(db.prepare(`SELECT IFNULL(SUM(total_amount),0) n FROM orders WHERE status <> 'CANCELLED'`).get().n),
    products: one(`SELECT COUNT(*) n FROM products WHERE is_available=1`),
    lowStock: one(`SELECT COUNT(*) n FROM inventory i JOIN products p ON p.product_id=i.product_id WHERE p.is_available=1 AND i.quantity - i.reserved_quantity <= i.reorder_level`),
    openSecurity: one(`SELECT COUNT(*) n FROM security_events WHERE resolved=0`), failedLogins1h: one(`SELECT COUNT(*) n FROM login_history WHERE success=0 AND created_at > ?`, hourAgo),
    trackedJobs: one(`SELECT COUNT(*) n FROM os_jobs`), trackedRuns: one(`SELECT COUNT(*) n FROM os_runs`), metricSamples: one(`SELECT COUNT(*) n FROM os_metrics`),
    auditRows: one(`SELECT COUNT(*) n FROM audit_logs`), osEvents: one(`SELECT COUNT(*) n FROM os_events`), loginRows: one(`SELECT COUNT(*) n FROM login_history`),
    movements: one(`SELECT COUNT(*) n FROM inventory_movements`), statusChanges: one(`SELECT COUNT(*) n FROM order_status_history`),
    pendingWrites: jobRows.length,
  } };
});

// ---- orders, products, users ----
route('GET', '/api/admin/orders', { auth: 'admin' }, (ctx) => {
  const st = String(ctx.query.status || '');
  return { body: { orders: db.prepare(`${ORDER_SELECT} WHERE (? = '' OR o.status = ?) ORDER BY o.order_id DESC LIMIT 200`).all(st, st).map(orderWithDetails) } };
});
route('PATCH', '/api/admin/orders/:id', { auth: 'admin', job: () => ({ type: 'ORDER_UPDATE', source: 'ADMIN', disk: [cyl('orders', 3), cyl('inventory', 2)] }) }, (ctx) => {
  const id = int(ctx.params.id), status = String(ctx.body.status || '').toUpperCase();
  if (!STATUSES.includes(status)) throw new HttpError(400, 'Unknown status.');
  tx(db, () => {
    const o = db.prepare(`SELECT * FROM orders WHERE order_id = ?`).get(id);
    if (!o) throw new HttpError(404, 'Order not found.');
    if (o.status === status) return;
    if (o.status === 'CANCELLED') throw new HttpError(409, 'Cancelled orders cannot be changed.');
    if (o.status === 'DELIVERED' && status !== 'DELIVERED') throw new HttpError(409, 'Delivered orders cannot be changed.');
    db.prepare(`UPDATE orders SET status = ? WHERE order_id = ?`).run(status, id);
    if (status === 'CANCELLED') restock(id, ctx.user.user_id, 'ORDER_CANCELLED');
  });
  audit(ctx, 'ORDER_STATUS', `Order #${id} set to ${status}`, { type: 'order', id });
  return { body: { ok: true } };
});

route('GET', '/api/admin/products', { auth: 'admin' }, () => ({ body: { products: listProducts('', true) } }));
route('POST', '/api/admin/products', { auth: 'admin', job: () => ({ type: 'STOCK_UPDATE', source: 'ADMIN', disk: [cyl('products', 9), cyl('inventory', 9)] }) }, (ctx) => {
  const name = String(ctx.body.name || '').trim(), category = String(ctx.body.category || '').trim(), price = Number(ctx.body.price), stock = int(ctx.body.stock);
  if (!name || name.length > 170) throw new HttpError(400, 'Name is required.');
  if (!(price >= 0) || price > 1e6) throw new HttpError(400, 'Enter a valid price.');
  if (stock < 0 || stock > 1e6) throw new HttpError(400, 'Enter a valid stock quantity.');
  const id = tx(db, () => {
    const pid = Number(db.prepare(`INSERT INTO products(name, category, price) VALUES (?,?,?)`).run(name, category || 'General', round2(price)).lastInsertRowid);
    db.prepare(`INSERT INTO inventory(product_id, quantity) VALUES (?,?)`).run(pid, stock);
    db.prepare(`INSERT INTO inventory_movements(product_id, delta, quantity_after, reason, user_id) VALUES (?,?,?, 'PRODUCT_CREATED', ?)`).run(pid, stock, stock, ctx.user.user_id);
    return pid;
  });
  audit(ctx, 'PRODUCT_ADD', `Added product "${name}" (${stock} in stock)`, { type: 'product', id });
  return { status: 201, body: { id } };
});
route('PATCH', '/api/admin/products/:id', { auth: 'admin', job: () => ({ type: 'STOCK_UPDATE', source: 'ADMIN', disk: [cyl('products', 5), cyl('inventory', 5)] }) }, (ctx) => {
  const id = int(ctx.params.id), b = ctx.body;
  tx(db, () => {
    const p = db.prepare(`SELECT * FROM products WHERE product_id = ?`).get(id);
    if (!p) throw new HttpError(404, 'Product not found.');
    if (b.name !== undefined) { const n = String(b.name).trim(); if (!n) throw new HttpError(400, 'Name is required.'); db.prepare(`UPDATE products SET name = ? WHERE product_id = ?`).run(n, id); }
    if (b.category !== undefined) db.prepare(`UPDATE products SET category = ? WHERE product_id = ?`).run(String(b.category).trim(), id);
    if (b.price !== undefined) { const v = Number(b.price); if (!(v >= 0) || v > 1e6) throw new HttpError(400, 'Invalid price.'); db.prepare(`UPDATE products SET price = ? WHERE product_id = ?`).run(round2(v), id); }
    if (b.available !== undefined) db.prepare(`UPDATE products SET is_available = ? WHERE product_id = ?`).run(b.available ? 1 : 0, id);
    if (b.stock !== undefined) {
      const v = int(b.stock, -1); if (v < 0 || v > 1e6) throw new HttpError(400, 'Invalid stock.');
      const cur = db.prepare(`SELECT quantity FROM inventory WHERE product_id = ?`).get(id).quantity;
      if (v !== cur) {
        db.prepare(`UPDATE inventory SET quantity = ? WHERE product_id = ?`).run(v, id);
        db.prepare(`INSERT INTO inventory_movements(product_id, delta, quantity_after, reason, user_id) VALUES (?,?,?, 'ADMIN_ADJUST', ?)`).run(id, v - cur, v, ctx.user.user_id);
      }
    }
  });
  audit(ctx, 'PRODUCT_UPDATE', `Updated product #${id}: ${Object.keys(b).join(', ')}`, { type: 'product', id });
  return { body: { ok: true } };
});
route('DELETE', '/api/admin/products/:id', { auth: 'admin', job: () => ({ type: 'STOCK_UPDATE', source: 'ADMIN', disk: [cyl('products', 7)] }) }, (ctx) => {
  const id = int(ctx.params.id);
  const used = db.prepare(`SELECT 1 FROM order_items WHERE product_id = ? LIMIT 1`).get(id);
  if (used) { db.prepare(`UPDATE products SET is_available = 0 WHERE product_id = ?`).run(id); audit(ctx, 'PRODUCT_HIDE', `Product #${id} has order history - hidden instead of deleted`, { type: 'product', id }); return { body: { ok: true, hidden: true } }; }
  db.prepare(`DELETE FROM products WHERE product_id = ?`).run(id);
  audit(ctx, 'PRODUCT_DELETE', `Deleted product #${id}`, { type: 'product', id });
  return { body: { ok: true } };
});
route('GET', '/api/admin/inventory/movements', { auth: 'admin' }, (ctx) => ({
  body: { movements: db.prepare(`SELECT m.movement_id id, p.name product, m.delta, m.quantity_after quantityAfter, m.reason, m.order_id orderId, m.created_at at, u.email FROM inventory_movements m
    JOIN products p ON p.product_id = m.product_id LEFT JOIN users u ON u.user_id = m.user_id ORDER BY m.movement_id DESC LIMIT ?`).all(clamp(int(ctx.query.limit, 100), 1, 500)) },
}));

route('GET', '/api/admin/users', { auth: 'admin' }, () => ({
  body: { users: db.prepare(`SELECT u.user_id id, u.full_name name, u.email, u.role, u.is_active active, u.created_at createdAt, u.last_login_at lastLogin,
      (SELECT COUNT(*) FROM orders o WHERE o.user_id = u.user_id) orders, (SELECT IFNULL(SUM(total_amount),0) FROM orders o WHERE o.user_id = u.user_id AND o.status <> 'CANCELLED') spent
      FROM users u ORDER BY u.user_id DESC LIMIT 300`).all() },
}));
route('PATCH', '/api/admin/users/:id', { auth: 'admin', job: () => ({ type: 'ADMIN_ACTION', source: 'ADMIN', disk: [cyl('users', 4)] }) }, (ctx) => {
  const id = int(ctx.params.id), active = ctx.body.active ? 1 : 0;
  const u = db.prepare(`SELECT * FROM users WHERE user_id = ?`).get(id);
  if (!u) throw new HttpError(404, 'User not found.');
  if (u.role === 'ADMIN') throw new HttpError(409, 'Admin accounts cannot be deactivated here.');
  db.prepare(`UPDATE users SET is_active = ? WHERE user_id = ?`).run(active, id);
  if (!active) db.prepare(`UPDATE sessions SET revoked = 1 WHERE user_id = ?`).run(id);
  audit(ctx, active ? 'USER_ACTIVATED' : 'USER_DEACTIVATED', `${active ? 'Re-activated' : 'Deactivated'} ${u.email}`, { type: 'user', id });
  return { body: { ok: true } };
});

// ---------------------------------------------------------------- static files
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon', '.json': 'application/json' };
function serveStatic(req, res, pathname) {
  if (req.method !== 'GET' && req.method !== 'HEAD') { res.writeHead(405); return res.end(); }
  let rel = pathname === '/' ? '/index.html' : pathname;
  let file; try { file = path.normalize(path.join(FRONTEND, decodeURIComponent(rel))); } catch { res.writeHead(400); return res.end(); }
  if (!file.startsWith(FRONTEND + path.sep) || !fs.existsSync(file) || !fs.statSync(file).isFile()) {
    res.writeHead(404, { 'Content-Type': 'text/plain', ...SEC_HEADERS }); return res.end('Not found');
  }
  res.writeHead(200, { 'Content-Type': MIME[path.extname(file)] || 'application/octet-stream', 'Cache-Control': 'no-cache', ...SEC_HEADERS });
  fs.createReadStream(file).pipe(res);
}

const server = http.createServer((req, res) => {
  const url = new URL(req.url, 'http://localhost');
  if (url.pathname.startsWith('/api/')) dispatchApi(req, res, url).catch((e) => { log('FATAL ' + (e.stack || e)); if (!res.headersSent) send(res, 500, { error: 'Internal error' }); });
  else serveStatic(req, res, url.pathname);
});

if (require.main === module) {
  server.listen(PORT, () => {
    log(`NEXORA running:  store  http://localhost:${PORT}/   admin  http://localhost:${PORT}/admin-login.html`);
    if (!process.env.NEXORA_ADMIN_PASSWORD) log(`NOTE  admin account uses the demo password (${DEFAULT_ADMIN_PASSWORD}). Set NEXORA_ADMIN_PASSWORD before first start for anything real.`);
  });
  const stop = async () => { await flushTracking(); kernel.stop(); server.close(); setTimeout(() => process.exit(0), 300).unref(); };
  process.on('SIGINT', stop); process.on('SIGTERM', stop);
}
module.exports = { server, kernel, db };
