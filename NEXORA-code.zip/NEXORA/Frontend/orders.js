'use strict';
// Order history for the signed-in customer, with live status and a status trail. Orders are private to the account.
const host = document.getElementById('orders');
let orders = [];

function draw() {
  host.innerHTML = orders.map((o) => `<article class="card order" data-id="${o.id}"><header><h3 style="margin:0">Order #${o.id}</h3>
      <span><span class="status ${escapeHtml(o.status)}">${escapeHtml(o.status.charAt(0) + o.status.slice(1).toLowerCase())}</span> <span class="muted">${when(o.createdAt)}</span></span></header>
    <ul class="items">${o.items.map((i) => `<li><span>${i.qty} × ${escapeHtml(i.name)}</span><span>${money(i.price * i.qty)}</span></li>`).join('')}</ul>
    <div style="display:flex;justify-content:space-between;gap:10px;flex-wrap:wrap"><span class="muted">Ship to: ${escapeHtml(o.address)}</span><b>${money(o.total)}</b></div>
    <ul class="trail" aria-label="Status history">${o.history.map((h) => `<li>${escapeHtml(h.status.toLowerCase())} · ${when(h.at)}</li>`).join('')}</ul>
    ${o.canCancel ? '<p style="margin:12px 0 0"><button type="button" class="danger" data-cancel="1">Cancel order</button></p>' : ''}</article>`).join('');
}

async function load() {
  orders = (await API.get('/api/orders')).orders;
  if (!orders.length) { host.innerHTML = '<div class="card empty"><h2>No orders yet</h2><p>When you place an order it shows up here, and you can follow it from placed to delivered.</p><a class="btn" href="index.html">Browse products</a></div>'; return; }
  draw();
}

host.addEventListener('click', async (ev) => {
  const b = ev.target.closest('button[data-cancel]'); if (!b) return;
  const id = b.closest('.order').dataset.id;
  if (!confirm(`Cancel order #${id}? The items go back into stock.`)) return;
  b.disabled = true;
  try { await API.post(`/api/orders/${id}/cancel`); toast(`Order #${id} cancelled`); } catch (e) { toast(e.message, 'bad'); }
  load().catch(() => {});
});

window.pageReady = async () => {
  if (!session.user) {
    host.innerHTML = '<div class="gate"><h3 style="margin-top:0">Sign in to see your orders</h3><p>Orders belong to your account, so you need to sign in first.</p><div class="row"><a class="btn" href="login.html?next=orders.html">Sign in</a><a class="btn secondary" href="login.html?tab=register&next=orders.html">Create account</a></div></div>';
    return;
  }
  try { await load(); } catch (e) { host.innerHTML = `<div class="card empty"><h2>Orders could not load</h2><p>${escapeHtml(e.message)}</p></div>`; }
  setInterval(() => load().catch(() => {}), 8000); // pick up status changes made by the admin
};
