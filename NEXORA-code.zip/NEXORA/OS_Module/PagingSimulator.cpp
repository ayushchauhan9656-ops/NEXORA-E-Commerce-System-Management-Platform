#include "PagingSimulator.hpp"
#include <algorithm>
#include <deque>
using namespace std;
namespace nexora
{
    int fifoPageFaults(const vector<int> &pages, int frameCount)
    {
        if (frameCount <= 0)
            return static_cast<int>(pages.size());
        deque<int> frames;
        int faults = 0;
        for (int page : pages)
        {
            if (find(frames.begin(), frames.end(), page) != frames.end())
                continue;
            ++faults;
            if (static_cast<int>(frames.size()) == frameCount)
                frames.pop_front();
            frames.push_back(page);
        }
        return faults;
    }

    bool LRUPageTable::access(int page, int *victim)
    {
        if (victim)
            *victim = -1;
        auto it = find(order_.begin(), order_.end(), page);
        if (it != order_.end())
        { // hit: becomes most recently used
            order_.splice(order_.begin(), order_, it);
            return true;
        }
        if (capacity_ == 0)
            return false; // no frames at all: every reference faults
        if (static_cast<int>(order_.size()) >= capacity_)
        {
            if (victim)
                *victim = order_.back();
            order_.pop_back(); // evict the least recently used page
        }
        order_.push_front(page);
        return false;
    }

    bool LRUPageTable::contains(int page) const
    {
        return find(order_.begin(), order_.end(), page) != order_.end();
    }

    vector<int> LRUPageTable::frames() const
    {
        return vector<int>(order_.begin(), order_.end());
    }

    int lruPageFaults(const vector<int> &pages, int frameCount)
    {
        if (frameCount <= 0)
            return static_cast<int>(pages.size());
        LRUPageTable table(frameCount);
        int faults = 0;
        for (int page : pages)
            if (!table.access(page))
                ++faults;
        return faults;
    }
}
