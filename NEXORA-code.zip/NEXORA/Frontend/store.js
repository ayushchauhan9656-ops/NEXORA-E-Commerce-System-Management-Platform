'use strict';
// Storefront catalogue. Signed-in customers add to their account cart; guests to a browser-only cart.
const host = document.getElementById('products'), search = document.getElementById('search'), countEl = document.getElementById('resultCount');
let timer = null, seq = 0;

function card(p) {
  const out = p.stock < 1, low = !out && p.stock <= 5;
  return `<article class="product">${tileFor(p.name, p.category)}<div class="body">
    <span class="cat">${escapeHtml(p.category || 'General')}</span><h3>${escapeHtml(p.name)}</h3>
    <span class="stock ${out ? 'out' : low ? 'low' : ''}">${out ? 'Sold out' : low ? `Only ${p.stock} left` : `${p.stock} in stock`}</span>
    <div class="price">${money(p.price)}</div>
    <button type="button" data-add="${p.id}" ${out ? 'disabled' : ''}>${out ? 'Sold out' : 'Add to cart'}</button></div></article>`;
}

async function load() {
  const mine = ++seq;
  try {
    const { products } = await API.get('/api/products?q=' + encodeURIComponent(search.value.trim()));
    if (mine !== seq) return; // a newer search is already running
    host.innerHTML = products.length ? products.map(card).join('')
      : '<div class="card empty" style="grid-column:1/-1"><h2>No products match</h2><p>Try a shorter search, or clear it to see everything.</p></div>';
    countEl.textContent = products.length + (products.length === 1 ? ' product' : ' products');
  } catch (e) { host.innerHTML = `<div class="card empty" style="grid-column:1/-1"><h2>The store could not load</h2><p>${escapeHtml(e.message)}</p></div>`; }
}

host.addEventListener('click', async (ev) => {
  const b = ev.target.closest('button[data-add]'); if (!b) return;
  const id = Number(b.dataset.add); b.disabled = true;
  try {
    if (session.user) { const cart = await API.post('/api/cart/items', { productId: id, qty: 1 }); setCartCount(cart.count); }
    else { guestCart.add(id, 1); setCartCount(guestCart.count()); }
    toast('Added to your cart');
  } catch (e) { toast(e.message, 'bad'); if (e.code === 'STOCK') load(); }
  b.disabled = false;
});
search.addEventListener('input', () => { clearTimeout(timer); timer = setTimeout(load, 200); });
window.pageReady = () => { document.getElementById('guestBanner').hidden = !!session.user; return load(); };
