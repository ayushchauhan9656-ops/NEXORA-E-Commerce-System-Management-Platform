#pragma once
#include <string>
#include <vector>
using namespace std;
namespace nexora
{
    // Simulated main memory.
    //
    //  * Pinned blocks (running jobs, system daemons) are never evicted.
    //  * Everything else (carts, sessions, cached product pages) is evictable and is
    //    managed with LRU: when a new block does not fit, the Least Recently Used
    //    evictable blocks are thrown out first.
    //  * allocate()/release() are the original anonymous byte counters and still work.
    class MemoryManager
    {
    public:
        struct Block
        {
            string owner;
            long long size;
            bool pinned;
        };

        explicit MemoryManager(long long total) : total_(total < 0 ? 0 : total) {}

        // ---- original API ----
        bool allocate(long long amount);
        bool release(long long amount);
        long long available() const;
        long long used() const;
        long long total() const;

        // ---- LRU API ----
        // Reserve `size` KB for `owner`. Evicts least-recently-used unpinned blocks (their
        // owners are appended to `evicted`) if needed. Returns false - and evicts nothing -
        // when the block cannot fit even after evicting everything evictable.
        // Re-allocating an owner that is already resident touches (and resizes) it.
        bool allocateFor(const string &owner, long long size, vector<string> &evicted, bool pinned = false);
        bool touch(const string &owner);             // mark as most recently used
        bool resident(const string &owner) const;
        bool releaseOwner(const string &owner);      // free a block explicitly
        long long evictions() const;
        const vector<Block> &blocks() const;         // most recently used first

    private:
        int find(const string &owner) const;
        bool makeRoom(long long need, vector<string> &evicted, const string &protectOwner);

        long long total_;
        long long anon_{0};      // bytes taken through allocate()
        long long blockKb_{0};   // bytes held by named blocks
        long long evictions_{0};
        vector<Block> blocks_;   // index 0 = most recently used
    };
}
