// Module tests: `make test`
#include "CPU_Scheduler.hpp"
#include "DiskScheduler.hpp"
#include "MemoryManager.hpp"
#include "PagingSimulator.hpp"
#include "ProcessManager.hpp"
#include "ResourceManager.hpp"
#include "SystemMonitor.hpp"
#include "IPCMessageQueue.hpp"
#include <iostream>
using namespace std;
using namespace nexora;

static int failures = 0, checks = 0;
#define CHECK(cond)                                                          \
    do                                                                       \
    {                                                                        \
        ++checks;                                                            \
        if (!(cond))                                                         \
        {                                                                    \
            ++failures;                                                      \
            cout << "FAIL line " << __LINE__ << ": " #cond "\n";             \
        }                                                                    \
    } while (0)

int main()
{
    // ---------- original algorithms still behave ----------
    {
        vector<Job> j = {{1, 0, 5, 2}, {2, 1, 3, 1}, {3, 2, 1, 3}};
        CHECK((CPUScheduler::fcfs(j) == vector<int>{1, 2, 3}));
        CHECK((CPUScheduler::sjf(j) == vector<int>{1, 3, 2}));
    }
    // ---------- Round Robin (textbook: quantum 4) ----------
    {
        vector<Job> j = {{1, 0, 24, 2}, {2, 0, 3, 2}, {3, 0, 3, 2}};
        CHECK((CPUScheduler::roundRobin(j, 4) == vector<int>{1, 2, 3, 1}));
        auto r = CPUScheduler::scheduleRoundRobin(j, 4);
        CHECK(r.avgWaiting > 5.66 && r.avgWaiting < 5.67); // (6+4+7)/3
        CHECK(r.makespan == 30);
        CHECK(r.idleTicks == 0);
        bool threw = false;
        try { CPUScheduler::roundRobin(j, 0); } catch (const invalid_argument &) { threw = true; }
        CHECK(threw);
    }
    // RR: idle gap, and arrivals during a slice queue before the preempted job
    {
        vector<Job> j = {{1, 0, 5, 2}, {2, 1, 2, 2}, {3, 20, 2, 2}};
        CHECK((CPUScheduler::roundRobin(j, 2) == vector<int>{1, 2, 1, 3}));
        auto r = CPUScheduler::scheduleRoundRobin(j, 2);
        CHECK(r.idleTicks == 13); // 7 -> 20
    }
    // ---------- Multilevel Queue ----------
    {
        // J1 batch (Q2) is preempted by J2 (Q1) and then J3 (Q0); Q0 is RR q=3.
        vector<Job> j = {{1, 0, 8, 3}, {2, 1, 4, 2}, {3, 2, 5, 1}, {4, 3, 3, 1}, {5, 4, 6, 3}};
        auto r = CPUScheduler::scheduleMLQ(j, 3);
        vector<int> expect = {1, 2, 3, 4, 3, 2, 1, 5};
        vector<int> got;
        for (auto &s : r.slices) got.push_back(s.jobId);
        CHECK(got == expect);
        CHECK(r.makespan == 26);
        CHECK(CPUScheduler::multilevelQueue(j, 3) == expect);
        // urgent job that arrives last still finishes before batch work that arrived first
        vector<Job> k = {{1, 0, 10, 3}, {2, 5, 2, 1}};
        auto rk = CPUScheduler::scheduleMLQ(k, 4);
        int f1 = 0, f2 = 0;
        for (auto &s : rk.stats) (s.id == 1 ? f1 : f2) = s.completion;
        CHECK(f2 == 7 && f1 == 12);
        // explicit queue overrides priority
        vector<Job> m = {{1, 0, 4, 1, 2}, {2, 0, 4, 3, 0}};
        auto rm = CPUScheduler::scheduleMLQ(m, 4);
        CHECK(rm.slices.front().jobId == 2);
    }
    // ---------- run() dispatch ----------
    {
        vector<Job> j = {{1, 0, 3, 1}, {2, 1, 3, 2}};
        for (const char *a : {"FCFS", "SJF", "PRIORITY", "RR", "MLQ"})
            CHECK(CPUScheduler::run(a, j, 2).busyTicks == 6);
        bool threw = false;
        try { CPUScheduler::run("NOPE", j, 2); } catch (const invalid_argument &) { threw = true; }
        CHECK(threw);
    }
    // ---------- LRU page replacement ----------
    {
        vector<int> refs = {7, 0, 1, 2, 0, 3, 0, 4, 2, 3, 0, 3, 2, 1, 2, 0, 1, 7, 0, 1};
        CHECK(lruPageFaults(refs, 3) == 12);  // classic textbook answer
        CHECK(fifoPageFaults(refs, 3) == 15);
        LRUPageTable t(2);
        CHECK(!t.access(1)); CHECK(!t.access(2));
        CHECK(t.access(1));              // 1 is now most recent
        int victim = -1;
        CHECK(!t.access(3, &victim));
        CHECK(victim == 2);              // 2 was least recently used
        CHECK((t.frames() == vector<int>{3, 1}));
    }
    // ---------- LRU memory manager ----------
    {
        MemoryManager m(100);
        vector<string> ev;
        CHECK(m.allocateFor("a", 40, ev)); CHECK(m.allocateFor("b", 40, ev));
        CHECK(m.touch("a"));                      // b is now LRU
        CHECK(m.allocateFor("c", 40, ev));        // must evict b
        CHECK(ev.size() == 1 && ev[0] == "b");
        CHECK(m.resident("a") && !m.resident("b") && m.resident("c"));
        CHECK(m.used() == 80);
        ev.clear();
        CHECK(m.allocateFor("pin", 20, ev, true));
        CHECK(!m.allocateFor("huge", 90, ev));    // cannot evict pinned -> refuses, evicts nothing
        CHECK(m.resident("a") && m.resident("c"));
        CHECK(m.allocateFor("d", 80, ev));        // evicts a and c, keeps pinned
        CHECK(m.resident("pin") && m.resident("d") && !m.resident("a"));
        CHECK(m.releaseOwner("d") && m.used() == 20);
        CHECK(m.evictions() == 3);
        CHECK(m.allocate(10) && m.used() == 30 && m.release(10)); // original API intact
    }
    // ---------- SSTF ----------
    {
        vector<int> reqs = {98, 183, 37, 122, 14, 124, 65, 67};
        CHECK(diskFCFS(reqs, 53) == 640);
        CHECK(diskSSTF(reqs, 53) == 236);
        CHECK((diskSSTFOrder(reqs, 53) == vector<int>{65, 67, 37, 14, 98, 122, 124, 183}));
        CHECK(diskSSTF({}, 10) == 0);
    }
    // ---------- deadlock ----------
    {
        CHECK(ResourceManager::hasDeadlock({0, 0}, {{1, 0}, {0, 1}}, {{0, 1}, {1, 0}}));
        CHECK(!ResourceManager::hasDeadlock({1, 1}, {{1, 0}, {0, 1}}, {{0, 1}, {1, 0}}));
        CHECK((ResourceManager::deadlockedProcesses({0, 0}, {{1, 0}, {0, 1}}, {{0, 1}, {1, 0}}) == vector<int>{0, 1}));
        CHECK(ResourceManager::deadlockedProcesses({1}, {{0}, {1}}, {{1}, {0}}).empty());
    }
    // ---------- process / monitor / IPC ----------
    {
        ProcessManager pm;
        int a = pm.create("a"), b = pm.create("b");
        CHECK(pm.create("") == -1 && pm.count() == 2);
        CHECK(pm.suspend(a) && pm.find(a)->state == "SUSPENDED");
        CHECK(pm.resume(a) && pm.setState(b, "RUNNING") && pm.find(b)->state == "RUNNING");
        CHECK(pm.terminate(a) && !pm.terminate(a));
        SystemMonitor mon;
        mon.record("x");
        mon.record("WARN", "disk", "y", 5);
        CHECK(mon.eventCount() == 2 && mon.recent(1).front().source == "disk");
        IPCMessageQueue ipc;
        ipc.send("m1"); ipc.send("m2");
        string out;
        CHECK(ipc.snapshot().size() == 2 && ipc.receive(out) && out == "m1" && ipc.size() == 1);
    }
    cout << (checks - failures) << "/" << checks << " checks passed\n";
    return failures ? 1 : 0;
}
