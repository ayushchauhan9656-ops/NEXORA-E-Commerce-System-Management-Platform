#include "DiskScheduler.hpp"
#include <cstdlib>
using namespace std;
namespace nexora
{
    int diskFCFS(const vector<int> &requests, int head)
    {
        int movement = 0;
        for (int request : requests)
        {
            movement += abs(head - request);
            head = request;
        }
        return movement;
    }

    DiskPlan diskSSTFPlan(const vector<int> &requests, int head)
    {
        DiskPlan plan;
        vector<int> pending = requests;
        while (!pending.empty())
        {
            size_t best = 0;
            for (size_t i = 1; i < pending.size(); ++i)
                if (abs(pending[i] - head) < abs(pending[best] - head))
                    best = i; // strict '<': the earlier request wins a tie
            plan.movement += abs(pending[best] - head);
            head = pending[best];
            plan.order.push_back(head);
            pending.erase(pending.begin() + static_cast<long>(best));
        }
        plan.finalHead = head;
        return plan;
    }

    vector<int> diskSSTFOrder(const vector<int> &requests, int head)
    {
        return diskSSTFPlan(requests, head).order;
    }

    int diskSSTF(const vector<int> &requests, int head)
    {
        return diskSSTFPlan(requests, head).movement;
    }
}
