'use strict';
// NEXORA admin console - core: helpers, data polling, tables, shared SVG pieces.
// (No inline handlers: the server's CSP only allows scripts served from this origin.)

const A = {
  os: null,          // latest /api/admin/os payload
  pts: [],           // series with derived fields, for charts
  stats: null,       // latest /api/admin/stats
  admin: null,
  runs: new Map(),   // run detail cache
  runId: null,       // run currently inspected (shared by Scheduler, Disk, Resources)
  view: null, tickNo: 0,
};
const VIEWS = {};

// ----------------------------------------------------------------- tiny helpers
const $ = (s, r = document) => r.querySelector(s);
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const nf = (n, d = 0) => (Number.isFinite(+n) ? (+n).toLocaleString(undefined, { minimumFractionDigits: d, maximumFractionDigits: d }) : '–');
const kb = (n) => (n >= 1024 ? nf(n / 1024, n >= 10240 ? 0 : 1) + ' MB' : nf(n) + ' KB');
const usd = (n) => '$' + nf(n, 2);
const clockTime = (iso) => { const d = new Date(iso); return isNaN(d) ? '' : d.toLocaleTimeString(); };
const dateTime = (iso) => { const d = new Date(iso); return isNaN(d) ? '' : d.toLocaleString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit', second: '2-digit' }); };
const QNAME = ['Q0 urgent', 'Q1 interactive', 'Q2 batch'];
const QCOL = ['var(--s1)', 'var(--s3)', 'var(--s2)'];
const qchip = (q) => `<span class="chip q${q}">Q${q}</span>`;
const sevClass = { LOW: '', MEDIUM: 'warn', HIGH: 'bad', CRITICAL: 'crit' };
const stateClass = { RUNNING: 'good', READY: 'q0', BLOCKED: 'warn', SUSPENDED: 'warn', TERMINATED: '' };
const chip = (text, cls = '') => `<span class="chip ${cls}">${esc(text)}</span>`;
const tile = (label, value, detail = '') => `<div class="panel tile"><div class="n">${value}</div><div class="l">${label}</div>${detail ? `<div class="d">${detail}</div>` : ''}</div>`;
const hbar = (label, value, max, color, right) => `<div class="hbar"><span>${label}</span><div class="track"><div class="fill" style="width:${max > 0 ? Math.min(100, (value / max) * 100) : 0}%;background:${color}"></div></div><span class="num">${right ?? nf(value)}</span></div>`;
const legend = (items) => `<div class="legend">${items.map(([c, t]) => `<span><i style="background:${c}"></i>${esc(t)}</span>`).join('')}</div>`;

// ----------------------------------------------------------------- network
async function aj(method, path, body) {
  const res = await fetch(path, { method, headers: body ? { 'Content-Type': 'application/json' } : {}, body: body ? JSON.stringify(body) : undefined, credentials: 'same-origin' });
  let data = {}; try { data = await res.json(); } catch { /* empty */ }
  if (res.status === 401) { location.href = 'admin-login.html'; throw new Error('Signed out'); }
  if (!res.ok) throw new Error(data.error || 'Request failed');
  return data;
}
const aget = (p) => aj('GET', p);
function say(el, text, kind) { if (el) { el.textContent = text; el.className = 'msg ' + (kind || ''); } }

// ----------------------------------------------------------------- tables
// cols: [{k, label, f(row)->html, v(row)->sortValue, num, sort:false}]
function dataTable(el, cols, rows, opt = {}) {
  el._cols = cols; el._rows = rows; el._opt = opt;
  if (!el._wired) {
    el._wired = true;
    el.addEventListener('click', (e) => {
      const th = e.target.closest('th[data-sort]'); if (!th) return;
      const k = th.dataset.sort;
      el._sort = el._sort && el._sort.k === k ? { k, dir: -el._sort.dir } : { k, dir: 1 };
      dataTable(el, el._cols, el._rows, el._opt);
    });
  }
  const wrapOld = el.querySelector('.tbl-wrap'), scroll = wrapOld ? wrapOld.scrollTop : 0;
  const s = el._sort; let r = rows.slice();
  if (s) { const c = cols.find((x) => x.k === s.k); if (c) { const val = c.v || ((x) => x[c.k]); r.sort((a, b) => { const x = val(a), y = val(b); return (x > y ? 1 : x < y ? -1 : 0) * s.dir; }); } }
  if (!rows.length) { el.innerHTML = `<div class="empty">${opt.empty || 'Nothing here yet.'}</div>`; return; }
  el.innerHTML = `<div class="tbl-wrap" ${opt.maxHeight ? `style="max-height:${opt.maxHeight}px"` : ''}><table class="t"><thead><tr>${cols.map((c) => `<th ${c.sort === false ? '' : `data-sort="${c.k}"`} class="${c.num ? 'num' : ''}">${c.label}${s && s.k === c.k ? (s.dir > 0 ? ' ▲' : ' ▼') : ''}</th>`).join('')}</tr></thead><tbody>${
    r.slice(0, opt.max || 500).map((row) => `<tr>${cols.map((c) => `<td class="${c.num ? 'num ' : ''}${c.cls || ''}">${c.f ? c.f(row) : esc(row[c.k] ?? '')}</td>`).join('')}</tr>`).join('')}</tbody></table></div>`;
  const w = el.querySelector('.tbl-wrap'); if (w && scroll) w.scrollTop = scroll;
}

// ----------------------------------------------------------------- SVG pieces
// Gantt: one lane per MLQ queue. slices: [{job,pid,start,end,queue,type}]
function ganttSvg(slices) {
  if (!slices || !slices.length) return '<div class="empty">No run yet. Place an order, or start a load test on this page.</div>';
  const t0 = Math.min(...slices.map((s) => s.start)), t1 = Math.max(...slices.map((s) => s.end)), span = Math.max(1, t1 - t0);
  const left = 92, top = 8, laneH = 36, W = left + Math.min(3200, Math.max(640, span * 9)), H = top + 3 * laneH + 26, iw = W - left - 10;
  const X = (t) => left + ((t - t0) / span) * iw;
  const step = [1, 2, 5, 10, 20, 50, 100, 200, 500, 1000].find((s) => span / s <= 14) || 1000;
  let g = '';
  for (let q = 0; q < 3; q++) g += `<rect x="${left}" y="${top + q * laneH}" width="${iw}" height="${laneH - 4}" fill="#0b0f14" rx="4"/><text x="${left - 8}" y="${top + q * laneH + 22}" text-anchor="end" style="fill:var(--ink-2)">${QNAME[q].split(' ')[0]} ${QNAME[q].split(' ')[1]}</text>`;
  for (let t = Math.ceil(t0 / step) * step; t <= t1; t += step) g += `<line x1="${X(t)}" x2="${X(t)}" y1="${top}" y2="${top + 3 * laneH - 4}" stroke="#263140"/><text x="${X(t)}" y="${H - 6}" text-anchor="middle" style="fill:var(--muted)">${t}</text>`;
  for (const s of slices) {
    const q = Math.max(0, Math.min(2, s.queue)), x = X(s.start), w = Math.max(2, X(s.end) - x - 1);
    g += `<g><title>Job ${s.job} (${esc(s.type)}) ticks ${s.start}–${s.end}, ${s.end - s.start} tick${s.end - s.start === 1 ? '' : 's'}</title><rect x="${x}" y="${top + q * laneH + 2}" width="${w}" height="${laneH - 8}" rx="3" fill="${QCOL[q]}"/>${w > 22 ? `<text x="${x + w / 2}" y="${top + q * laneH + 21}" text-anchor="middle">${s.job}</text>` : ''}</g>`;
  }
  return `<div class="gantt"><svg width="${W}" height="${H}" viewBox="0 0 ${W} ${H}" role="img" aria-label="Gantt chart of CPU time per queue">${g}</svg></div>`;
}

// Disk seek diagram: head path across cylinders 0..199, one step per request.
function seekSvg(headStart, seq, color, title, total) {
  const pts = [headStart, ...seq.slice(0, 40)], W = 360, rowH = 16, H = 40 + pts.length * rowH, L = 14, R = 14, X = (c) => L + (c / 199) * (W - L - R);
  let g = `<text x="${L}" y="16" style="fill:#fff;font-weight:600">${esc(title)}</text><text x="${W - R}" y="16" text-anchor="end" style="fill:var(--ink-2)">${nf(total)} cylinders</text>`;
  g += [0, 50, 100, 150, 199].map((c) => `<line x1="${X(c)}" x2="${X(c)}" y1="26" y2="${H - 6}" stroke="#263140"/><text x="${X(c)}" y="${H}" text-anchor="middle" style="fill:var(--muted)">${c}</text>`).join('');
  const path = pts.map((c, i) => `${i ? 'L' : 'M'}${X(c).toFixed(1)},${(34 + i * rowH).toFixed(1)}`).join('');
  g += `<path d="${path}" fill="none" stroke="${color}" stroke-width="2" stroke-linejoin="round"/>`;
  g += pts.map((c, i) => `<circle cx="${X(c)}" cy="${34 + i * rowH}" r="${i ? 3 : 5}" fill="${i ? color : '#fff'}"><title>${i ? 'Request ' + i : 'Head start'}: cylinder ${c}</title></circle>`).join('');
  return `<svg width="100%" viewBox="0 0 ${W} ${H + 4}" role="img" aria-label="${esc(title)} head movement">${g}</svg>`;
}

// ----------------------------------------------------------------- run detail cache
async function loadRun(id) {
  if (id == null) return null;
  if (A.runs.has(id)) return A.runs.get(id);
  try { const r = await aget('/api/admin/os/run?id=' + id); A.runs.set(id, r); if (A.runs.size > 40) A.runs.delete(A.runs.keys().next().value); return r; } catch { return null; }
}
function currentRunId() {
  const runs = (A.os && A.os.runs) || [];
  if (A.runId != null && runs.some((r) => r.runId === A.runId)) return A.runId;
  return A.os ? A.os.focusRunId : null;
}
function runOptions(selected) {
  const runs = (A.os && A.os.runs) || [];
  return runs.map((r) => `<option value="${r.runId}" ${r.runId === selected ? 'selected' : ''}>Run ${r.runId} · ${r.algorithm} · ${r.jobs} job${r.jobs === 1 ? '' : 's'} · ${clockTime(r.at)}</option>`).join('');
}

// ----------------------------------------------------------------- polling
function derive(series) { return (series || []).map((p) => ({ ...p, mem: p.memTotal ? (p.memUsed * 100) / p.memTotal : 0 })); }

async function pollOs() {
  try {
    A.os = await aget('/api/admin/os?points=150');
    A.pts = derive(A.os.series);
    paintTopbar();
  } catch { /* offline or signed out: aj() already redirected */ }
}
async function pollStats() { try { A.stats = await aget('/api/admin/stats'); } catch { /* ignore */ } }

function paintTopbar() {
  const o = A.os, s = o && o.snapshot, last = A.pts[A.pts.length - 1] || {};
  $('#eng-dot').className = 'dot' + (o && o.online ? ' on' : '');
  $('#eng-txt').textContent = o && o.online ? `OS engine online · ${o.config.algorithm}` + (['RR', 'MLQ'].includes(o.config.algorithm) ? ` q=${o.config.quantum}` : '') : 'OS engine offline';
  $('#tb-cpu').textContent = nf(last.cpu || 0, 0) + '%';
  $('#tb-mem').textContent = nf(last.mem || 0, 0) + '%';
  $('#tb-proc').textContent = s ? nf(s.processes.length) : '–';
  $('#tb-jps').textContent = nf(last.jps || 0, 1);
  $('#tb-dead').textContent = s ? nf(s.resources.deadlocks) : '–';
}

let timer = null;
async function loop() {
  A.tickNo++;
  await pollOs();
  if (A.tickNo % 4 === 1) await pollStats();
  const v = A.view;
  if (v) {
    try {
      if (v.load && v.every && A.tickNo % v.every === 0) await v.load();
      if (v.tick) v.tick();
    } catch (e) { console.error(e); }
  }
}
function startLoop() { loop().finally(() => { timer = setInterval(loop, 1000); }); }

// ----------------------------------------------------------------- router
const NAV = [
  ['Monitor', [['overview', 'Overview'], ['performance', 'Performance'], ['processes', 'Processes'], ['activity', 'Live activity']]],
  ['OS engine', [['scheduler', 'CPU scheduler'], ['memory', 'Memory'], ['disk', 'Disk'], ['resources', 'Locks & deadlocks'], ['ipc', 'IPC & events']]],
  ['Store', [['orders', 'Orders'], ['products', 'Products & stock'], ['customers', 'Customers & logins'], ['security', 'Security']]],
  ['Data', [['tracking', 'Database tracking']]],
];
function buildNav() {
  $('#nav').innerHTML = NAV.map(([g, items]) => `<h6>${g}</h6>` + items.map(([id, label]) => `<a class="tab" href="#${id}" data-id="${id}">${label}</a>`).join('')).join('');
}
async function route() {
  const id = (location.hash || '#overview').slice(1);
  const v = VIEWS[id] || VIEWS.overview, key = VIEWS[id] ? id : 'overview';
  if (A.view && A.view.unmount) A.view.unmount();
  document.querySelectorAll('#nav a.tab').forEach((a) => (a.getAttribute('data-id') === key ? a.setAttribute('aria-current', 'page') : a.removeAttribute('aria-current')));
  A.view = null;
  const root = $('#view'); root.innerHTML = '';
  document.title = v.title + ' · NEXORA Admin';
  v.mount(root);
  A.view = v;
  try { if (v.load) await v.load(); if (v.tick) v.tick(); } catch (e) { console.error(e); }
}
