'use strict';
// Admin console boot: confirm the admin session (admin-core redirects to the login on 401), then start routing + live polling.
(async function boot() {
  try { A.admin = (await aget('/api/admin/me')).admin; } catch { return; }
  $('#who').textContent = A.admin.name + ' · ' + A.admin.email;
  $('#logout').addEventListener('click', async () => {
    try { await aj('POST', '/api/admin/logout'); } catch { /* already signed out */ }
    location.href = 'admin-login.html';
  });
  buildNav();
  window.addEventListener('hashchange', route);
  await route();
  startLoop();
})();
