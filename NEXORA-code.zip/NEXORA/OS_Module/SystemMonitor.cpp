#include "SystemMonitor.hpp"
#include <iostream>
using namespace std;

namespace nexora
{
    void SystemMonitor::record(const string &event)
    {
        record("INFO", "system", event, 0);
    }
    void SystemMonitor::record(const string &level, const string &source, const string &message, long long tick)
    {
        MonitorEvent e;
        e.seq = ++total_;
        e.tick = static_cast<int>(tick);
        e.level = level;
        e.source = source;
        e.message = message;
        events_.push_back(std::move(e));
        if (events_.size() > kKeep)
            events_.pop_front();
    }
    long long SystemMonitor::eventCount() const
    {
        return total_;
    }
    vector<MonitorEvent> SystemMonitor::recent(size_t n) const
    {
        const size_t take = n < events_.size() ? n : events_.size();
        return vector<MonitorEvent>(events_.end() - static_cast<long>(take), events_.end());
    }
    vector<MonitorEvent> SystemMonitor::since(long long seq, size_t limit) const
    {
        vector<MonitorEvent> out;
        for (const auto &e : events_)
        {
            if (e.seq <= seq)
                continue;
            if (out.size() >= limit)
                break;
            out.push_back(e);
        }
        return out;
    }
    void SystemMonitor::print() const
    {
        for (const auto &event : events_)
            cout << "- [" << event.level << "] " << event.source << ": " << event.message << '\n';
    }
}
