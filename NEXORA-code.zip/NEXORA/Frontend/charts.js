'use strict';
// Tiny dependency-free SVG charts for the admin console (the server's CSP forbids CDNs).
const COLORS = ['var(--s1)', 'var(--s2)', 'var(--s3)', 'var(--s4)', 'var(--s5)'];
const NS = 'http://www.w3.org/2000/svg';

function niceMax(v) {
  if (!(v > 0)) return 1;
  const p = Math.pow(10, Math.floor(Math.log10(v))), n = v / p;
  return (n <= 1 ? 1 : n <= 2 ? 2 : n <= 5 ? 5 : 10) * p;
}

// Line/area chart with a hover crosshair + tooltip.
//   opts: series [{name,key,color}], fmt(v), yMax (number | fn(points) | undefined = auto), height, label (aria)
class LineChart {
  constructor(el, opts) {
    this.el = el; this.o = Object.assign({ height: 210, fmt: (v) => String(Math.round(v)), label: 'Chart' }, opts);
    this.pts = []; this.hover = -1; this.geo = null;
    el.classList.add('lc');
    el.innerHTML = '<svg role="img"></svg><div class="lc-tip" hidden></div>';
    this.svg = el.firstChild; this.tip = el.lastChild;
    el.addEventListener('pointermove', (e) => this._move(e));
    el.addEventListener('pointerleave', () => { this.hover = -1; this._drawHover(); });
  }
  update(pts) { this.pts = pts || []; this.draw(); }
  draw() {
    const W = Math.max(280, this.el.clientWidth || 600), H = this.o.height, pad = { l: 46, r: 12, t: 10, b: 22 };
    const pts = this.pts, iw = W - pad.l - pad.r, ih = H - pad.t - pad.b;
    let max = typeof this.o.yMax === 'function' ? this.o.yMax(pts) : this.o.yMax;
    if (!(max > 0)) { let m = 0; for (const p of pts) for (const s of this.o.series) m = Math.max(m, p[s.key] || 0); max = niceMax(m * 1.1); }
    const t0 = pts.length ? pts[0].t : 0, t1 = pts.length > 1 ? pts[pts.length - 1].t : t0 + 1;
    const X = (t) => pad.l + ((t - t0) / Math.max(1, t1 - t0)) * iw, Y = (v) => pad.t + ih - (Math.min(v, max) / max) * ih;
    this.geo = { X, Y, pad, W, H, max, t0, t1 };
    let g = '';
    for (let i = 0; i <= 4; i++) {
      const v = (max * i) / 4, y = Y(v);
      g += `<line class="gridl" x1="${pad.l}" x2="${W - pad.r}" y1="${y}" y2="${y}"/><text x="${pad.l - 6}" y="${y + 4}" text-anchor="end">${this.o.fmt(v, true)}</text>`;
    }
    const span = Math.round((t1 - t0) / 1000);
    g += `<text x="${pad.l}" y="${H - 5}">${pts.length ? '−' + span + 's' : ''}</text><text x="${W - pad.r}" y="${H - 5}" text-anchor="end">now</text>`;
    this.o.series.forEach((s, i) => {
      if (pts.length < 2) return;
      const col = s.color || COLORS[i % COLORS.length];
      const d = pts.map((p, k) => `${k ? 'L' : 'M'}${X(p.t).toFixed(1)},${Y(p[s.key] || 0).toFixed(1)}`).join('');
      if (this.o.series.length === 1)
        g += `<path d="${d}L${X(t1)},${Y(0)}L${X(t0)},${Y(0)}Z" fill="${col}" opacity=".16"/>`;
      g += `<path d="${d}" fill="none" stroke="${col}" stroke-width="2" stroke-linejoin="round" stroke-linecap="round"/>`;
    });
    if (!pts.length) g += `<text x="${W / 2}" y="${H / 2}" text-anchor="middle">Waiting for data…</text>`;
    this.svg.setAttribute('viewBox', `0 0 ${W} ${H}`); this.svg.setAttribute('height', H); this.svg.setAttribute('aria-label', this.o.label);
    this.svg.innerHTML = `<g class="axis">${g}</g><g class="hv"></g>`;
    this._drawHover();
  }
  _move(e) {
    if (!this.geo || !this.pts.length) return;
    const r = this.svg.getBoundingClientRect(), x = ((e.clientX - r.left) / r.width) * this.geo.W;
    let best = 0, bd = Infinity;
    this.pts.forEach((p, i) => { const d = Math.abs(this.geo.X(p.t) - x); if (d < bd) { bd = d; best = i; } });
    this.hover = best; this._drawHover();
  }
  _drawHover() {
    const hv = this.svg.querySelector('.hv'); if (!hv) return;
    if (this.hover < 0 || !this.pts[this.hover]) { hv.innerHTML = ''; this.tip.hidden = true; return; }
    const p = this.pts[this.hover], { X, Y, pad, H, W } = this.geo, x = X(p.t);
    let s = `<line class="cross" x1="${x}" x2="${x}" y1="${pad.t}" y2="${H - pad.b}"/>`;
    this.o.series.forEach((se, i) => { s += `<circle cx="${x}" cy="${Y(p[se.key] || 0)}" r="4" fill="${se.color || COLORS[i % COLORS.length]}" stroke="#151b23" stroke-width="2"/>`; });
    hv.innerHTML = s;
    this.tip.hidden = false;
    this.tip.innerHTML = `<b>${new Date(p.t).toLocaleTimeString()}</b>` + this.o.series.map((se, i) =>
      `<div><i style="background:${se.color || COLORS[i % COLORS.length]}"></i>${se.name}: <b>${this.o.fmt(p[se.key] || 0)}</b></div>`).join('');
    const left = (x / W) * this.el.clientWidth;
    this.tip.style.left = Math.min(Math.max(0, left + 12), this.el.clientWidth - this.tip.offsetWidth - 4) + 'px';
    this.tip.style.top = '8px';
  }
}

function sparkline(values, color, max) {
  const w = 78, h = 40, n = values.length;
  if (n < 2) return `<svg viewBox="0 0 ${w} ${h}" aria-hidden="true"></svg>`;
  const m = max > 0 ? max : niceMax(Math.max(...values) * 1.1);
  const pts = values.map((v, i) => `${((i / (n - 1)) * (w - 2) + 1).toFixed(1)},${(h - 2 - (Math.min(v, m) / m) * (h - 4)).toFixed(1)}`);
  return `<svg viewBox="0 0 ${w} ${h}" aria-hidden="true"><polygon points="1,${h - 1} ${pts.join(' ')} ${w - 1},${h - 1}" fill="${color}" opacity=".18"/><polyline points="${pts.join(' ')}" fill="none" stroke="${color}" stroke-width="1.6" stroke-linejoin="round"/></svg>`;
}
