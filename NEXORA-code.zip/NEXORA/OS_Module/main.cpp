// =============================================================================
//  NEXORA OS Engine - main.cpp
//
//  Connects every OS module into one kernel:
//
//      ProcessManager  -> every storefront/admin operation becomes a process
//      MemoryManager   -> job memory + resident carts/sessions/pages, LRU eviction
//      PagingSimulator -> LRU page-frame table for product pages
//      ResourceManager -> stock-lock graph, deadlock detection on checkout
//      CPUScheduler    -> Multilevel Queue (default), Round Robin, FCFS, SJF, Priority
//      DiskScheduler   -> SSTF scheduling of log / data-storage writes
//      IPCMessageQueue -> job-completion messages delivered to the monitor
//      SystemMonitor   -> event log the admin panel reads
//
//  Modes
//      nexora_kernel --serve   line protocol on stdin/stdout (used by Backend/)
//      nexora_kernel --demo    self-contained walkthrough printed to the terminal
//
//  Protocol (one command per line, one JSON object per reply):
//      CONFIG algo=MLQ quantum=4 memory=8192 frames=16
//      SUBMIT id=17 type=CHECKOUT user=5 pages=1,2 locks=2,1 disk=170,60 [burst= prio= mem=]
//      RUN         schedule everything submitted since the last RUN
//      SNAPSHOT [since=SEQ]   full state of every module (since=: ALL monitor events after SEQ, for DB tracking)
//      PING | QUIT
// =============================================================================
#include "CPU_Scheduler.hpp"
#include "DiskScheduler.hpp"
#include "IPCMessageQueue.hpp"
#include "MemoryManager.hpp"
#include "PagingSimulator.hpp"
#include "ProcessManager.hpp"
#include "ResourceManager.hpp"
#include "SystemMonitor.hpp"

#include <algorithm>
#include <cmath>
#include <cstdlib>
#include <deque>
#include <iomanip>
#include <iostream>
#include <map>
#include <set>
#include <sstream>
#include <string>
#include <vector>

using namespace std;
using namespace nexora;

namespace
{
    constexpr int kCylinders = 200;
    constexpr long long kPageKb = 32;     // one cached product page
    constexpr long long kSessionKb = 64;  // resident per logged-in user
    constexpr long long kCartKb = 256;    // resident per active cart
    constexpr int kRollbackPenalty = 2;   // extra ticks for a deadlock victim

    string esc(const string &s)
    {
        string o;
        for (unsigned char c : s)
        {
            switch (c)
            {
            case '"': o += "\\\""; break;
            case '\\': o += "\\\\"; break;
            case '\n': o += "\\n"; break;
            case '\r': o += "\\r"; break;
            case '\t': o += "\\t"; break;
            default:
                if (c < 0x20)
                {
                    char buf[8];
                    snprintf(buf, sizeof buf, "\\u%04x", c);
                    o += buf;
                }
                else
                    o += static_cast<char>(c);
            }
        }
        return o;
    }
    string q(const string &s) { return "\"" + esc(s) + "\""; }
    string num(double v)
    {
        if (!isfinite(v))
            return "0";
        ostringstream o;
        o << fixed << setprecision(2) << v;
        return o.str();
    }
    template <class T>
    string arr(const vector<T> &v)
    {
        string o = "[";
        for (size_t i = 0; i < v.size(); ++i)
            o += (i ? "," : "") + to_string(v[i]);
        return o + "]";
    }
    string err(const string &m) { return "{\"ok\":false,\"error\":" + q(m) + "}"; }

    vector<int> parseInts(const string &s)
    {
        vector<int> out;
        stringstream ss(s);
        string item;
        while (getline(ss, item, ','))
            if (!item.empty())
                out.push_back(atoi(item.c_str()));
        return out;
    }

    // What each kind of storefront / admin operation costs the machine.
    struct Profile
    {
        int burst;      // CPU ticks (1 tick = 10 ms of simulated CPU)
        int priority;   // 1 urgent -> MLQ Q0, 2 interactive -> Q1, 3 batch -> Q2
        long long mem;  // KB while running
    };
    const map<string, Profile> &profiles()
    {
        static const map<string, Profile> p = {
            {"CHECKOUT", {8, 1, 512}},     {"STOCK_UPDATE", {5, 1, 256}},
            {"LOGIN", {3, 2, 96}},         {"REGISTER", {4, 2, 96}},
            {"LOGOUT", {1, 2, 32}},        {"CART", {2, 2, 128}},
            {"BROWSE", {2, 2, 64}},        {"ORDER_UPDATE", {4, 2, 128}},
            {"ADMIN_ACTION", {3, 2, 192}}, {"REPORT", {12, 3, 1024}},
            {"AUDIT_FLUSH", {6, 3, 256}},
        };
        return p;
    }
    int defaultCylinder(const string &type, int id)
    {
        static const map<string, int> base = {{"CHECKOUT", 170}, {"STOCK_UPDATE", 95}, {"LOGIN", 20},
                                              {"REGISTER", 25}, {"CART", 130}, {"ORDER_UPDATE", 165},
                                              {"AUDIT_FLUSH", 190}, {"REPORT", 150}};
        auto it = base.find(type);
        return it == base.end() ? -1 : (it->second + (id * 7) % 20) % kCylinders;
    }

    struct JobRec
    {
        int id{0}, pid{0}, user{0};
        string type;
        int burst{0}, priority{2}, arrival{0};
        long long mem{0};
        vector<int> pages, locks, disk;
        bool retried{false}, deadlocked{false};
    };

    struct JobOut
    {
        JobRec job;
        int queue{0}, start{0}, finish{0}, wait{0}, turnaround{0}, response{0}, memWait{0}, wave{0};
        int faults{0}, hits{0};
        vector<string> evicted;
    };

    struct GanttBar
    {
        int jobId, pid, start, end, queue;
        string type;
    };

    struct DeadlockRec
    {
        vector<int> jobs;
        int victim;
    };

    struct RunSummary
    {
        string algorithm;
        int quantum{0}, clock{0}, jobs{0}, waves{0}, ctx{0};
        double avgWait{0}, avgTurnaround{0}, avgResponse{0}, utilization{0};
        vector<GanttBar> gantt;
    };
} // namespace

// =============================================================================
class NexoraKernel
{
    // ---- the modules ----
    ProcessManager processes_;
    MemoryManager memory_{8192};
    LRUPageTable frames_{16};
    IPCMessageQueue ipc_;
    SystemMonitor monitor_;

    // ---- configuration ----
    string algorithm_{"MLQ"};
    int quantum_{4};
    int frameCount_{16};

    // ---- state ----
    long long clock_{0};
    vector<JobRec> pending_;
    deque<JobOut> recent_;
    vector<int> refString_;
    int head_{100};

    // ---- counters ----
    long long completed_{0}, busy_{0}, idle_{0}, ctx_{0};
    long long queueDone_[3]{0, 0, 0};
    double sumWait_{0}, sumTat_{0};
    long long pageHits_{0}, pageFaults_{0};
    long long diskFcfs_{0}, diskSstf_{0}, diskRuns_{0};
    vector<int> lastDiskOrder_;
    int lastDiskFcfs_{0}, lastDiskSstf_{0};
    long long deadlocks_{0}, rollbacks_{0}, lockWaits_{0};
    string lockTableJson_{"[]"};
    long long ipcSent_{0}, ipcReceived_{0};
    deque<string> ipcLog_;
    RunSummary lastRun_;
    long long runs_{0};

    int tick() const { return static_cast<int>(clock_); }

    static int levelOf(const JobRec &j)
    {
        return CPUScheduler::queueLevel(Job{j.id, 0, 0, j.priority});
    }

public:
    NexoraKernel()
    {
        // Long-lived system processes, resident and never evicted.
        const char *daemons[] = {"nexora-kernel", "cpu-scheduler", "memory-manager",
                                 "resource-manager", "disk-audit-manager", "ipc-monitor"};
        for (const char *name : daemons)
        {
            int pid = processes_.create(name);
            if (Process *p = processes_.find(pid))
            {
                p->state = "RUNNING";
                p->type = "DAEMON";
                p->queue = 0;
                p->priority = 0;
                p->memoryKb = string(name) == "nexora-kernel" ? 256 : 128;
                vector<string> none;
                memory_.allocateFor(string("daemon:") + name, p->memoryKb, none, true);
            }
        }
        monitor_.record("INFO", "kernel", "NEXORA OS Engine booted (MLQ scheduler, LRU memory, SSTF disk)", 0);
    }

    // -------------------------------------------------------------- commands
    string handle(const string &line)
    {
        stringstream ss(line);
        string cmd;
        ss >> cmd;
        map<string, string> kv;
        string tok;
        while (ss >> tok)
        {
            auto eq = tok.find('=');
            if (eq != string::npos)
                kv[tok.substr(0, eq)] = tok.substr(eq + 1);
        }
        try
        {
            if (cmd == "PING")
                return "{\"ok\":true,\"pong\":true}";
            if (cmd == "CONFIG")
                return config(kv);
            if (cmd == "SUBMIT")
                return submit(kv);
            if (cmd == "RUN")
                return run();
            if (cmd == "SNAPSHOT")
            {
                auto it = kv.find("since");
                return snapshot(it == kv.end() ? -1 : atoll(it->second.c_str()));
            }
            return err("Unknown command: " + cmd);
        }
        catch (const exception &e)
        {
            return err(e.what());
        }
    }

private:
    string config(const map<string, string> &kv)
    {
        auto get = [&](const char *k) -> const string *
        { auto it = kv.find(k); return it == kv.end() ? nullptr : &it->second; };
        if (const string *a = get("algo"))
        {
            static const set<string> ok = {"FCFS", "SJF", "PRIORITY", "RR", "MLQ"};
            if (!ok.count(*a))
                return err("algo must be one of FCFS, SJF, PRIORITY, RR, MLQ");
            algorithm_ = *a;
        }
        if (const string *v = get("quantum"))
        {
            const int n = atoi(v->c_str());
            if (n < 1 || n > 64)
                return err("quantum must be 1..64");
            quantum_ = n;
        }
        if (const string *v = get("memory"))
        {
            const long long n = atoll(v->c_str());
            if (n < 1024 || n > 1048576)
                return err("memory must be 1024..1048576 KB");
            if (n != memory_.total())
            {
                // Rebuild: daemons come back pinned, resident caches start cold.
                memory_ = MemoryManager(n);
                for (const auto &p : processes_.list())
                    if (p.type == "DAEMON")
                    {
                        vector<string> none;
                        memory_.allocateFor("daemon:" + p.name, p.memoryKb, none, true);
                    }
            }
        }
        if (const string *v = get("frames"))
        {
            const int n = atoi(v->c_str());
            if (n < 1 || n > 256)
                return err("frames must be 1..256");
            if (n != frameCount_)
            { // only a real change resizes (and so empties) the page-frame table
                frameCount_ = n;
                frames_ = LRUPageTable(n);
            }
        }
        monitor_.record("INFO", "cpu", "Config: algorithm=" + algorithm_ + " quantum=" + to_string(quantum_) +
                                           " memory=" + to_string(memory_.total()) + "KB frames=" + to_string(frameCount_),
                        clock_);
        return "{\"ok\":true,\"algorithm\":" + q(algorithm_) + ",\"quantum\":" + to_string(quantum_) +
               ",\"memory\":" + to_string(memory_.total()) + ",\"frames\":" + to_string(frameCount_) + "}";
    }

    string submit(const map<string, string> &kv)
    {
        auto get = [&](const char *k, const string &d = "")
        { auto it = kv.find(k); return it == kv.end() ? d : it->second; };
        if (get("id").empty())
            return err("SUBMIT needs id=");
        JobRec j;
        j.id = atoi(get("id").c_str());
        j.type = get("type", "BROWSE");
        for (auto &c : j.type)
            c = static_cast<char>(toupper(static_cast<unsigned char>(c)));
        Profile pr{3, 2, 128};
        auto found = profiles().find(j.type);
        if (found != profiles().end())
            pr = found->second;
        j.user = atoi(get("user", "0").c_str());
        j.burst = max(1, min(60, atoi(get("burst", to_string(pr.burst)).c_str())));
        j.priority = max(1, min(9, atoi(get("prio", to_string(pr.priority)).c_str())));
        j.mem = max(1LL, min(memory_.total() / 2, atoll(get("mem", to_string(pr.mem)).c_str())));
        j.pages = parseInts(get("pages"));
        j.locks = parseInts(get("locks"));
        j.disk = parseInts(get("disk"));
        if (j.disk.empty())
        {
            const int c = defaultCylinder(j.type, j.id);
            if (c >= 0)
                j.disk.push_back(c);
        }
        for (int &c : j.disk)
            c = max(0, min(kCylinders - 1, c));
        j.arrival = tick() + static_cast<int>(pending_.size()); // requests arrive one tick apart
        j.pid = processes_.create(j.type + "#" + to_string(j.id));
        if (Process *p = processes_.find(j.pid))
        {
            p->type = j.type;
            p->user = j.user;
            p->priority = j.priority;
            p->queue = levelOf(j);
            p->burst = j.burst;
            p->arrival = j.arrival;
            p->memoryKb = j.mem;
        }
        pending_.push_back(j);
        return "{\"ok\":true,\"pid\":" + to_string(j.pid) + ",\"queue\":" + to_string(levelOf(j)) + "}";
    }

    // Detect circular lock waits between the jobs of one wave.
    void analyseLocks(vector<JobRec> &wave, vector<DeadlockRec> &found)
    {
        set<int> resSet;
        for (const auto &j : wave)
            for (int r : j.locks)
                resSet.insert(r);
        const size_t n = wave.size();
        if (resSet.empty())
        {
            lockTableJson_ = "[]";
            return;
        }
        vector<int> res(resSet.begin(), resSet.end());
        map<int, size_t> col;
        for (size_t i = 0; i < res.size(); ++i)
            col[res[i]] = i;

        // Round 1: everybody grabs their first lock. Round 2: holders ask for their next.
        map<int, size_t> holder;
        vector<int> holds(n, -1), wants(n, -1);
        for (size_t i = 0; i < n; ++i)
        {
            if (wave[i].locks.empty())
                continue;
            const int first = wave[i].locks[0];
            if (!holder.count(first))
            {
                holder[first] = i;
                holds[i] = first;
                if (wave[i].locks.size() > 1)
                    wants[i] = wave[i].locks[1];
            }
            else
                wants[i] = first;
        }
        vector<int> available(res.size(), 1);
        vector<vector<int>> alloc(n, vector<int>(res.size(), 0)), req(n, vector<int>(res.size(), 0));
        for (size_t i = 0; i < n; ++i)
        {
            if (holds[i] >= 0)
            {
                alloc[i][col[holds[i]]] = 1;
                available[col[holds[i]]] = 0;
            }
            if (wants[i] >= 0)
                req[i][col[wants[i]]] = 1;
        }

        string table = "[";
        bool firstRow = true;
        for (int r : res)
        {
            string waiters = "[";
            bool f = true;
            for (size_t i = 0; i < n; ++i)
                if (wants[i] == r && (!holder.count(r) || holder[r] != i))
                {
                    if (holder.count(r))
                        ++lockWaits_;
                    waiters += (f ? "" : ",") + to_string(wave[i].id);
                    f = false;
                }
            waiters += "]";
            table += string(firstRow ? "" : ",") + "{\"resource\":" + to_string(r) + ",\"holder\":" +
                     (holder.count(r) ? to_string(wave[holder[r]].id) : "null") + ",\"waiters\":" + waiters + "}";
            firstRow = false;
        }
        lockTableJson_ = table + "]";

        const vector<int> stuck = ResourceManager::deadlockedProcesses(available, alloc, req);
        if (stuck.empty())
            return;
        DeadlockRec rec;
        size_t victim = static_cast<size_t>(stuck[0]);
        for (int s : stuck)
        {
            rec.jobs.push_back(wave[s].id);
            wave[s].deadlocked = true;
            sort(wave[s].locks.begin(), wave[s].locks.end()); // ordered locking from now on
            if (wave[s].arrival > wave[victim].arrival ||
                (wave[s].arrival == wave[victim].arrival && wave[s].id > wave[victim].id))
                victim = static_cast<size_t>(s);
        }
        wave[victim].retried = true;
        wave[victim].burst += kRollbackPenalty; // roll back and retry
        rec.victim = wave[victim].id;
        ++deadlocks_;
        ++rollbacks_;
        ostringstream m;
        m << "DEADLOCK among jobs " << arr(rec.jobs) << " - victim job " << rec.victim
          << " rolled back; ordered locking applied";
        monitor_.record("WARN", "resource", m.str(), clock_);
        found.push_back(rec);
    }

    string run()
    {
        vector<JobRec> todo = std::move(pending_);
        pending_.clear();
        RunSummary summary;
        summary.algorithm = algorithm_;
        summary.quantum = quantum_;
        if (todo.empty())
        {
            summary.clock = tick();
            lastRunKeep(summary, false);
            return "{\"ok\":true,\"jobs\":[],\"gantt\":[],\"deadlocks\":[],\"waves\":0,\"clock\":" + to_string(tick()) + "}";
        }

        vector<JobOut> finished;
        vector<DeadlockRec> deadlocks;
        vector<int> diskRequests;
        double wSum = 0, tSum = 0, rSum = 0;
        int busyThisRun = 0, spanStart = tick(), wave = 0;

        while (!todo.empty())
        {
            ++wave;
            // ---- long-term scheduling: admit as many jobs as memory allows ----
            vector<JobRec> admitted, waiting;
            map<int, vector<string>> evictedFor;
            for (auto &j : todo)
            {
                vector<string> ev;
                if (memory_.allocateFor("job:" + to_string(j.id), j.mem, ev, true))
                {
                    admitted.push_back(j);
                    evictedFor[j.id] = ev;
                    for (const auto &e : ev)
                        monitor_.record("INFO", "memory", "LRU evicted '" + e + "' to admit job " + to_string(j.id), clock_);
                }
                else
                    waiting.push_back(j);
            }
            if (admitted.empty())
            { // memory hopelessly full: run one job without a reservation
                admitted.push_back(waiting.front());
                waiting.erase(waiting.begin());
            }
            for (auto &j : waiting)
                processes_.setState(j.pid, "BLOCKED");
            todo = waiting;

            analyseLocks(admitted, deadlocks);

            // ---- short-term scheduling ----
            const int waveStart = tick();
            vector<Job> jobs;
            map<int, size_t> byId;
            for (size_t i = 0; i < admitted.size(); ++i)
            {
                jobs.push_back(Job{admitted[i].id, max(admitted[i].arrival, waveStart), admitted[i].burst, admitted[i].priority});
                byId[admitted[i].id] = i;
                processes_.setState(admitted[i].pid, "READY");
                if (Process *p = processes_.find(admitted[i].pid))
                    p->burst = admitted[i].burst;
            }
            ScheduleResult sr = CPUScheduler::run(algorithm_, jobs, quantum_);
            summary.ctx += sr.contextSwitches;
            ctx_ += sr.contextSwitches;
            busy_ += sr.busyTicks;
            idle_ += sr.idleTicks;
            busyThisRun += sr.busyTicks;

            for (const auto &s : sr.slices)
            {
                const JobRec &jr = admitted[byId[s.jobId]];
                summary.gantt.push_back({s.jobId, jr.pid, s.start, s.end, s.queue, jr.type});
            }

            // ---- results per job (start order => page references in running order) ----
            vector<JobOut> outs;
            for (const auto &st : sr.stats)
            {
                JobOut o;
                o.job = admitted[byId[st.id]];
                o.queue = st.queue;
                o.start = st.firstRun;
                o.finish = st.completion;
                o.turnaround = st.completion - o.job.arrival;
                o.wait = o.turnaround - st.burst;
                o.response = st.firstRun - o.job.arrival;
                o.memWait = max(0, waveStart - o.job.arrival);
                o.wave = wave;
                o.evicted = evictedFor[st.id];
                outs.push_back(o);
            }
            sort(outs.begin(), outs.end(), [](const JobOut &a, const JobOut &b)
                 { return a.start != b.start ? a.start < b.start : a.job.id < b.job.id; });
            for (auto &o : outs)
            {
                processes_.setState(o.job.pid, "RUNNING");
                touchMemory(o);
            }
            sort(outs.begin(), outs.end(), [](const JobOut &a, const JobOut &b)
                 { return a.finish != b.finish ? a.finish < b.finish : a.job.id < b.job.id; });
            for (auto &o : outs)
            {
                memory_.releaseOwner("job:" + to_string(o.job.id));
                if (o.job.type == "CHECKOUT" && o.job.user > 0)
                    memory_.releaseOwner("cart:" + to_string(o.job.user)); // cart is gone once ordered
                if (o.job.type == "LOGOUT" && o.job.user > 0)
                {
                    memory_.releaseOwner("session:" + to_string(o.job.user));
                    memory_.releaseOwner("cart:" + to_string(o.job.user));
                }
                if (Process *p = processes_.find(o.job.pid))
                    p->cpuTime = o.job.burst;
                processes_.setState(o.job.pid, "TERMINATED");
                for (int c : o.job.disk)
                    diskRequests.push_back(c);
                wSum += o.wait;
                tSum += o.turnaround;
                rSum += o.response;
                sumWait_ += o.wait;
                sumTat_ += o.turnaround;
                ++completed_;
                ++queueDone_[max(0, min(2, o.queue))];
                // IPC: the job reports back to the monitor
                ostringstream msg;
                msg << "JOB_DONE pid=" << o.job.pid << " job=" << o.job.id << " " << o.job.type
                    << " exit=0 wait=" << o.wait << " tat=" << o.turnaround;
                ipc_.send(msg.str());
                ++ipcSent_;
                recent_.push_front(o);
                if (recent_.size() > 40)
                    recent_.pop_back();
                finished.push_back(o);
            }
            for (auto &o : outs)
                processes_.terminate(o.job.pid);

            clock_ = max<long long>(clock_, sr.makespan);
        }

        // ---- disk manager: schedule this run's writes with SSTF ----
        string diskJson = "null";
        if (!diskRequests.empty())
        {
            const int fcfs = diskFCFS(diskRequests, head_);
            const DiskPlan plan = diskSSTFPlan(diskRequests, head_);
            diskFcfs_ += fcfs;
            diskSstf_ += plan.movement;
            ++diskRuns_;
            lastDiskOrder_ = plan.order;
            lastDiskFcfs_ = fcfs;
            lastDiskSstf_ = plan.movement;
            ostringstream m;
            m << "DISK " << diskRequests.size() << " writes: SSTF moved " << plan.movement
              << " cyl vs FCFS " << fcfs << " (head " << head_ << " -> " << plan.finalHead << ")";
            monitor_.record("INFO", "disk", m.str(), clock_);
            diskJson = "{\"headStart\":" + to_string(head_) + ",\"head\":" + to_string(plan.finalHead) +
                       ",\"requests\":" + arr(diskRequests) + ",\"order\":" + arr(plan.order) +
                       ",\"fcfs\":" + to_string(fcfs) + ",\"sstf\":" + to_string(plan.movement) + "}";
            head_ = plan.finalHead;
        }

        // ---- IPC: monitor drains the message queue ----
        string msg;
        while (ipc_.receive(msg))
        {
            ++ipcReceived_;
            ipcLog_.push_back(msg);
            if (ipcLog_.size() > 60)
                ipcLog_.pop_front();
            monitor_.record("INFO", "ipc", msg, clock_);
        }

        const double n = static_cast<double>(finished.size());
        summary.clock = tick();
        summary.jobs = static_cast<int>(finished.size());
        summary.waves = wave;
        summary.avgWait = n ? wSum / n : 0;
        summary.avgTurnaround = n ? tSum / n : 0;
        summary.avgResponse = n ? rSum / n : 0;
        const int span = max(1, tick() - spanStart);
        summary.utilization = min(100.0, 100.0 * busyThisRun / span);
        lastRunKeep(summary, true);
        {
            ostringstream m;
            m << algorithm_ << " ran " << finished.size() << " jobs in " << wave << " wave(s): avg wait "
              << num(summary.avgWait) << ", avg turnaround " << num(summary.avgTurnaround)
              << ", " << summary.ctx << " context switches";
            monitor_.record("INFO", "cpu", m.str(), clock_);
        }

        // ---- reply ----
        ostringstream o;
        o << "{\"ok\":true,\"algorithm\":" << q(algorithm_) << ",\"quantum\":" << quantum_
          << ",\"clock\":" << tick() << ",\"waves\":" << wave << ",\"jobs\":[";
        for (size_t i = 0; i < finished.size(); ++i)
            o << (i ? "," : "") << jobJson(finished[i]);
        o << "],\"gantt\":" << ganttJson(summary.gantt) << ",\"avgWait\":" << num(summary.avgWait)
          << ",\"avgTurnaround\":" << num(summary.avgTurnaround) << ",\"avgResponse\":" << num(summary.avgResponse)
          << ",\"ctx\":" << summary.ctx << ",\"util\":" << num(summary.utilization)
          << ",\"disk\":" << diskJson << ",\"locks\":" << lockTableJson_ << ",\"deadlocks\":[";
        for (size_t i = 0; i < deadlocks.size(); ++i)
            o << (i ? "," : "") << "{\"jobs\":" << arr(deadlocks[i].jobs) << ",\"victim\":" << deadlocks[i].victim << "}";
        o << "]}";
        return o.str();
    }

    void lastRunKeep(const RunSummary &s, bool real)
    {
        if (real)
        {
            lastRun_ = s;
            ++runs_;
        }
    }

    // Memory + paging side effects of a job starting to run.
    void touchMemory(JobOut &o)
    {
        const JobRec &j = o.job;
        auto reserve = [&](const string &owner, long long kb)
        {
            vector<string> ev;
            if (!memory_.allocateFor(owner, kb, ev))
            {
                monitor_.record("WARN", "memory", "No room for '" + owner + "' (memory pinned by running jobs)", clock_);
                return;
            }
            for (const auto &e : ev)
            {
                o.evicted.push_back(e);
                monitor_.record("INFO", "memory", "LRU evicted '" + e + "' to load '" + owner + "'", clock_);
            }
        };
        if (j.user > 0)
        {
            if (j.type != "LOGOUT")
                reserve("session:" + to_string(j.user), kSessionKb);
            if (j.type == "CART" || j.type == "CHECKOUT")
                reserve("cart:" + to_string(j.user), kCartKb);
        }
        for (int page : j.pages)
        {
            int victim = -1;
            const bool hit = frames_.access(page, &victim);
            hit ? (++o.hits, ++pageHits_) : (++o.faults, ++pageFaults_);
            refString_.push_back(page);
            if (refString_.size() > 400)
                refString_.erase(refString_.begin());
            reserve("page:" + to_string(page), kPageKb);
        }
    }

    string jobJson(const JobOut &o) const
    {
        ostringstream s;
        s << "{\"id\":" << o.job.id << ",\"pid\":" << o.job.pid << ",\"type\":" << q(o.job.type)
          << ",\"user\":" << o.job.user << ",\"queue\":" << o.queue << ",\"priority\":" << o.job.priority
          << ",\"arrival\":" << o.job.arrival << ",\"start\":" << o.start << ",\"finish\":" << o.finish
          << ",\"burst\":" << o.job.burst << ",\"wait\":" << o.wait << ",\"turnaround\":" << o.turnaround
          << ",\"response\":" << o.response << ",\"memKb\":" << o.job.mem << ",\"memWait\":" << o.memWait
          << ",\"wave\":" << o.wave << ",\"pageFaults\":" << o.faults << ",\"pageHits\":" << o.hits
          << ",\"retried\":" << (o.job.retried ? "true" : "false")
          << ",\"deadlocked\":" << (o.job.deadlocked ? "true" : "false")
          << ",\"disk\":" << arr(o.job.disk) << ",\"evicted\":[";
        for (size_t i = 0; i < o.evicted.size(); ++i)
            s << (i ? "," : "") << q(o.evicted[i]);
        s << "]}";
        return s.str();
    }

    static string ganttJson(const vector<GanttBar> &g)
    {
        string o = "[";
        for (size_t i = 0; i < g.size(); ++i)
            o += string(i ? "," : "") + "{\"job\":" + to_string(g[i].jobId) + ",\"pid\":" + to_string(g[i].pid) +
                 ",\"start\":" + to_string(g[i].start) + ",\"end\":" + to_string(g[i].end) +
                 ",\"queue\":" + to_string(g[i].queue) + ",\"type\":" + q(g[i].type) + "}";
        return o + "]";
    }

    string snapshot(long long since = -1) const
    {
        ostringstream o;
        const double done = static_cast<double>(max<long long>(1, completed_));
        o << "{\"ok\":true,\"clock\":" << clock_ << ",\"algorithm\":" << q(algorithm_) << ",\"quantum\":" << quantum_;

        // CPU
        o << ",\"cpu\":{\"busy\":" << busy_ << ",\"idle\":" << idle_ << ",\"ctx\":" << ctx_
          << ",\"completed\":" << completed_ << ",\"pending\":" << pending_.size()
          << ",\"queues\":[" << queueDone_[0] << "," << queueDone_[1] << "," << queueDone_[2] << "]"
          << ",\"avgWait\":" << num(sumWait_ / done) << ",\"avgTurnaround\":" << num(sumTat_ / done)
          << ",\"runs\":" << runs_ << ",\"lastRun\":{\"algorithm\":" << q(lastRun_.algorithm)
          << ",\"quantum\":" << lastRun_.quantum << ",\"jobs\":" << lastRun_.jobs << ",\"waves\":" << lastRun_.waves
          << ",\"avgWait\":" << num(lastRun_.avgWait) << ",\"avgTurnaround\":" << num(lastRun_.avgTurnaround)
          << ",\"avgResponse\":" << num(lastRun_.avgResponse) << ",\"ctx\":" << lastRun_.ctx
          << ",\"utilization\":" << num(lastRun_.utilization) << ",\"gantt\":" << ganttJson(lastRun_.gantt) << "}}";

        // Memory
        o << ",\"memory\":{\"total\":" << memory_.total() << ",\"used\":" << memory_.used()
          << ",\"available\":" << memory_.available() << ",\"evictions\":" << memory_.evictions() << ",\"blocks\":[";
        const auto blocks = memory_.blocks();
        for (size_t i = 0; i < blocks.size(); ++i)
            o << (i ? "," : "") << "{\"owner\":" << q(blocks[i].owner) << ",\"size\":" << blocks[i].size
              << ",\"pinned\":" << (blocks[i].pinned ? "true" : "false") << "}";
        o << "],\"frames\":{\"capacity\":" << frames_.capacity() << ",\"resident\":" << arr(frames_.frames())
          << ",\"hits\":" << pageHits_ << ",\"faults\":" << pageFaults_ << ",\"refs\":" << refString_.size()
          << ",\"lruFaults\":" << lruPageFaults(refString_, frameCount_)
          << ",\"fifoFaults\":" << fifoPageFaults(refString_, frameCount_) << "}}";

        // Disk
        o << ",\"disk\":{\"head\":" << head_ << ",\"cylinders\":" << kCylinders << ",\"runs\":" << diskRuns_
          << ",\"fcfsTotal\":" << diskFcfs_ << ",\"sstfTotal\":" << diskSstf_ << ",\"lastOrder\":" << arr(lastDiskOrder_)
          << ",\"lastFcfs\":" << lastDiskFcfs_ << ",\"lastSstf\":" << lastDiskSstf_ << "}";

        // Resources
        o << ",\"resources\":{\"deadlocks\":" << deadlocks_ << ",\"rollbacks\":" << rollbacks_
          << ",\"lockWaits\":" << lockWaits_ << ",\"table\":" << lockTableJson_ << "}";

        // IPC
        o << ",\"ipc\":{\"sent\":" << ipcSent_ << ",\"received\":" << ipcReceived_ << ",\"queued\":" << ipc_.size()
          << ",\"recent\":[";
        {
            size_t i = 0;
            for (auto it = ipcLog_.rbegin(); it != ipcLog_.rend() && i < 25; ++it, ++i)
                o << (i ? "," : "") << q(*it);
        }
        o << "]}";

        // Processes
        o << ",\"processes\":[";
        {
            bool first = true;
            for (const auto &p : processes_.list())
            {
                o << (first ? "" : ",") << "{\"pid\":" << p.pid << ",\"name\":" << q(p.name) << ",\"state\":" << q(p.state)
                  << ",\"type\":" << q(p.type) << ",\"user\":" << p.user << ",\"queue\":" << p.queue
                  << ",\"priority\":" << p.priority << ",\"burst\":" << p.burst << ",\"cpuTime\":" << p.cpuTime
                  << ",\"memKb\":" << p.memoryKb << "}";
                first = false;
            }
        }
        o << "],\"recent\":[";
        for (size_t i = 0; i < recent_.size(); ++i)
        {
            const JobOut &r = recent_[i];
            o << (i ? "," : "") << "{\"pid\":" << r.job.pid << ",\"name\":" << q(r.job.type + "#" + to_string(r.job.id))
              << ",\"state\":\"TERMINATED\",\"type\":" << q(r.job.type) << ",\"user\":" << r.job.user
              << ",\"queue\":" << r.queue << ",\"priority\":" << r.job.priority << ",\"burst\":" << r.job.burst
              << ",\"cpuTime\":" << r.job.burst << ",\"memKb\":" << r.job.mem << ",\"wait\":" << r.wait
              << ",\"turnaround\":" << r.turnaround << "}";
        }
        o << "]";

        // Monitor
        o << ",\"monitor\":{\"count\":" << monitor_.eventCount() << ",\"events\":[";
        const auto evs = since >= 0 ? monitor_.since(since, 1000) : monitor_.recent(60);
        for (size_t i = 0; i < evs.size(); ++i)
            o << (i ? "," : "") << "{\"seq\":" << evs[i].seq << ",\"tick\":" << evs[i].tick << ",\"level\":" << q(evs[i].level)
              << ",\"source\":" << q(evs[i].source) << ",\"message\":" << q(evs[i].message) << "}";
        o << "]}}";
        return o.str();
    }
};

// =============================================================================
namespace
{
    void printGantt(const ScheduleResult &r)
    {
        cout << "  " << left << setw(9) << r.algorithm << "| ";
        for (const auto &s : r.slices)
            cout << "J" << s.jobId << "[" << s.start << "-" << s.end << "] ";
        cout << "\n            avg wait " << num(r.avgWaiting) << "  avg turnaround " << num(r.avgTurnaround)
             << "  ctx switches " << r.contextSwitches << "\n";
    }

    int demo()
    {
        cout << "NEXORA OS Engine - demo\n=======================\n\n";
        // The same workload under every scheduler.
        vector<Job> jobs = {{1, 0, 8, 3}, {2, 1, 4, 2}, {3, 2, 5, 1}, {4, 3, 3, 1}, {5, 4, 6, 3}};
        cout << "1) CPU scheduling  (jobs: id/arrival/burst/priority = 1/0/8/3 2/1/4/2 3/2/5/1 4/3/3/1 5/4/6/3, quantum 3)\n";
        for (const char *a : {"FCFS", "SJF", "PRIORITY", "RR", "MLQ"})
            printGantt(CPUScheduler::run(a, jobs, 3));

        cout << "\n2) LRU vs FIFO page replacement (3 frames)\n";
        const vector<int> refs = {7, 0, 1, 2, 0, 3, 0, 4, 2, 3, 0, 3, 2};
        cout << "  reference string 7 0 1 2 0 3 0 4 2 3 0 3 2\n  FIFO faults: " << fifoPageFaults(refs, 3)
             << "   LRU faults: " << lruPageFaults(refs, 3) << "\n";

        cout << "\n3) Disk scheduling, head at 53\n";
        const vector<int> reqs = {98, 183, 37, 122, 14, 124, 65, 67};
        const DiskPlan plan = diskSSTFPlan(reqs, 53);
        cout << "  FCFS movement: " << diskFCFS(reqs, 53) << "   SSTF movement: " << plan.movement << "  order:";
        for (int c : plan.order)
            cout << " " << c;
        cout << "\n";

        cout << "\n4) Deadlock detection (2 checkouts locking products in opposite order)\n";
        cout << "  deadlocked: "
             << (ResourceManager::hasDeadlock({0, 0}, {{1, 0}, {0, 1}}, {{0, 1}, {1, 0}}) ? "yes" : "no") << "\n";

        cout << "\n5) Integrated kernel: a burst of storefront operations\n";
        NexoraKernel kernel;
        int id = 100;
        auto sub = [&](const string &line) { kernel.handle(line); };
        sub("SUBMIT id=" + to_string(id++) + " type=REPORT");
        sub("SUBMIT id=" + to_string(id++) + " type=BROWSE user=2 pages=1,2,3");
        sub("SUBMIT id=" + to_string(id++) + " type=CHECKOUT user=3 pages=1,2 locks=1,2");
        sub("SUBMIT id=" + to_string(id++) + " type=CHECKOUT user=4 pages=2,1 locks=2,1");
        sub("SUBMIT id=" + to_string(id++) + " type=LOGIN user=5");
        sub("SUBMIT id=" + to_string(id++) + " type=STOCK_UPDATE user=1 pages=3");
        const string reply = kernel.handle("RUN");
        cout << "  RUN -> " << reply.substr(0, 400) << " ...\n\n";
        cout << "  SNAPSHOT -> " << kernel.handle("SNAPSHOT").size() << " bytes of JSON (processes, memory, disk, IPC, monitor)\n";
        return 0;
    }

    int serve()
    {
        ios::sync_with_stdio(false);
        NexoraKernel kernel;
        string line;
        cerr << "[nexora-kernel] ready\n";
        while (getline(cin, line))
        {
            if (line == "QUIT")
                break;
            if (line.empty())
                continue;
            cout << kernel.handle(line) << '\n'
                 << flush;
        }
        return 0;
    }
} // namespace

int main(int argc, char **argv)
{
    const string mode = argc > 1 ? argv[1] : "";
    if (mode == "--serve")
        return serve();
    if (mode == "--demo")
        return demo();
    cout << "NEXORA OS Engine\n  nexora_kernel --serve   run as the backend's kernel process (stdin/stdout protocol)\n"
            "  nexora_kernel --demo    print a walkthrough of every module\n";
    return mode.empty() ? 0 : 1;
}
