# NEXORA

NEXORA is an e-commerce application paired with a **simulated operating-system engine**. Storefront and admin operations are submitted to a C++ engine, where they are processed as jobs. The engine demonstrates CPU scheduling, memory management, resource locking, disk scheduling and process monitoring. The Node.js backend stores application data and activity records in SQLite.

```
 Storefront (customers)   +   Admin console (staff)
            |   every operation becomes a managed workload
            v
 NEXORA OS Engine  (OS_Module/, C++17)
   Process Manager · CPU Scheduler · Memory Manager
   Resource & Deadlock Manager · Disk & Audit Manager · IPC & Process Monitor
            |
            v
 NEXORA Data Store (DB/, SQLite now, Oracle twin included)
```

## Run it

Requirements:

- **Node.js 22.13 or later** (the backend uses the built-in `node:sqlite` module).
- A **C++17 compiler**, such as `g++` or `clang++`. On macOS, install the Xcode Command Line Tools with `xcode-select --install`.
- No third-party npm packages are required.

```
cd Backend
npm start            # compiles the OS engine on first start, then serves everything
```

| What | Where |
|---|---|
| Store | http://localhost:3000/ |
| Admin console | http://localhost:3000/admin-login.html |
| Admin login (demo) | `admin` / `NexoraDemo123!` — set `NEXORA_ADMIN_PASSWORD` before the first start to change it |

Other commands: `npm test` (15 end-to-end test groups, real server + real kernel) · `make -C OS_Module test` (57 module checks) · `make -C OS_Module demo` (printed walkthrough of every module).

## What is where

| Folder | Contents |
|---|---|
| `OS_Module/` | One file pair per OS component, plus `main.cpp` which wires them into a single kernel (`nexora_kernel --serve` is what the backend talks to; `--demo` prints a walkthrough). |
| `Backend/` | `server.js` (API, auth, tracking), `kernel.js` (bridge to the C++ engine), `db.js`, `auth.js`, `test/e2e.js`. |
| `Frontend/` | Customer store (`index/cart/orders/login.html`) and the separate admin console (`admin-login.html`, `admin.html`). |
| `DB/` | `schema_sqlite.sql` is used by the backend; `schema_oracle.sql` provides an Oracle version of the database schema. |

## OS engine

| Component | Files | What it does |
|---|---|---|
| CPU Scheduler | `CPU_Scheduler.*` | **Multilevel Queue** (default): Q0 urgent = Round Robin (quantum *q*), Q1 interactive = Round Robin (2*q*), Q2 batch = FCFS; a lower queue always preempts. **Round Robin**, plus FCFS, SJF and preemptive Priority. Admin can switch live. |
| Memory Manager | `MemoryManager.*`, `PagingSimulator.*` | Running jobs and daemons are pinned. Carts, sessions and product pages are evictable and managed with **LRU** (also an LRU page-frame table, compared against FIFO on live traffic). |
| Disk & Audit Manager | `DiskScheduler.*` | Every finished job writes to a cylinder; each batch is reordered with **SSTF**, with FCFS computed on the same writes for comparison. |
| Resource & Deadlock Manager | `ResourceManager.*` | Checkouts lock products; circular waits are detected, one checkout is rolled back and retried with ordered locking. |
| Process Manager | `ProcessManager.*` | Every operation is a process with a PID, queue, burst, memory and state. |
| IPC & Process Monitor | `IPCMessageQueue.hpp`, `SystemMonitor.*` | Finished jobs report through an IPC queue; the monitor's event log is copied losslessly into the database. |
| Kernel | `main.cpp` | Connects all of the above: admits jobs by available memory, schedules, applies paging/locks/disk, and answers `CONFIG / SUBMIT / RUN / SNAPSHOT`. |

## Accounts and the store

* Anyone can browse and fill a cart. **Nobody can order without an account**: the cart page offers *Create account* / *Sign in*, the guest cart is merged into the account after sign-in, and `POST /api/checkout` answers 401 without a customer session.
* Customers and admins use separate sessions and cookies. A customer session is never accepted by an admin route, and customer credentials do not work on the admin login.
* Passwords are hashed with scrypt; sessions use random tokens stored as SHA-256 hashes. Repeated failed logins lock an account for 10 minutes and create a security event.

**Demo only:** the default admin account is intended for local evaluation. Set `NEXORA_ADMIN_PASSWORD` before the first run and do not expose this demo application directly to the public internet.

## Admin console (separate from the store, dark task-manager style)

Overview (the architecture diagram, live) · **Performance** (Task-Manager-style CPU, memory, paging, disk, throughput and deadlock graphs) · Processes · Live activity (every customer/admin action) · CPU scheduler (switch policy, run load tests, Gantt chart per queue) · Memory (LRU) · Disk (FCFS vs SSTF seek diagrams) · Locks & deadlocks · IPC & events · Orders · Products & stock · Customers & logins · Security · Database tracking.

## Database tracking

`audit_logs` (who did what, IP, OS job) · `login_history` · `sessions` · `order_items` · `order_status_history` (by trigger) · `inventory_movements` · `security_events` · `os_jobs` (one row per job: queue, wait, turnaround, page faults) · `os_runs` · `os_metrics` (the graph samples) · `os_events` (the monitor log).


## Development notes

- Run `npm test` from `Backend/` to execute the end-to-end checks.
- Run `make -C OS_Module test` from the project root to test the C++ modules.
- Run `make -C OS_Module clean` to remove compiled objects and executables.
- The SQLite database is created as `Backend/nexora.db` on first start. Set `NEXORA_DB` to use a different database file.
- The OS engine is a teaching/demo simulation. It does not replace or control the host operating system scheduler, memory manager or disk subsystem.
