'use strict';
// NEXORA storefront - shared code: API client, signed-in session, guest cart, header, toasts.
// (No inline handlers anywhere: the server's CSP only allows scripts served from this origin.)

const money = (v) => '$' + Number(v).toFixed(2);
const escapeHtml = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const when = (iso) => { const d = new Date(iso); return isNaN(d) ? '' : d.toLocaleString([], { day: 'numeric', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' }); };

// ------------------------------------------------------------------ API client
async function request(method, path, body) {
  let res;
  try {
    res = await fetch(path, { method, headers: body ? { 'Content-Type': 'application/json' } : {}, body: body ? JSON.stringify(body) : undefined, credentials: 'same-origin' });
  } catch {
    const e = new Error('Cannot reach the NEXORA server. Check that the backend is running and try again.'); e.status = 0; throw e;
  }
  let data = {};
  try { data = await res.json(); } catch { /* empty body */ }
  if (!res.ok) { const e = new Error(data.error || 'Something went wrong. Try again.'); e.status = res.status; e.code = data.code; throw e; }
  return data;
}
const API = {
  get: (p) => request('GET', p),
  post: (p, b) => request('POST', p, b || {}),
  put: (p, b) => request('PUT', p, b || {}),
  del: (p) => request('DELETE', p),
};

// ------------------------------------------------------------------ guest cart
// Guests can fill a cart in this browser, but they cannot order: it is merged into their account after sign-in.
const GUEST_KEY = 'nexora_guest_cart_v2';
const guestCart = {
  get() {
    try { const a = JSON.parse(localStorage.getItem(GUEST_KEY)); return Array.isArray(a) ? a.filter((i) => i && i.id > 0 && i.qty > 0) : []; } catch { return []; }
  },
  set(items) { try { localStorage.setItem(GUEST_KEY, JSON.stringify(items)); } catch { /* private mode */ } },
  add(id, qty = 1) { const c = this.get(), i = c.find((x) => x.id === id); if (i) i.qty += qty; else c.push({ id, qty }); this.set(c); },
  clear() { try { localStorage.removeItem(GUEST_KEY); } catch { /* ignore */ } },
  count() { return this.get().reduce((n, i) => n + i.qty, 0); },
};

// Only same-site page names may be used as a post-login destination (no open redirects).
function safeNext(n) { return /^[a-z0-9-]+\.html(\?[\w=&%.-]*)?$/i.test(String(n || '')) ? n : 'index.html'; }

// ------------------------------------------------------------------ session
const session = {
  user: null, cartCount: 0,
  async load() {
    try { this.user = (await API.get('/api/auth/me')).user; } catch { this.user = null; }
    await this.refreshCart();
  },
  async refreshCart() {
    if (!this.user) { this.cartCount = guestCart.count(); return; }
    try { this.cartCount = (await API.get('/api/cart')).count; } catch { this.cartCount = 0; }
  },
  async signOut() { try { await API.post('/api/auth/logout'); } catch { /* already out */ } location.href = 'index.html'; },
};

function paintHeader() {
  const el = document.getElementById('top'); if (!el) return;
  const here = location.pathname.split('/').pop() || 'index.html';
  const link = (href, label, extra = '') => `<a href="${href}" ${here === href ? 'aria-current="page"' : ''}>${label}${extra}</a>`;
  const badge = `<span class="count" id="cartCount" ${session.cartCount ? '' : 'hidden'}>${session.cartCount}</span>`;
  el.className = 'site';
  el.innerHTML = `<a class="brand" href="index.html" aria-label="NEXORA home"><svg viewBox="0 0 32 32" width="26" height="26" aria-hidden="true"><path d="M16 4l10 12-10 12L6 16z" fill="#5fd4e4"/></svg>NEXORA</a>
    <nav aria-label="Main">${link('index.html', 'Store')}${link('cart.html', 'Cart', badge)}${link('orders.html', 'My orders')}</nav>
    <div class="who">${session.user
      ? `<span class="hello">Hi, ${escapeHtml(session.user.name.split(' ')[0])}</span><button type="button" class="ghost" id="signOut">Sign out</button>`
      : `<a class="ghost" href="login.html?next=${encodeURIComponent(here)}">Sign in</a><a class="btn light" href="login.html?tab=register&next=${encodeURIComponent(here)}">Create account</a>`}</div>`;
  const out = document.getElementById('signOut'); if (out) out.addEventListener('click', () => session.signOut());
  if (!document.querySelector('footer')) {
    const f = document.createElement('footer');
    f.innerHTML = 'NEXORA &middot; an e-commerce store running on its own OS engine &middot; <a href="admin-login.html">Staff sign in</a>';
    document.body.appendChild(f);
  }
}
function setCartCount(n) { session.cartCount = n; const c = document.getElementById('cartCount'); if (c) { c.textContent = n; c.hidden = !n; } }

// ------------------------------------------------------------------ toast
let toastTimer = null;
function toast(msg, kind = '') {
  let t = document.getElementById('toast');
  if (!t) { t = document.createElement('div'); t.id = 'toast'; t.setAttribute('role', 'status'); document.body.appendChild(t); }
  t.className = 'show ' + kind; t.textContent = msg;
  clearTimeout(toastTimer); toastTimer = setTimeout(() => { t.className = ''; }, 3200);
}

async function boot() {
  await session.load();
  paintHeader();
  if (typeof window.pageReady === 'function') { try { await window.pageReady(); } catch (e) { console.error(e); } }
}
document.addEventListener('DOMContentLoaded', boot);

// Product art: a tinted monogram tile (stable colour per category).
function tileFor(name, category) {
  const words = String(name).trim().split(/\s+/);
  const mono = (words[0][0] + (words[1] ? words[1][0] : words[0][1] || '')).toUpperCase();
  let h = 0; for (const ch of String(category || 'x')) h = (h * 31 + ch.charCodeAt(0)) % 5;
  return `<div class="tile c${h}" aria-hidden="true">${escapeHtml(mono)}</div>`;
}
