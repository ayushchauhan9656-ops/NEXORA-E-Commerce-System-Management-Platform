#pragma once
#include <vector>
using namespace std;
namespace nexora
{
    // The order the head visits the cylinders, how far it travels, and where it ends up.
    struct DiskPlan
    {
        vector<int> order;
        int movement{0};
        int finalHead{0};
    };

    // First-Come First-Served: serve requests in arrival order (original policy; the baseline).
    int diskFCFS(const vector<int> &requests, int head);

    // Shortest Seek Time First: always serve the pending request closest to the head.
    // Ties go to the request that arrived first.
    DiskPlan diskSSTFPlan(const vector<int> &requests, int head);
    vector<int> diskSSTFOrder(const vector<int> &requests, int head);
    int diskSSTF(const vector<int> &requests, int head); // total head movement
}
