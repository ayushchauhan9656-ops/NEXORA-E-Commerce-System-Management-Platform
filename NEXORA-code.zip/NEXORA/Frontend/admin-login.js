'use strict';
// Admin sign in. The password is checked on the server; the session lives in an HttpOnly cookie that customers' cookies can never satisfy.
const form = document.getElementById('login'), errEl = document.getElementById('error'), go = document.getElementById('go');
form.addEventListener('submit', async (e) => {
  e.preventDefault();
  errEl.textContent = ''; go.disabled = true;
  try {
    const res = await fetch('/api/admin/login', {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, credentials: 'same-origin',
      body: JSON.stringify({ username: document.getElementById('username').value, password: document.getElementById('password').value }),
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.error || 'Sign in failed. Try again.');
    location.href = 'admin.html';
  } catch (err) { errEl.textContent = err.message; go.disabled = false; }
});
fetch('/api/admin/me', { credentials: 'same-origin' }).then((r) => { if (r.ok) location.href = 'admin.html'; }).catch(() => {});
